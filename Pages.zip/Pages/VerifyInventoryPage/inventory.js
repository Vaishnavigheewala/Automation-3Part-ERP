const { test, expect } = require('@playwright/test');
const locators = require('./inventory.json');

async function selectsubmenuinventory(page, menu) {
    if (menu == "Master") {
        await page.locator(locators.inventorymenu.Inventory).click();
        await expect(page.locator('li.breadcrumb-item.active', { hasText: 'Inventory' })).toBeVisible();


    }
    else if (menu == "Reports") {
        await page.locator(locators.reportmenu.inventoryStock).click();
        await expect(page.locator('li.breadcrumb-item.active', { hasText: 'Inventory Stock Report ' })).toBeVisible();


    }

}

async function verifyInventoryEntrySection(page) {
    await page.waitForSelector(locators.verifyInventoryPage.inventorygroup);
    console.log('Inventory Group dropdown is displayed.');

    const hasSaveButton = await page.isVisible(locators.verifyInventoryPage.savebutton);
    const hasResetButton = await page.isVisible(locators.verifyInventoryPage.resetbutton);

    console.log(`Save button displayed: ${hasSaveButton}`);
    console.log(`Reset button displayed: ${hasResetButton}`);

    await page.click(locators.verifyInventoryPage.inventorygroup);
    const options = await page.locator('li.e-list-item').allInnerTexts();
    console.log('Inventory Group dropdown values:', options);
    await page.waitForTimeout(2000);
}
async function verifyFinishMaterial(page) {

    await page.click(locators.verifyInventoryPage.inventorygroup);
    await page.keyboard.press('Enter');
    await page.waitForTimeout(1000);
    await page.click("//li[normalize-space()='FinishMaterial']");
    const isRoProductVisible = await page.isVisible(locators.verifyInventoryPage.IsRoProduct);
    const inHouseProductVisible = await page.isVisible(locators.verifyInventoryPage.InhouseProduct);
    const inventoryname = await page.isVisible(locators.verifyInventoryPage.InventoryNameField);
    const warranty = await page.isVisible(locators.verifyInventoryPage.warrantyField);
    const unit = await page.isVisible(locators.verifyInventoryPage.unitField);
    const rate = await page.isVisible(locators.verifyInventoryPage.rateField);
    const hsncode = await page.isVisible(locators.verifyInventoryPage.hsncodeField);
    const taxable = await page.isVisible(locators.verifyInventoryPage.taxableField);
    const gst = await page.isVisible(locators.verifyInventoryPage.GSTField);
    const cgst = await page.isVisible(locators.verifyInventoryPage.CGSTField);
    const igst = await page.isVisible(locators.verifyInventoryPage.IGSTField);



    console.log(`IsRoProduct visible: ${isRoProductVisible}`);
    console.log(`InHouseProduct visible: ${inHouseProductVisible}`);
    console.log(`inventoryname visible: ${inventoryname}`);
    console.log(`warranty visible: ${warranty}`);
    console.log(`unit visible: ${unit}`);
    console.log(`rate visible: ${rate}`);
    console.log(`hsncode visible: ${hsncode}`);
    console.log(`taxable visible: ${taxable}`);
    console.log(`gst visible: ${gst}`);
    console.log(`cgst visible: ${cgst}`);
    console.log(`igst visible: ${igst}`);
    await page.waitForTimeout(2000);
}

async function verifyRawMaterial(page) {
    await page.click(locators.verifyInventoryPage.inventorygroup);
    await page.keyboard.press('Enter');
    await page.waitForTimeout(1000);
    await page.click("//li[normalize-space()='RawMaterial']");

    const inventoryname = await page.isVisible(locators.verifyInventoryPage.InventoryNameField);
    const warranty = await page.isVisible(locators.verifyInventoryPage.warrantyField);
    const unit = await page.isVisible(locators.verifyInventoryPage.unitField);
    const rate = await page.isVisible(locators.verifyInventoryPage.rateField);
    const hsncode = await page.isVisible(locators.verifyInventoryPage.hsncodeField);
    const taxable = await page.isVisible(locators.verifyInventoryPage.taxableField);
    const gst = await page.isVisible(locators.verifyInventoryPage.GSTField);
    const cgst = await page.isVisible(locators.verifyInventoryPage.CGSTField);
    const igst = await page.isVisible(locators.verifyInventoryPage.IGSTField);

    console.log(`inventoryname visible: ${inventoryname}`);
    console.log(`warranty visible: ${warranty}`);
    console.log(`unit visible: ${unit}`);
    console.log(`rate visible: ${rate}`);
    console.log(`hsncode visible: ${hsncode}`);
    console.log(`taxable visible: ${taxable}`);
    console.log(`gst visible: ${gst}`);
    console.log(`cgst visible: ${cgst}`);
    console.log(`igst visible: ${igst}`);
    await page.waitForTimeout(1000);
}

async function verifyGeneral(page) {
    await page.click(locators.verifyInventoryPage.inventorygroup);
    await page.keyboard.press('Enter');
    await page.waitForTimeout(1000);
    await page.click("//li[normalize-space()='General']");

    const specialDiscountVisible = await page.isVisible(locators.verifyInventoryPage.specialDiscount);
    const inventoryname = await page.isVisible(locators.verifyInventoryPage.InventoryNameField);
    const warranty = await page.isVisible(locators.verifyInventoryPage.warrantyField);
    const unit = await page.isVisible(locators.verifyInventoryPage.unitField);
    const rate = await page.isVisible(locators.verifyInventoryPage.rateField);
    const hsncode = await page.isVisible(locators.verifyInventoryPage.hsncodeField);
    const taxable = await page.isVisible(locators.verifyInventoryPage.taxableField);

    console.log(`Special Discount visible: ${specialDiscountVisible}`);
    console.log(`Unit value: ${unit}`);
    console.log(`Taxable value: ${taxable}`);
    console.log(`inventoryname visible: ${inventoryname}`);
    console.log(`warranty visible: ${warranty}`);
    console.log(`unit visible: ${unit}`);
    console.log(`rate visible: ${rate}`);
    console.log(`hsncode visible: ${hsncode}`);
    console.log(`taxable visible: ${taxable}`);
    await page.waitForTimeout(1000);
}

async function verifyInventoryGrid(page) {
    const columns = [
        locators.gridinventory.InventoryGroupName,
        locators.gridinventory.InventoryName,
        locators.gridinventory.unit,
        locators.gridinventory.Warranty,
        locators.gridinventory.rate,
        locators.gridinventory.CGST,
        locators.gridinventory.SGST,
        locators.gridinventory.IGST,
        locators.gridinventory.Action,
    ];

    for (const column of columns) {
        const isVisible = await page.isVisible(column);
        console.log(`${column} visible: ${isVisible}`);
    }
}

async function downloadPDF(page) {
    await page.click(locators.verifyInventoryPage.pdfdownload);
    console.log('PDF download triggered.');
}

async function addfinishmaterial(page, Inventory_Name) {
    await page.click(locators.verifyInventoryPage.inventorygroup);
    await page.keyboard.press('Enter');
    await page.waitForTimeout(1000);
    await page.click("//li[normalize-space()='FinishMaterial']");

    // Verify Radio Buttons for Inventory Group
    const isRoProductExists = await page.isVisible(locators.verifyInventoryPage.IsRoProduct);
    await page.waitForTimeout(1000);
    const inhouseProductExists = await page.isVisible(locators.verifyInventoryPage.InhouseProduct);
    await page.waitForTimeout(1000);
    console.log(`IsRoProduct visible: ${isRoProductExists}`);
    console.log(`InHouse Product visible: ${inhouseProductExists}`);

    // Turn on InHouse Product Radio Button
    await page.waitForTimeout(1000);
    await page.click(locators.verifyInventoryPage.InhouseProduct);
    const isRoProductChecked = await page.isChecked(locators.verifyInventoryPage.IsRoProduct);

    console.log(`IsRoProduct automatically on: ${isRoProductChecked}`);

    await page.waitForTimeout(1000);
    await page.click(locators.verifyInventoryPage.inventorygroup);
    await page.keyboard.press('Enter');
    await page.waitForTimeout(1000);
    await page.click("//li[normalize-space()='FinishMaterial']");
    // add inventory
    await page.fill(locators.verifyInventoryPage.InventoryNameField, Inventory_Name);
    await page.click(locators.verifyInventoryPage.unitField);
    await page.waitForTimeout(1000);
    await page.click(locators.verifyInventoryPage.selectPCS);
    await page.waitForTimeout(1000);
    await page.fill(locators.verifyInventoryPage.rateField, "6000");
    await page.fill(locators.verifyInventoryPage.hsncodeField, "451203");
    await page.waitForTimeout(1000);
    const warrantyValue = await page.getAttribute(locators.verifyInventoryPage.warrantyField, "12");
    console.log(`Warranty pre-populated: ${warrantyValue}`);

    await page.click(locators.verifyInventoryPage.savebutton);

    const rows1 = await page.locator('tr[aria-rowindex]'); // Select all rows with aria-rowindex
    const firstRow1 = await rows1.nth(0);
    await firstRow1.locator(locators.gridinventory.InventoryName);
    await expect(firstRow1).toContainText(Inventory_Name);
    console.log("data saved in grid")
    await page.waitForTimeout(1000);

}

async function addinroinventory(page, Inventory_Name) {

    // Verify Radio Button Behavior for IsRoProduct
    await page.click(locators.verifyInventoryPage.inventorygroup);
    await page.keyboard.press('Enter');
    await page.waitForTimeout(1000);
    await page.click("//li[normalize-space()='FinishMaterial']");
    await page.click(locators.verifyInventoryPage.IsRoProduct);

    const isInHouseProductChecked = await page.isDisabled(locators.verifyInventoryPage.InhouseProduct);
    console.log(`InHouse Product automatically off: ${isInHouseProductChecked}`);
    const inentorynameVisible = await page.isVisible(locators.verifyInventoryPage.InventoryNameField);
    const unitVisible = await page.isVisible(locators.verifyInventoryPage.unitField);
    const warrantyVisible = await page.isVisible(locators.verifyInventoryPage.warrantyField);
    const rateVisible = await page.isVisible(locators.verifyInventoryPage.rateField);
    const hsnCodeVisible = await page.isVisible(locators.verifyInventoryPage.hsncodeField);
    const unitDropdownVisible = await page.isVisible(locators.verifyInventoryPage.unitField);
    const taxableDropdownVisible = await page.isVisible(locators.verifyInventoryPage.taxableField);

    console.log(`Warranty visible: ${warrantyVisible}`);
    console.log(`Rate visible: ${rateVisible}`);
    console.log(`HSN Code visible: ${hsnCodeVisible}`);
    console.log(`Unit dropdown visible: ${unitDropdownVisible}`);
    console.log(`Taxable dropdown visible: ${taxableDropdownVisible}`);


    // Test GST/Non GST behavior
    await page.fill(locators.verifyInventoryPage.InventoryNameField, Inventory_Name);
   await page.fill(locators.verifyInventoryPage.warrantyField, "12");
    await page.click(locators.verifyInventoryPage.unitField);
    await page.keyboard.press('Enter');
    await page.click(locators.verifyInventoryPage.selectPCS);
    await page.fill(locators.verifyInventoryPage.rateField, "1000");
    await page.fill(locators.verifyInventoryPage.hsncodeField, "451203");
    await page.click(locators.verifyInventoryPage.taxableField);
    await page.keyboard.press('Enter');
    await page.waitForTimeout(1000);
    await page.click(locators.verifyInventoryPage.selectTaxable);
    await page.click(locators.verifyInventoryPage.GSTField);
    await page.click(locators.verifyInventoryPage.GST);
    await page.waitForTimeout(1000);
    await page.click(locators.verifyInventoryPage.savebutton);
    console.log('Details saved successfully.');

    await page.waitForTimeout(1000);

    await page.click(locators.verifyInventoryPage.taxableField);
    await page.keyboard.press('Enter');
    await page.click(locators.verifyInventoryPage.selectNOnGST);

    const gstNotVisible = await page.isHidden(locators.verifyInventoryPage.GSTField);
    console.log(`GST fields hidden: ${gstNotVisible}`);
    await page.waitForTimeout(1000);



}

async function addinroinventoryNONGSt(page, Inventory_Name) {

    // Verify Radio Button Behavior for IsRoProduct
    await page.click(locators.verifyInventoryPage.inventorygroup);
    await page.keyboard.press('Enter');
    await page.waitForTimeout(1000);
    await page.click("//li[normalize-space()='FinishMaterial']");

    // Test GST/Non GST behavior
    await page.fill(locators.verifyInventoryPage.InventoryNameField, Inventory_Name);
    await page.fill(locators.verifyInventoryPage.warrantyField, "12");
    await page.click(locators.verifyInventoryPage.unitField);
    await page.keyboard.press('Enter');
    await page.click(locators.verifyInventoryPage.selectPCS);
    await page.fill(locators.verifyInventoryPage.rateField, "1000");
    await page.fill(locators.verifyInventoryPage.hsncodeField, "451203");
    await page.click(locators.verifyInventoryPage.taxableField);
    await page.keyboard.press('Enter');
    await page.waitForTimeout(1000);
    await page.click(locators.verifyInventoryPage.selectNOnGST);
    await page.waitForTimeout(2000);
    await page.click(locators.verifyInventoryPage.savebutton);
    console.log('Details saved successfully.');
    await page.waitForTimeout(1000);


}

async function inventorystockreport(page, InventoryRO_Name) {
    await page.click('#InventoryReportopenSideBarButton');
    await page.waitForTimeout(2000);
    console.log("Clicked on the Filter button.");
    await page.locator(locators.inventorystockreport.inventoryselect).click();
    await page.waitForTimeout(2000);
    await page.fill(locators.inventorystockreport.enterInventory, InventoryRO_Name);
    await page.waitForTimeout(3000);
    await page.locator('li.e-list-item', { hasText: InventoryRO_Name }).click();
    await page.waitForTimeout(2000);
    await page.locator(locators.inventorystockreport.inventorysearchbutton).click();
    await page.waitForTimeout(2000);

}

async function selectsubmenu1(page, menu) {
    if (menu == "Transaction") {
        await page.locator(locators.Transactionmenu.salesmodule).click();
        await page.locator(locators.Transactionmenu.sales).click();
        await expect(page.locator('li.breadcrumb-item.active', { hasText: 'Sales' })).toBeVisible();


    }
    else if (menu === "Proforma Sales") {
        await page.locator(locators.Transactionmenu.salesmodule).click();
        await page.locator(locators.Transactionmenu.proformasales).click();
        await expect(page.locator('li.breadcrumb-item.active', { hasText: 'Proforma Sales' })).toBeVisible();
    }

}

async function selectsubmenu2(page, menu) {
    if (menu == "Transaction") {
        await page.locator(locators.Transactionmenu.salesmodule).click();
        await page.locator(locators.Transactionmenu.salesreturn).click();
        await expect(page.locator('li.breadcrumb-item.active', { hasText: 'Sales Return' })).toBeVisible();


    }

}



async function checkinventorySalespage(page, customer, broker, inventorygroup, item) {
    //sales page SAC
    const Addnewsales = await page.locator(locators.SAC.Addnewsales);
    await expect(Addnewsales).toBeVisible();
    await page.locator(locators.SAC.Addnewsales).click();
    await page.waitForTimeout(1000);
    await page.locator(locators.SAC.customerdropdown).click();
    await page.fill(locators.SAC.entercustomername, customer);
    await page.locator('td.customerdropdown1', { hasText: customer }).click();
    await page.waitForTimeout(1000);
    await page.locator(locators.SAC.brokerdropdown).click();
    await page.fill(locators.SAC.entercustomername, broker);
    await page.waitForTimeout(1000);
    await page.locator('li.e-list-item', { hasText: broker }).click();
    await page.locator(locators.SAC.addinventoryonsalesdetails).click();
    await page.waitForTimeout(1000);
    await page.locator(locators.SAC.selectinventorygroup).click();
    await page.waitForTimeout(1000); //Click on Inventory Group
    if (inventorygroup == "FinishMaterial") {
        await page.click(locators.SAC.selectfinishmaterial);
    }
    else if (inventorygroup == "RawMaterial") {
        await page.click(locators.SAC.selectrawmaterial);
    }
    await page.waitForTimeout(1000);
    await page.locator('td.e-rowcell.e-lastrowcell.e-updatedtd.e-selectionbackground.e-active[aria-label=" Column Header Item"]').click();
    await page.locator(locators.SAC.inventoryitem).click();
    await page.waitForTimeout(3000);
    await page.locator('li.e-list-item', { hasText: item }).click();
    await page.waitForTimeout(2000);





}
async function checkinventorySalesReturnpage(page, inventorygroup, item) {

    // SAC - sales return page
    const Addnewsalesreturn = await page.locator(locators.SAC.salesreturnaAdd);
    await expect(Addnewsalesreturn).toBeVisible();
    await page.locator(locators.SAC.salesreturnaAdd).click();
    await page.waitForTimeout(1000);
    await page.locator(locators.SAC.salesreturnadddetails).click();
    await page.click(locators.SAC.inventorygroupsalesreturn);
    if (inventorygroup == "FinishMaterial") {
        await page.click(locators.SAC.selectfinishmaterial);
    }
    else if (inventorygroup == "RawMaterial") {
        await page.waitForTimeout(1000);
        await page.click(locators.SAC.selectrawmaterial);
    }
    await page.waitForTimeout(3000);
    await page.locator('td.e-rowcell.e-lastrowcell.e-updatedtd.e-selectionbackground.e-active[aria-label=" Column Header Item"]').click();
    await page.waitForTimeout(2000);
    await page.locator(locators.SAC.selectitem).click();
    await page.waitForTimeout(1000);
    await page.fill(locators.SAC.entercustomername, item);
    await page.waitForTimeout(2000);
    await page.locator('li.e-list-item', { hasText: item }).click();
    await page.waitForTimeout(2000);





}

async function checkinventoryProformasalespage(page, inventorygroup, item) {

    await page.locator(locators.Transactionmenu.salesmodule).click();
    await page.locator(locators.Transactionmenu.proformasales).click();
    await expect(page.locator('li.breadcrumb-item.active', { hasText: 'Proforma Sales' })).toBeVisible();
    const Addnewsalesreturn = await page.locator(locators.SAC.proformasalesaddnew);
    await expect(Addnewsalesreturn).toBeVisible();
    await page.locator(locators.SAC.proformasalesaddnew).click();
    await page.waitForTimeout(2000);
    await page.locator(locators.SAC.addproformasales).click();
    await page.click(locators.SAC.selectioninventroyproforma);
    await page.waitForTimeout(1000);
    if (inventorygroup == "FinishMaterial") {
        await page.click(locators.SAC.selectfinishmaterial);
    }
    else if (inventorygroup == "RawMaterial") {
        await page.click(locators.SAC.selectrawmaterial);
    }

    await page.locator('td.e-rowcell.e-lastrowcell.e-updatedtd.e-selectionbackground.e-active[aria-label=" Column Header Item"]').click();
   
    await page.locator(locators.SAC.selectionitemproforma).click();
    await page.fill(locators.SAC.entercustomername, item);
    await page.waitForTimeout(1000);
    await page.locator('li.e-list-item', { hasText: item }).click();
    await page.waitForTimeout(2000);





}

async function checkinventoryPurchasepage(page, inventorygroup, item) {

    await page.locator(locators.Transactionmenu.purchase).click();
    await page.locator(locators.Transactionmenu.purchasentry).click();
    await expect(page.locator('li.breadcrumb-item.active', { hasText: 'Purchase Register' })).toBeVisible();
    const Addnewsalesreturn = await page.locator(locators.SAC.purchaseadd);
    await expect(Addnewsalesreturn).toBeVisible();
    await page.locator(locators.SAC.purchaseadd).click();
    await page.waitForTimeout(1000);
    await page.locator(locators.SAC.purchasedetailadd).click();
    await page.waitForTimeout(2000);
    await page.click(locators.SAC.selectinventorypurchase);
    await page.waitForTimeout(2000);
    if (inventorygroup == "FinishMaterial") {
        await page.click(locators.SAC.selectfinishmaterial);
    }
    else if (inventorygroup == "RawMaterial") {
        await page.click(locators.SAC.selectrawmaterial);
    }

    await page.locator('td.e-rowcell.e-lastrowcell.e-updatedtd.e-selectionbackground.e-active[aria-label=" Column Header Item"]').click();
    await page.waitForTimeout(1000);
    await page.locator(locators.SAC.selectitempurchase).click();
    await page.fill(locators.SAC.entercustomername, item);
    await page.waitForTimeout(2000);
    await page.locator('li.e-list-item', { hasText: item }).click();

}

async function checkinventoryPurchasereturnpage(page, inventorygroup, item) {

    await page.locator(locators.Transactionmenu.purchase).click();
    await page.locator(locators.Transactionmenu.purchasereturn).click();
    // await expect(page.locator('li.breadcrumb-item.active', { hasText: 'Purchase Return Register' })).toBeVisible();
    const Addnewsalesreturn = await page.locator(locators.SAC.purchasereturnadd);
    await expect(Addnewsalesreturn).toBeVisible();
    await page.locator(locators.SAC.purchasereturnadd).click();
    await page.waitForTimeout(1000);
    await page.locator(locators.SAC.purchasereturndeatiladd).click();
    await page.click(locators.SAC.selectinvetorypurchasereturn);
    await page.waitForTimeout(1000);
    if (inventorygroup == "FinishMaterial") {
        await page.click(locators.SAC.selectfinishmaterial);
    }
    else if (inventorygroup == "RawMaterial") {
        await page.click(locators.SAC.selectrawmaterial);
    }
    await page.waitForTimeout(1000);
    await page.locator('td.e-rowcell.e-lastrowcell.e-updatedtd.e-selectionbackground.e-active[aria-label=" Column Header Item"]').click();
    await page.waitForTimeout(1000);
    await page.locator(locators.SAC.selectitempurchasereturn).click();
    await page.fill(locators.SAC.entercustomername, item);
    await page.locator('li.e-list-item', { hasText: item }).click();

}

async function checkinventoryAMcwithgstpage(page, product) {

    await page.locator(locators.Transactionmenu.tmenu).click();
    await page.locator(locators.Transactionmenu.amcwithgst).click();
    // await expect(page.locator('li.breadcrumb-item.active', { hasText: 'Purchase Return Register' })).toBeVisible();
    const Addnewsalesreturn = await page.locator(locators.SAC.Amcwithgstadd);
    await expect(Addnewsalesreturn).toBeVisible();
    await page.locator(locators.SAC.Amcwithgstadd).click();
    await page.waitForTimeout(1000);
    const dropdown = page.locator('span.e-ddl.e-lib.e-input-group.e-control-container.e-control-wrapper.CommonInvenotoryDropdownList').nth(0); // Adjust the index as needed
    await dropdown.click();
    await page.waitForTimeout(1000);
    await page.fill(locators.SAC.entercustomername, product);
    await page.locator('li.e-list-item', { hasText: product }).click();

}

async function checkinventoryserviceticketpage(page, product) {

    await page.locator(locators.Archie.Service).click();
    await page.locator(locators.Archie.serviceticketpage).click();
    // await expect(page.locator('li.breadcrumb-item.active', { hasText: 'Purchase Return Register' })).toBeVisible();
    const Addnewserviceticket = await page.locator(locators.Archie.serviceticketadd);
    await expect(Addnewserviceticket).toBeVisible();
    await page.locator(locators.Archie.serviceticketadd).click();
    const dropdown = page.locator('span.e-ddl.e-lib.e-input-group.e-control-container.e-control-wrapper.CommonInvenotoryDropdownList').nth(0); // Adjust the index as needed
    await dropdown.click();
    await page.fill(locators.SAC.entercustomername, product);
    await page.locator('li.e-list-item', { hasText: product }).click();

}

async function checkinventoryamcinvoicepage(page, product) {

    await page.locator(locators.Archie.Service).click();
    await page.locator(locators.Archie.amcinvoicepage).click();
    // await expect(page.locator('li.breadcrumb-item.active', { hasText: 'Purchase Return Register' })).toBeVisible();
    const Addnewamcinvoice = await page.locator(locators.Archie.Amcinvoiceadd);
    await expect(Addnewamcinvoice).toBeVisible();
    await page.locator(locators.Archie.Amcinvoiceadd).click();
    await page.waitForTimeout(1000);
    const dropdown = page.locator('span.e-ddl.e-lib.e-input-group.e-control-container.e-control-wrapper.CommonInvenotoryDropdownList').nth(0); // Adjust the index as needed
    await dropdown.click();
    await page.fill(locators.SAC.entercustomername, product);
    await page.locator('li.e-list-item', { hasText: product }).click();

}

async function checkinventorydirecthufpage(page, inventorygroup, item) {

    await page.locator(locators.Transactionmenu.salesmodule).click();
    await page.locator(locators.KBT.Dhufsale).click();
    // await expect(page.locator('li.breadcrumb-item.active', { hasText: 'Purchase Return Register' })).toBeVisible();
    const Addnewamcinvoice = await page.locator(locators.KBT.DHufadd);
    await expect(Addnewamcinvoice).toBeVisible();
    await page.locator(locators.KBT.DHufadd).click();
    await page.waitForTimeout(1000);
    await page.locator(locators.KBT.gridAdd).click();
    await page.waitForTimeout(500);
    await page.click(locators.KBT.selectinventorygrp);
    await page.waitForTimeout(1000);
    if (inventorygroup == "FinishMaterial") {
        await page.click(locators.SAC.selectfinishmaterial);
    }
    else if (inventorygroup == "RawMaterial") {
        await page.click(locators.SAC.selectrawmaterial);
    }

    await page.locator('td.e-rowcell.e-lastrowcell.e-updatedtd.e-selectionbackground.e-active[aria-label=" Column Header Item"]').click();
    await page.waitForTimeout(1000);
    await page.locator(locators.KBT.selectitemdhuf).click();
    await page.fill(locators.SAC.entercustomername, item);
    await page.waitForTimeout(1000);
    await page.locator('li.e-list-item', { hasText: item }).click();

}

async function checkinventoryhufpage(page, inventorygroup, item) {

    await page.locator(locators.Transactionmenu.salesmodule).click();
    await page.locator(locators.cashonly.hufcyclesale).click();
    // await expect(page.locator('li.breadcrumb-item.active', { hasText: 'Purchase Return Register' })).toBeVisible();
    const Addnewamcinvoice = await page.locator(locators.cashonly.addnewhuf);
    await expect(Addnewamcinvoice).toBeVisible();
    await page.locator(locators.cashonly.addnewhuf).click();
    await page.waitForTimeout(1000);
    await page.locator(locators.cashonly.gridaddhuf).click();
    await page.waitForTimeout(500);
    await page.click(locators.cashonly.selectinventoryhuf);
    await page.waitForTimeout(1000);
    if (inventorygroup == "FinishMaterial") {
        await page.click(locators.SAC.selectfinishmaterial);
    }
    else if (inventorygroup == "RawMaterial") {
        await page.click(locators.SAC.selectrawmaterial);
    }

    await page.locator('td.e-rowcell.e-lastrowcell.e-updatedtd.e-selectionbackground.e-active[aria-label=" Column Header Item"]').click();
    await page.waitForTimeout(1000);   
    await page.locator(locators.cashonly.selectitemhufsale).click();
    await page.fill(locators.SAC.entercustomername, item);
    await page.waitForTimeout(1000);
    await page.locator('li.e-list-item', { hasText: item }).click();

}

async function checkinventorysalescashpage(page, inventorygroup, item) {

    await page.locator(locators.Transactionmenu.salesmodule).click();
    await page.locator(locators.Transactionmenu.sales).click();
    // await expect(page.locator('li.breadcrumb-item.active', { hasText: 'Purchase Return Register' })).toBeVisible();
    const Addnewamcinvoice = await page.locator(locators.cashonly.salesAddnew);
    await expect(Addnewamcinvoice).toBeVisible();
    await page.locator(locators.cashonly.salesAddnew).click();
    await page.waitForTimeout(1000);
    await page.locator(locators.cashonly.salesgrid).click();
    await page.waitForTimeout(1000);
    await page.click(locators.cashonly.selectinventoryGroupsales);
    await page.waitForTimeout(1000);
    if (inventorygroup == "FinishMaterial") {
        await page.click(locators.SAC.selectfinishmaterial);
    }
    else if (inventorygroup == "RawMaterial") {
        await page.click(locators.SAC.selectrawmaterial);
    }

    await page.locator('td.e-rowcell.e-lastrowcell.e-updatedtd.e-selectionbackground.e-active[aria-label=" Column Header Item"]').click();
    await page.waitForTimeout(1000);
    await page.locator(locators.cashonly.selectitemsales).click();
    await page.fill(locators.SAC.entercustomername, item);
    await page.waitForTimeout(1000);
    await page.locator('li.e-list-item', { hasText: item }).click();
    await page.waitForTimeout(1000);

}

async function checkinventoryPurchasecashpage(page, inventorygroup, item) {

    await page.locator(locators.Transactionmenu.purchase).click();
    await page.locator(locators.Transactionmenu.purchasentry).click();
    // await expect(page.locator('li.breadcrumb-item.active', { hasText: 'Purchase Return Register' })).toBeVisible();
    const Addnewamcinvoice = await page.locator(locators.SAC.purchaseadd);
    await expect(Addnewamcinvoice).toBeVisible();
    await page.locator(locators.SAC.purchaseadd).click();
    await page.waitForTimeout(1000);
    await page.locator(locators.SAC.purchasedetailadd).click();
    await page.waitForTimeout(2000);
    await page.click(locators.SAC.selectinventorypurchase);
    if (inventorygroup == "FinishMaterial") {
        await page.click(locators.SAC.selectfinishmaterial);
    }
    else if (inventorygroup == "RawMaterial") {
        await page.click(locators.SAC.selectrawmaterial);
    }

    await page.locator('td.e-rowcell.e-lastrowcell.e-updatedtd.e-selectionbackground.e-active[aria-label=" Column Header Item"]').click();
    await page.waitForTimeout(1000);
    await page.locator(locators.SAC.selectitempurchase).click();
    await page.fill(locators.SAC.entercustomername, item);
    await page.waitForTimeout(1000);
    await page.locator('li.e-list-item', { hasText: item }).click();
    await page.waitForTimeout(1000);

}
async function updateinventory(page, update_inventory) {

    const rows = await page.locator('tr[aria-rowindex]'); // Select all rows with aria-rowindex
    const firstRow = await rows.nth(0); // Select the first row
    await firstRow.locator(locators.editinventory.editbutton).click();
    await page.waitForTimeout(1000);


    const inventoryGroupDropdown = page.locator(locators.verifyInventoryPage.disableinventory);
    const taxableDropdown = page.locator(locators.verifyInventoryPage.inventorytaxable);

    console.log(`Inventory dropdown Distable: ${inventoryGroupDropdown}`);
    console.log(`taxable dropdown Disable : ${taxableDropdown}`);



    const editableField1 = page.locator(locators.verifyInventoryPage.InventoryNameField);
    const editableField2 = page.locator(locators.verifyInventoryPage.warrantyField);

    await editableField1.fill(update_inventory);
    await editableField2.fill('5');


    await page.locator(locators.editinventory.updatebutton).click();

    // Wait for the grid to update
    await page.waitForTimeout(1000);


    const rows1 = await page.locator('tr[aria-rowindex]'); // Select all rows with aria-rowindex
    const firstRow1 = await rows1.nth(0);
    await firstRow1.locator(locators.gridinventory.InventoryName);
    await expect(firstRow1).toContainText(update_inventory);

}

async function addRawinroinventory(page, Raw_inventory) {

    // Verify Radio Button Behavior for IsRoProduct
    await page.click(locators.verifyInventoryPage.inventorygroup);
    await page.keyboard.press('Enter');
    await page.waitForTimeout(1000);
    await page.click("//li[normalize-space()='RawMaterial']");



    // Test GST/Non GST behavior
    await page.fill(locators.verifyInventoryPage.InventoryNameField, Raw_inventory);
     await page.fill(locators.verifyInventoryPage.warrantyField, "12");
    await page.click(locators.verifyInventoryPage.unitField);
    await page.click(locators.verifyInventoryPage.selectPCS);
    await page.fill(locators.verifyInventoryPage.rateField, "6000");
    await page.fill(locators.verifyInventoryPage.hsncodeField, "789456");
    await page.click(locators.verifyInventoryPage.taxableField);
    await page.click(locators.verifyInventoryPage.selectTaxable);
    await page.click(locators.verifyInventoryPage.GSTField);
    await page.click(locators.verifyInventoryPage.GST);
    await page.waitForTimeout(1000);
    await page.click(locators.verifyInventoryPage.savebutton);
    console.log('Details saved successfully.');

    await page.waitForTimeout(1000);

    const rows1 = await page.locator('tr[aria-rowindex]'); // Select all rows with aria-rowindex
    const firstRow1 = await rows1.nth(0);
    await firstRow1.locator(locators.gridinventory.InventoryName);
    await expect(firstRow1).toContainText(Raw_inventory);



}

async function addRawinroinventoryNONGST(page, NonGST_Raw_Inventory) {

    // Verify Radio Button Behavior for IsRoProduct
    await page.click(locators.verifyInventoryPage.inventorygroup);
    await page.keyboard.press('Enter');
    await page.waitForTimeout(1000);
    await page.click("//li[normalize-space()='RawMaterial']");



    // Test GST/Non GST behavior
    await page.fill(locators.verifyInventoryPage.InventoryNameField, NonGST_Raw_Inventory);
    await page.waitForTimeout(2000);
    await page.fill(locators.verifyInventoryPage.warrantyField, "5");
    await page.waitForTimeout(2000);
    await page.click(locators.verifyInventoryPage.unitField);
    await page.waitForTimeout(2000);
    await page.click(locators.verifyInventoryPage.selectPCS);
    await page.waitForTimeout(2000);
    await page.fill(locators.verifyInventoryPage.rateField, "7000");
    await page.waitForTimeout(2000);
    await page.fill(locators.verifyInventoryPage.hsncodeField, "789246");
    await page.waitForTimeout(2000);
    await page.click(locators.verifyInventoryPage.taxableField);
    await page.keyboard.press('Enter');
    await page.waitForTimeout(1000);
    await page.click(locators.verifyInventoryPage.selectNOnGST);

    await page.waitForTimeout(1000);
    await page.click(locators.verifyInventoryPage.savebutton);
    await page.waitForTimeout(2000);
    console.log('Details saved successfully.');

    await page.waitForTimeout(1000);

    const rows1 = await page.locator('tr[aria-rowindex]'); // Select all rows with aria-rowindex
    const firstRow1 = await rows1.nth(0);
    await firstRow1.locator(locators.gridinventory.InventoryName);
    await page.waitForTimeout(2000);
    await expect(firstRow1).toContainText(NonGST_Raw_Inventory);



}
async function checkinventoryAMcwithgstpageforRaw(page, item) {

    await page.locator(locators.Transactionmenu.tmenu).click();
    await page.locator(locators.Transactionmenu.amcwithgst).click();
    // await expect(page.locator('li.breadcrumb-item.active', { hasText: 'Purchase Return Register' })).toBeVisible();
    const Addnewsalesreturn = await page.locator(locators.SAC.Amcwithgstadd);
    await expect(Addnewsalesreturn).toBeVisible();
    await page.locator(locators.SAC.Amcwithgstadd).click();
    await page.waitForTimeout(1000);
    await page.locator(locators.SAC.amcwithgstaddIdetail).click();
    await page.waitForTimeout(1000);
    await page.click(locators.SAC.addinventoryamc);
    await page.fill(locators.SAC.entercustomername, item);
    await page.waitForTimeout(1000);
    await page.locator('li.e-list-item', { hasText: item }).click();
    await page.waitForTimeout(1000);




}

async function checkinventoryserviceticketpageraw(page, item) {

    await page.locator(locators.Archie.Service).click();
    await page.locator(locators.Archie.serviceticketpage).click();
    // await expect(page.locator('li.breadcrumb-item.active', { hasText: 'Purchase Return Register' })).toBeVisible();
    const Addnewserviceticket = await page.locator(locators.Archie.serviceticketadd);
    await expect(Addnewserviceticket).toBeVisible();
    await page.locator(locators.Archie.serviceticketadd).click();
    await page.waitForTimeout(1000);
    await page.locator(locators.SAC.foraddserviceticket).click();
    await page.waitForTimeout(1000);
    await page.click(locators.SAC.itemselect);

    await page.fill(locators.SAC.entercustomername, item);
    await page.waitForTimeout(1000);
    await page.locator('li.e-list-item', { hasText: item }).click();
    await page.waitForTimeout(1000);


}

async function checkinventoryamcinvoicepageraw(page, item) {

    await page.locator(locators.Archie.Service).click();
    await page.locator(locators.Archie.amcinvoicepage).click();
    await page.waitForTimeout(1000);
    // await expect(page.locator('li.breadcrumb-item.active', { hasText: 'Purchase Return Register' })).toBeVisible();
    const Addnewamcinvoice = await page.locator(locators.Archie.Amcinvoiceadd);
    await page.waitForTimeout(1000);
    await expect(Addnewamcinvoice).toBeVisible();
    await page.locator(locators.Archie.Amcinvoiceadd).click();
    await page.waitForTimeout(1000);
    await page.locator(locators.SAC.amcinvoiceadd).click();
    await page.waitForTimeout(1000);
    await page.click(locators.SAC.addinventoryamc);
    await page.fill(locators.SAC.entercustomername, item);
    await page.waitForTimeout(1000);
    await page.locator('li.e-list-item', { hasText: item }).click();
    await page.waitForTimeout(1000);





}

async function inventorystockreportraw(page, inventoryName) {
    await page.click('#InventoryReportopenSideBarButton');
    console.log("Clicked on the Filter button.");
    await page.locator(locators.inventorystockreport.inventoryselect).click();
    await page.fill(locators.inventorystockreport.enterInventory, inventoryName);
    await page.waitForTimeout(1000);
    await page.locator('li.e-list-item', { hasText: inventoryName }).click();
    await page.waitForTimeout(1000);
    await page.locator(locators.inventorystockreport.inventorysearchbutton).click();

    await page.waitForTimeout(1000);


}

async function updateinventoryforRaw(page, UpdateRaw_Inventory) {

    const rows = await page.locator('tr[aria-rowindex]'); // Select all rows with aria-rowindex
    const firstRow = await rows.nth(0); // Select the first row
    await firstRow.locator(locators.editinventory.editbutton).click();
    await page.waitForTimeout(1000);


    const inventoryGroupDropdown = page.locator(locators.verifyInventoryPage.disableinventory);
    const taxableDropdown = page.locator(locators.verifyInventoryPage.inventorytaxable);

    console.log(`Inventory dropdown Distable: ${inventoryGroupDropdown}`);
    console.log(`taxable dropdown Disable : ${taxableDropdown}`);



    const editableField1 = page.locator(locators.verifyInventoryPage.InventoryNameField);
    const editableField2 = page.locator(locators.verifyInventoryPage.warrantyField);

    await editableField1.fill(UpdateRaw_Inventory);
    await editableField2.fill('8');


    await page.locator(locators.editinventory.updatebutton).click();

    // Wait for the grid to update
    await page.waitForTimeout(1000);


    const rows1 = await page.locator('tr[aria-rowindex]'); // Select all rows with aria-rowindex
    const firstRow1 = await rows1.nth(0);
    await firstRow1.locator(locators.gridinventory.InventoryName);
    await expect(firstRow1).toContainText(UpdateRaw_Inventory);

}

//general material
async function addinroinventorygeneral(page, General_Inventory) {

    // Verify Radio Button Behavior for IsRoProduct
    await page.click(locators.verifyInventoryPage.inventorygroup);
    await page.keyboard.press('Enter');
    await page.waitForTimeout(1000);
    await page.click("//li[normalize-space()='General']");
    await page.click(locators.verifyInventoryPage.specialDiscount);

    const unit = await page.isDisabled(locators.verifyInventoryPage.unitField);
    console.log(`unit is disable: ${unit}`);
    const taxableDropdownVisible = await page.isDisabled(locators.verifyInventoryPage.taxableField);
    console.log(`taxable is disable: ${taxableDropdownVisible}`);
    const inentorynameVisible = await page.isVisible(locators.verifyInventoryPage.InventoryNameField);
    const hsnCodeVisible = await page.isVisible(locators.verifyInventoryPage.hsncodeField);
    const gst = await page.isDisabled(locators.verifyInventoryPage.GSTField);
    const cgst = await page.isDisabled(locators.verifyInventoryPage.CGSTField);
    const sgst = await page.isDisabled(locators.verifyInventoryPage.SGSTField);
    const igst = await page.isDisabled(locators.verifyInventoryPage.IGSTField);



    console.log(`name visible: ${inentorynameVisible}`);
    console.log(`HSN Code visible: ${hsnCodeVisible}`);
    console.log(`gst visible: ${gst}`);
    console.log(`cgst visible: ${cgst}`);
    console.log(`sgst visible: ${sgst}`);
    console.log(`igst visible: ${igst}`);




    // Test GST/Non GST behavior
    await page.fill(locators.verifyInventoryPage.InventoryNameField, General_Inventory);
    await page.waitForTimeout(1000);
    await page.fill(locators.verifyInventoryPage.hsncodeField, "456203");
    await page.waitForTimeout(1000);
    await page.click(locators.verifyInventoryPage.savebutton);
    console.log('Details saved successfully.');

    await page.waitForTimeout(1000);

    const rows1 = await page.locator('tr[aria-rowindex]'); // Select all rows with aria-rowindex
    const firstRow1 = await rows1.nth(0);
    await firstRow1.locator(locators.gridinventory.InventoryName);
    await page.waitForTimeout(2000);
    await expect(firstRow1).toContainText(General_Inventory);
    await page.waitForTimeout(2000);




}

async function addinroinventorygeneralwithoutdiscount(page, NoDiscount_Inventory) {

    // Verify Radio Button Behavior for IsRoProduct
    await page.click(locators.verifyInventoryPage.inventorygroup);
    await page.keyboard.press('Enter');
    await page.waitForTimeout(1000);
    await page.click("//li[normalize-space()='General']");

    const specialDiscount = await page.isVisible(locators.verifyInventoryPage.specialDiscount);
    const unit = await page.isDisabled(locators.verifyInventoryPage.unitField);
    console.log(`unit is disable: ${unit}`);
    const taxableDropdownVisible = await page.isDisabled(locators.verifyInventoryPage.taxableField);
    console.log(`taxable is disable: ${taxableDropdownVisible}`);
    const inentorynameVisible = await page.isVisible(locators.verifyInventoryPage.InventoryNameField);
    const warrantyVisible = await page.isVisible(locators.verifyInventoryPage.warrantyField);
    const rateVisible = await page.isVisible(locators.verifyInventoryPage.rateField);
    const hsnCodeVisible = await page.isVisible(locators.verifyInventoryPage.hsncodeField);

    console.log(`special discount visible: ${specialDiscount}`);
    console.log(`name visible: ${inentorynameVisible}`);
    console.log(`Warranty visible: ${warrantyVisible}`);
    console.log(`Rate visible: ${rateVisible}`);
    console.log(`HSN Code visible: ${hsnCodeVisible}`);




    // Test GST/Non GST behavior
    await page.fill(locators.verifyInventoryPage.InventoryNameField, NoDiscount_Inventory);
    await page.waitForTimeout(1000);
    await page.fill(locators.verifyInventoryPage.warrantyField, "2");
    await page.waitForTimeout(1000);
    await page.fill(locators.verifyInventoryPage.rateField, "2000");
    await page.waitForTimeout(1000);
    await page.fill(locators.verifyInventoryPage.hsncodeField, "456203");
    await page.waitForTimeout(1000);
    await page.click(locators.verifyInventoryPage.savebutton);
    console.log('Details saved successfully.');

    await page.waitForTimeout(1000);

    const rows1 = await page.locator('tr[aria-rowindex]'); // Select all rows with aria-rowindex
    const firstRow1 = await rows1.nth(0);
    await firstRow1.locator(locators.gridinventory.InventoryName);
    await page.waitForTimeout(2000);
    await expect(firstRow1).toContainText(NoDiscount_Inventory);
    await page.waitForTimeout(2000);




}

async function Checkinventorycreditnote(page, item) {

    await page.locator(locators.creditnote).click();
    await expect(page.locator('li.breadcrumb-item.active', { hasText: 'Credit Note' })).toBeVisible();
    const Addnewserviceticket = await page.locator(locators.creditadd);
    await expect(Addnewserviceticket).toBeVisible();
    await page.locator(locators.creditadd).click();
    await page.click(locators.particular);
    await page.fill(locators.SAC.entercustomername, item);
    await page.waitForTimeout(1000);
    await page.locator('li.e-list-item', { hasText: item }).click();
    await page.waitForTimeout(1000);




}
async function Checkinventorydebitnote(page, item) {
    await page.locator(locators.Transactionmenu.tmenu).click();
    await page.locator(locators.debitnote).click();
    await expect(page.locator('li.breadcrumb-item.active', { hasText: 'Debit Note' })).toBeVisible();
    const Addnewserviceticket = await page.locator(locators.debitadd);
    await expect(Addnewserviceticket).toBeVisible();
    await page.locator(locators.debitadd).click();
    await page.click(locators.particulardebit);
    await page.fill(locators.SAC.entercustomername, item);
    await page.waitForTimeout(1000);
    await page.locator('li.e-list-item', { hasText: item }).click();
    await page.waitForTimeout(1000);




}

async function updateinventoryforGeneral(page, Update_General) {

    const rows = await page.locator('tr[aria-rowindex]'); // Select all rows with aria-rowindex
    const firstRow = await rows.nth(0); // Select the first row
    await firstRow.locator(locators.editinventory.editbutton).click();
    await page.waitForTimeout(1000);

    const inventoryGroupDropdown = page.locator(locators.verifyInventoryPage.disableinventory);
    console.log(`Inventory dropdown Distable: ${inventoryGroupDropdown}`);
    const editableField1 = page.locator(locators.verifyInventoryPage.InventoryNameField);
    const editableField2 = page.locator(locators.verifyInventoryPage.warrantyField);
    await editableField1.fill(Update_General);
    await editableField2.fill('8');
    await page.locator(locators.editinventory.updatebutton).click();
    // Wait for the grid to update
    await page.waitForTimeout(1000);
    const rows1 = await page.locator('tr[aria-rowindex]'); // Select all rows with aria-rowindex
    const firstRow1 = await rows1.nth(0);
    await firstRow1.locator(locators.gridinventory.InventoryName);
    await expect(firstRow1).toContainText(Update_General);

}










module.exports = {addinroinventoryNONGSt,
    selectsubmenuinventory, verifyInventoryEntrySection, verifyFinishMaterial,
    verifyRawMaterial, verifyGeneral, verifyInventoryGrid,
    downloadPDF, addfinishmaterial, inventorystockreport, checkinventorySalespage,
    addinroinventory, selectsubmenu1, selectsubmenu2, checkinventorySalesReturnpage,
    checkinventoryAMcwithgstpage, checkinventoryPurchasepage,
    checkinventoryProformasalespage, checkinventoryPurchasereturnpage,
    checkinventoryserviceticketpage, checkinventoryamcinvoicepage, checkinventorydirecthufpage,
    checkinventoryhufpage, checkinventorysalescashpage, checkinventoryPurchasecashpage, updateinventory,
    addRawinroinventory, addRawinroinventoryNONGST, checkinventoryAMcwithgstpageforRaw,
    checkinventoryamcinvoicepageraw,
    checkinventoryserviceticketpageraw, inventorystockreportraw,
    updateinventoryforRaw, addinroinventorygeneral, addinroinventorygeneralwithoutdiscount,
    Checkinventorycreditnote, Checkinventorydebitnote, updateinventoryforGeneral
};