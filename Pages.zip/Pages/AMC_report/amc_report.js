const { test, expect } = require('@playwright/test');
const locators = require('./amc_report.json');
const { TIMEOUT } = require('dns');
const fs = require('fs');


async function selectsubmenuofamc(page,menu) {
    
        if (menu == "Reports") {
            await page.locator(locators.reports_menu.reports).click();
            await page.locator(locators.reports_menu.amc_menu).click();
            await expect(page.locator('li.breadcrumb-item.active', { hasText: 'GST AMC Invoice Report' })).toBeVisible();
    
        }
}

async function selectfilterResetamc(page, customername ,date ) {

    const backButton = page.locator('button:has-text("Back")');
    const pdfExportButton = page.locator('button:has-text("PDF Export")');
    const filterButton = page.locator('button:has-text("Filter")');
    
    await expect(backButton).toBeVisible();
    await expect(pdfExportButton).toBeVisible();
    await expect(filterButton).toBeVisible();

      const button2 = await page.locator('span.e-ungroupbutton[title="Ungroup by this column"]');
      await button2.click();
  
      console.log(' Back, PDF Export, and Filter buttons are visible');
  
      await page.locator(locators.amc_report.amc_filter).click();
  
      await page.locator(locators.customerdropdown).click();
      await page.fill(locators.entercustomername, customername);
      await page.waitForTimeout(1000);
      
      const datepicker = '#CustomerGSTAMCReportDatePickerForFilter'; //code to clear the date
      await page.fill(datepicker, ''); //code to clear the date
      await page.fill(datepicker, date); //code to enter current data
      await page.locator(locators.amc_report.amc_reset).click();
      await page.waitForTimeout(1000);
      await page.locator(locators.amc_report.amc_close).click();
  
  
  }
  
  
  async function selectfilteramc(page, customername ) {
    await page.locator(locators.amc_report.amc_filter).click();
  
      //await page.locator(locators.Itemwise_report.Itemwise_Filter).click();
      
      await page.locator(locators.customerdropdown).click();
      await page.fill(locators.entercustomername, customername);
      await page.locator('li.e-list-item', { hasText: customername }).click();
      await page.waitForTimeout(3000);

      await page.locator(locators.amc_report.amc_status).nth(1).click();
      await page.waitForTimeout(1000);
    
      await page.locator(locators.amc_report.amc_search).click();
      await page.waitForTimeout(1000);
  
      await page.locator(locators.amc_report.amc_back).click();
      await page.waitForTimeout(1000);
  
      await page.locator(locators.amc_report.amc_pdf).click();
      await page.waitForTimeout(1000);
  
  
  }


  async function sortingamc(page) {
    await page.locator(locators.Invoice_no).click();
    // await page.waitForTimeout(1000);
     console.log(" The report is sorted by Bill No in assending order");
     await page.waitForTimeout(1000);
     await page.locator(locators.Invoice_no).click();
     //await page.waitForTimeout(1000);
     console.log(" The report is sorted by Bill No in descending order");
  }

module.exports = { selectsubmenuofamc,selectfilterResetamc,selectfilteramc,sortingamc }
