const { test, expect } = require('@playwright/test');
const locators = require('./bank.json');
const { TIMEOUT } = require('dns');
const fs = require('fs');


async function Bank_Entry_Selection(page, menu) {
    if (menu == "Master") {
        await page.locator(locators.bank_menu.mastermaunu).click();
        await page.waitForTimeout(1000);
        await page.locator(locators.bank_menu.bankmenu).click();
        await page.waitForTimeout(1000);
        await expect(page.locator('li.breadcrumb-item.active', { hasText: 'Bank' })).toBeVisible();
        //await page.waitForTimeout(1000);
    }
}


async function verifybank(page, bank) {

    await page.locator(locators.Verify_bank.bank_name).fill(bank.bank_name || '');
    await page.waitForTimeout(1000);

    await page.locator(locators.Verify_bank.bank_save).click();
    await page.waitForTimeout(1000);

    await page.locator(locators.Verify_bank.bank_name).fill(bank.bank_name || '');
    await page.waitForTimeout(1000);

    await page.locator(locators.Verify_bank.bank_reset).click();
    await page.waitForTimeout(1000);

    await page.locator(locators.Verify_bank.bank_pdf).click();
    await page.waitForTimeout(1000);

    let Pagination = await page.locator("//div[@class='e-pagercontainer']").isVisible();
    console.log("Pagination Available = ", Pagination);



}

async function Addbank(page, bank) {

    await page.locator(locators.Verify_bank.bank_name).fill(bank);
    await page.waitForTimeout(1000);

    const checkbox = page.locator('input[type="checkbox"]'); // Adjust the selector if necessary

    // Check if the checkbox is currently checked
    const isChecked = await checkbox.isChecked();

    // If the checkbox is not checked, check it; if it is checked, uncheck it
    if (!isChecked) {
        await checkbox.check(); // Check the checkbox
    } else {
        await checkbox.uncheck(); // Uncheck the checkbox
    }


    await page.locator(locators.Verify_bank.bank_save).click();
    await page.waitForTimeout(1000);

}

async function updatebank(page, bank) {

    const rows = await page.locator('tr[aria-rowindex]'); // Select all rows with aria-rowindex
    const firstRow = await rows.nth(0); // Select the first row
    await firstRow.locator(locators.Verify_bank.bank_edit).click();
    await page.waitForTimeout(1000);

    await page.locator(locators.Verify_bank.bank_name).fill(bank);
    await page.waitForTimeout(1000);

    const checkbox = page.locator('input[type="checkbox"]'); // Adjust the selector if necessary

    // Check if the checkbox is currently checked
    const isChecked = await checkbox.isChecked();

    // If the checkbox is not checked, check it; if it is checked, uncheck it
    if (!isChecked) {
        await checkbox.check(); // Check the checkbox
    } else {
        await checkbox.uncheck(); // Uncheck the checkbox
    }


    await page.locator(locators.Verify_bank.bank_save).click();
    await page.waitForTimeout(1000);

}


async function paymentmethod(page, bank, bank_name) {
    await page.waitForTimeout(1000);
    await page.locator(locators.Verify_bank.paymentdropdown).click();
    await page.waitForTimeout(1000);
    await page.fill(locators.Verify_bank.enterpaymentname, bank);
    await page.locator('li.e-list-item', { hasText: bank }).click();


    await page.waitForTimeout(1000);
    await page.locator(locators.Verify_bank.banknamedropdown).click();
    await page.waitForTimeout(2000);
    await page.fill(locators.Verify_bank.enterpaymentname, bank_name);
    await page.locator('li.e-list-item', { hasText: bank_name }).click();
    await page.waitForTimeout(2000);
    await page.locator(locators.Verify_bank.bank_ledger_close).click()

}

async function Bank_Ledger_Navigation(page) {
    await page.locator(locators.bank_menu.Transaction).click();
    console.log('Click on Transaction Menu');
    await page.locator(locators.bank_menu.ledger).click();
    console.log('Click on Ledger Menu');
    await page.locator(locators.bank_menu.bank_ledger).click();
    console.log('Navigat to Bank Ledger Page');
    await page.locator(locators.Verify_bank.ladger_add).click();
    console.log('Click on Add New in Bank ');
}

module.exports = { Bank_Entry_Selection,Addbank, verifybank, updatebank, paymentmethod, Bank_Ledger_Navigation };
