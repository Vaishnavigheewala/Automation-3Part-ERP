const { test, expect } = require('@playwright/test');
const { loadEnvFile } = require('process');
const { pathToFileURL } = require('url');
const locators = require('./AMC_With_GST_Edit.json');

async function OpenView(page) {
    // View AMC GST Invoice
    const divElement = await page.locator(locators.Action_Column).first();
    if (!divElement) {
        throw new Error('divElement is not found');
    }
    const elementHandle = await divElement.elementHandle();
    if (elementHandle) {
        await page.evaluate((el) => {
            el.scrollLeft += 600; // Adjust this value to scroll further or slower
        }, elementHandle);
    } else {
        throw new Error('Element handle is not found for divElement');
    }
    await page.waitForTimeout(2000);
    const rows = await page.locator('tr[aria-rowindex]');
    const firstRow = await rows.nth(0); // Select the first row
    await firstRow.locator(locators.View_AMC_GST_Link).click();
    await page.waitForTimeout(1000);
}

async function OpenEditPage(page) {
    if (await page.locator(locators.Edit_AMC_GST.Edit).isVisible()) {
        await page.locator(locators.Edit_AMC_GST.Edit).click();
        await page.waitForTimeout(3000);
    }
    else {
        console.log("Edit Button not visible");
    }
}

async function Reset_Close_Edit(page, P_Delivey_Address, P_No_Of_Service) {
    await page.waitForTimeout(1000);
    if (P_Delivey_Address != null) {
        await page.fill(locators.Edit_AMC_GST.Delivery_Address, P_Delivey_Address);
    }

    if (P_No_Of_Service != null) {
        await page.fill(locators.Edit_AMC_GST.No_Of_Service, P_No_Of_Service);
    }
    console.log("Data Add for reset");
    await page.waitForTimeout(3000);
    await page.locator(locators.Edit_AMC_GST.Reset).click();
    console.log("Edit page Data reset");
    await page.waitForTimeout(1000);
    await page.locator(locators.Edit_AMC_GST.Close).click();
    await page.waitForTimeout(800);
    console.log("Edit page Closed");
}

async function Verify_Edit(page) {
    await page.waitForTimeout(500);
    // verify disabled conmponent is desabled
    const AMC_E_Invoice_NO = await page.locator(locators.Edit_AMC_GST.Invoice_No).isDisabled();
    const AMC_E_Mobile = await page.locator(locators.Edit_AMC_GST.Mobile).isDisabled();
    await page.waitForTimeout(1000);
    const AMC_E_Address = await page.locator(locators.Edit_AMC_GST.Address).isDisabled();
    const AMC_E_Due_Date = await page.locator(locators.Edit_AMC_GST.Due_Date).isDisabled();
    await page.waitForTimeout(1000);
    const AMC_E_Due_Day = await page.locator(locators.Edit_AMC_GST.Due_Day).isDisabled();
    await page.waitForTimeout(1000);
    console.log("Disabled = Invoice, Mobile, Address, Due Date, Due Day :", AMC_E_Invoice_NO, AMC_E_Mobile, AMC_E_Address, AMC_E_Due_Date, AMC_E_Due_Day);
    await page.waitForTimeout(500);

}

async function Edit_AMC_GST(page, P_Invoice_Date, P_Is_Outside, P_Outside_Product, P_Customer, P_Contract, P_Delivey_Address, P_Technician, P_Payment, P_Contract_period_Date, P_No_Of_Service, P_Product, P_Inventory_Add, P_Inventory_Item, P_Inventory_Qty, P_Inventory_Rate, P_Add_Less) {
    //Invoice Date fill
    if (P_Invoice_Date != null) {
        await page.fill(locators.Edit_AMC_GST.Invoice_Date, P_Invoice_Date);
    }
    //Check/tick the checkbox
    if (P_Is_Outside == "Yes") {
        await page.check(locators.Edit_AMC_GST.Is_Outside_Product);
        if (P_Outside_Product != null) {
            await page.fill(locators.Edit_AMC_GST.Outside_Product, P_Outside_Product);
        }
    }
    //Customer Selction
    if (P_Customer != null) {
        await page.locator(locators.Edit_AMC_GST.Customer_Class).click();
        await page.waitForTimeout(500);
        await page.locator(locators.Edit_AMC_GST.Customer_Input).click();
        await page.waitForTimeout(500);
        await page.fill(locators.Edit_AMC_GST.Customer_Input, P_Customer);
        await page.locator('li.e-list-item', { hasText: P_Customer }).waitFor({ state: 'visible' });
        await page.locator('li.e-list-item', { hasText: P_Customer }).click();
        await page.waitForTimeout(1000);
    }
    //Contract Selection
    if (P_Contract != null) {
        await page.locator(locators.Edit_AMC_GST.Contract_Class).click();
        await page.waitForTimeout(500);
        await page.locator(locators.Edit_AMC_GST.Contract_Input).click();
        await page.waitForTimeout(500);
        await page.fill(locators.Edit_AMC_GST.Contract_Input, P_Contract);
        await page.locator('li.e-list-item', { hasText: P_Contract }).waitFor({ state: 'visible' });
        await page.locator('li.e-list-item', { hasText: P_Contract }).click();
        await page.waitForTimeout(1000);
    }

    //Technician Selection
    if (P_Technician != null) {
        await page.locator(locators.Edit_AMC_GST.Technician_Class).click();
        await page.waitForTimeout(500);
        await page.locator(locators.Edit_AMC_GST.Technician_Input).click();
        await page.waitForTimeout(500);
        await page.fill(locators.Edit_AMC_GST.Technician_Input, P_Technician);
        await page.locator('li.e-list-item', { hasText: P_Technician }).waitFor({ state: 'visible' });
        await page.locator('li.e-list-item', { hasText: P_Technician }).click();
        await page.waitForTimeout(1000);
    }
    //Payment Type Selection
    if (P_Payment != null) {
        await page.locator(locators.Edit_AMC_GST.Payment_Type_Class).click();
        await page.waitForTimeout(500);
        await page.locator(locators.Edit_AMC_GST.Payment_Input).click();
        await page.waitForTimeout(500);
        await page.fill(locators.Edit_AMC_GST.Payment_Input, P_Payment);
        await page.locator('li.e-list-item', { hasText: P_Payment }).waitFor({ state: 'visible' });
        await page.locator('li.e-list-item', { hasText: P_Payment }).click();
        await page.waitForTimeout(1000);
    }
    //Delivery Address
    if (P_Delivey_Address != null) {
        await page.fill(locators.Edit_AMC_GST.Delivery_Address, P_Delivey_Address);
    }
    //Contract Period 
    if (P_Contract_period_Date != null) {
        await page.fill(locators.Edit_AMC_GST.Contract_Per, P_Contract_period_Date);
    }
    //No service
    if (P_No_Of_Service != null) {
        await page.fill(locators.Edit_AMC_GST.No_Of_Service, P_No_Of_Service);
    }
    //Product Selection
    if (P_Product != null) {
        await page.locator(locators.Edit_AMC_GST.Product_Class).click();
        await page.waitForTimeout(500);
        await page.locator(locators.Edit_AMC_GST.Product_Input).click();
        await page.waitForTimeout(500);
        await page.fill(locators.Edit_AMC_GST.Product_Input, P_Product);
        await page.locator('li.e-list-item', { hasText: P_Product }).waitFor({ state: 'visible' });
        await page.locator('li.e-list-item', { hasText: P_Product }).click();
        await page.waitForTimeout(1000);
    }
    //Inventory Adding 
    if (P_Inventory_Add == "Yes") {
        await page.locator(locators.Inventory_Detail.Add).click();
        if (P_Inventory_Item != null) {
            await page.locator(locators.Inventory_Detail.Select_An_Item_Class).click();
            await page.waitForTimeout(500);
            await page.locator(locators.Inventory_Detail.Select_An_Item_Input).click();
            await page.waitForTimeout(500);
            await page.fill(locators.Inventory_Detail.Select_An_Item_Input, P_Inventory_Item);
            await page.locator('li.e-list-item', { hasText: P_Inventory_Item }).waitFor({ state: 'visible' });
            await page.locator('li.e-list-item', { hasText: P_Inventory_Item }).click();
            await page.waitForTimeout(1000);
        }

        //Adding Qut 
        if (P_Inventory_Qty != null) {
            await page.fill(locators.Inventory_Detail.Qty, P_Inventory_Qty);
        }
        //Adding Rate 
        const Rate_Value = await page.inputValue(locators.Inventory_Detail.Rate)
        if (Rate_Value == null) {
            if (P_Inventory_Rate != null) {
                await page.fill(locators.Inventory_Detail.Rate, P_Inventory_Rate);
            }
        }
        await page.locator(locators.Inventory_Detail.Update).click();
    }

    if (P_Add_Less != null) {
        await page.fill(locators.Edit_AMC_GST.Add_Less);
    }
    await page.waitForTimeout(6000);
    await page.locator(locators.Edit_AMC_GST.Submit).click();
    await page.waitForTimeout(3000);
    if (await page.locator(locators.Edit_AMC_GST.Pop_Up_Yes).isVisible()) {
        await page.waitForTimeout(500);
        await page.locator(locators.Edit_AMC_GST.Pop_Up_Yes).click();
        await page.waitForTimeout(2500);
    }

}

async function AMC_With_GST_Reports_Edited_AMC_GST(page, Customer_AGR) {
    // Open AMC GST Reports 
    await page.locator(locators.GST_AMC_Invoice_Report.AMC_GST_Report_Menu).click();
    await page.waitForTimeout(1000);

    //Open side Bar 
    await page.locator(locators.GST_AMC_Invoice_Report.Side_Bar).click();
    await page.waitForTimeout(700);

    if (Customer_AGR != null) {
        // Customer Selction 
        await page.locator(locators.GST_AMC_Invoice_Report.Customer_Class).waitFor({ state: 'visible' });
        await page.locator(locators.GST_AMC_Invoice_Report.Customer_Class).click();
        await page.locator(locators.GST_AMC_Invoice_Report.Customer_Input, Customer_AGR);
        await page.locator('li.e-list-item', { hasText: Customer_AGR }).waitFor({ state: 'visible' });
        await page.waitForTimeout(1000);
        await page.locator('li.e-list-item', { hasText: Customer_AGR }).click();
    }

    // Search Button
    await page.locator(locators.GST_AMC_Invoice_Report.Search).click();
    await page.waitForTimeout(5000);

}

async function Outstanding_Reports_Edit_AMC_GST(page, Customer_OS) {
    //Open Outstanding Reports
    await page.locator(locators.Outstanding_Reports.Outstanding_Report_Menu).click();
    await page.waitForTimeout(1000);
    //Open side Bar 
    await page.locator(locators.Outstanding_Reports.Side_Bar).click();
    await page.waitForTimeout(700);

    if (Customer_OS != null) {
        // Customer Selction 
        await page.locator(locators.Outstanding_Reports.Customer_Class).waitFor({ state: 'visible' });
        await page.locator(locators.Outstanding_Reports.Customer_Class).click();
        await page.locator(locators.Outstanding_Reports.Customer_Input, Customer_OS);
        await page.locator('li.e-list-item', { hasText: Customer_OS }).waitFor({ state: 'visible' });
        await page.waitForTimeout(1000);
        await page.locator('li.e-list-item', { hasText: Customer_OS }).click();
    }
    // Search Button
    await page.locator(locators.Outstanding_Reports.Search).click();
    await page.waitForTimeout(5000);
}

async function Customer_Account_Ledger_Edit_AMC_GST(page, Customer_CAL) {
    // For open the Account Ledger Report & Customer Account Ledger 
    await page.locator(locators.Customer_Account_Ledger.Account_Ledger_Report).click();
    await page.locator(locators.Customer_Account_Ledger.Customer_Account_Ledger_Report).click();
    await page.waitForTimeout(1000);

    // Open Side Bar
    await page.locator(locators.Customer_Account_Ledger.Customer_Account_Ledger_side_Bar).click();
    await page.waitForTimeout(1000);

    if (Customer_CAL != null) {
        // Customer Selction 
        await page.locator(locators.Customer_Account_Ledger.Customer_Class).waitFor({ state: 'visible' });
        await page.locator(locators.Customer_Account_Ledger.Customer_Class).click();
        await page.locator(locators.Customer_Account_Ledger.Customer_Class, Customer_CAL);
        await page.locator('li.e-list-item', { hasText: Customer_CAL }).waitFor({ state: 'visible' });
        await page.waitForTimeout(1000);
        await page.locator('li.e-list-item', { hasText: Customer_CAL }).click();
    }


    // Search Button
    await page.locator(locators.Customer_Account_Ledger.Search).click();
    await page.waitForTimeout(5000);
}

async function Inventory_Stock_Edit_AMC_GST(page, Inventory_Name) {
    // Open inventory stock menu and sidebar
    await page.locator(locators.Inventory_Stock_Report.Inventory_Stock_Menu).click();
    await page.waitForTimeout(1000);
    await page.locator(locators.Inventory_Stock_Report.Side_Bar).click();
    await page.waitForTimeout(1000);

    if (Inventory_Name != null) {
        // Open inventory class dropdown
        await page.locator(locators.Inventory_Stock_Report.Inventory_Class).waitFor({ state: 'visible' });
        await page.locator(locators.Inventory_Stock_Report.Inventory_Class).click();
        await page.locator(locators.Inventory_Stock_Report.Inventory_Input).fill(Inventory_Name);

        // Scroll and search for the inventory item
        let isFound = false;
        let maxScrollAttempts = 20; // Limit to prevent infinite loop
        let scrollAttempts = 0;

        while (!isFound && scrollAttempts < maxScrollAttempts) {
            try {
                // Check if the desired inventory item is visible
                const inventoryItem = await page.locator('li.e-list-item', { hasText: Inventory_Name });
                if (await inventoryItem.isVisible()) {
                    await inventoryItem.click();
                    isFound = true;
                    break;
                }
            } catch (error) {
                // Catch any errors during the lookup
                console.log(`Attempt ${scrollAttempts + 1}: Inventory not found yet.`);
            }

            // Scroll down
            await page.evaluate(() => window.scrollBy(0, 500)); // Adjust scroll step as needed
            await page.waitForTimeout(1000); // Allow time for new items to load
            scrollAttempts++;
        }

        if (!isFound) {
            throw new Error(`Inventory with name "${Inventory_Name}" not found after ${maxScrollAttempts} attempts.`);
        }
    }
    // Click the Search button
    await page.locator(locators.Inventory_Stock_Report.Search).click();
    await page.waitForTimeout(1500);
    // View AMC GST Invoice
    const divElement = await page.locator(locators.Inventory_Stock_Report.View_Action_Column).first();
    if (!divElement) {
        throw new Error('divElement is not found');
    }
    const elementHandle = await divElement.elementHandle();
    if (elementHandle) {
        await page.evaluate((el) => {
            el.scrollLeft += 600; // Adjust this value to scroll further or slower
        }, elementHandle);
    } else {
        throw new Error('Element handle is not found for divElement');
    }
    await page.waitForTimeout(1000);
    const rows = await page.locator('tr[aria-rowindex]');
    const firstRow = await rows.nth(0); // Select the first row
    await firstRow.locator(locators.Inventory_Stock_Report.View_link).click();
    await page.waitForTimeout(2000);
}


module.exports = { OpenView, OpenEditPage, Verify_Edit, Edit_AMC_GST, Reset_Close_Edit, Outstanding_Reports_Edit_AMC_GST, Customer_Account_Ledger_Edit_AMC_GST, Inventory_Stock_Edit_AMC_GST, AMC_With_GST_Reports_Edited_AMC_GST };