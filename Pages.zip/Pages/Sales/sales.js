const { test, expect } = require('@playwright/test');
const locators = require('./sales.json');
const fs = require('fs');
const path = require('path');

let filePath = path.join(process.cwd(), 'Dynamic_Variables_Manage/Dynamic_Variable.json');

// Ensure the variable file exists
if (!fs.existsSync(filePath)) {
    console.error(`File not found: ${filePath}`);
    process.exit(1);
}
let updatedVariables = JSON.parse(fs.readFileSync(filePath, 'utf-8'));
let Customer_Name = updatedVariables.Customer.Customer_Account_Name; // Get the latest Customer_Name

async function selectsubmenu(page, menu) {
    if (menu == "Transaction") {
        await page.locator(locators.salesmenu.sales_menu).click();
        await page.locator(locators.salesmenu.sales_gstsales).click();
        await expect(page.locator('li.breadcrumb-item.active', { hasText: 'Sales' })).toBeVisible();


    }
    else if (menu == "Reports") {
        await page.locator(locators.reportsmenu.sales_menu).click();
        await page.locator(locators.reportsmenu.reportitemwise).click();
        await expect(page.locator('li.breadcrumb-item.active', { hasText: 'Item Wise Sales Report' })).toBeVisible();

    }

}



async function addgstsales_button(page) {

    const Addnewsales = await page.locator(locators.Addnewsales);
    await expect(Addnewsales).toBeVisible();
    await page.locator(locators.Addnewsales).click();

}

async function selectcustomer(page, customer) {

    await page.waitForTimeout(1000);
    await page.locator(locators.customerdropdown).click();
    await page.fill(locators.entercustomername, customer);
    // Select the desired customer by its text
    await page.locator('td.customerdropdown1', { hasText: customer }).click();

}

async function Pagination_Checking(page) {
    await page.waitForTimeout(500);
    let Pagination = await page.locator("//div[@class='e-pagercontainer']").isVisible();
    console.log("Pagination Available = ", Pagination);
}

async function selectbroker(page, broker) {
    await page.locator(locators.brokerdropdown).click();
    await page.fill(locators.entercustomername, broker);
    await page.waitForTimeout(1000);
    //  Select the desired Broker by its text
    await page.locator('li.e-list-item', { hasText: broker }).click();
}

async function selecttechnician(page, technician) {
    // Select Technician
    await page.locator(locators.techniciandropdown).click();
    await page.fill(locators.entercustomername, technician);
    await page.waitForTimeout(1000);
    //  Select the desired Broker by its text
    await page.locator('li.e-list-item', { hasText: technician }).click();


}

async function addsalesdetails(page, inventorygroup, item, qty) {
    // Sales Detail 
    await page.locator(locators.addinventoryonsalesdetails).click();
    await page.waitForTimeout(500);
    await page.locator(locators.selectinventorygroup).click(); //Click on Inventory Group
    if (inventorygroup == "FinishMaterial") {
        await page.click(locators.selectfinishmaterial);
    }
    else if (inventorygroup == "RawMaterial") {
        await page.click(locators.selectrawmaterial);
    }
    await page.locator('td.e-rowcell.e-lastrowcell.e-updatedtd.e-selectionbackground.e-active[aria-label=" Column Header Item"]').click();
    await page.locator(locators.inventoryitem).click();
    await page.locator('li.e-list-item', { hasText: item }).nth(0).click();
    await page.locator(locators.clickquantity).click();
    await page.locator(locators.enterquantity).fill(qty);


}
async function updatesalesdetails(page) {
    await page.locator(locators.updateinventorysalesdetails).click();
    await page.locator(locators.updateok).click();
}

async function storenetamount(page, selector) {
    await page.locator(selector).click();
    const value = await page.locator(selector);
    const rawNetAmount = await value.inputValue();
    const netAmount = parseFloat(rawNetAmount.replace(/,/g, ''));
    return netAmount;
}
async function submitbutton(page) {
    await page.locator(locators.submitsales).click();
}

async function salesgrid(page) {
    await page.locator().click();
}

async function selectfilter(page, customername) {
    await page.locator(locators.filterbutton).click();
    await page.locator(locators.customerfilter).click();
    await page.fill(locators.entercustomername, customername);
    await page.waitForTimeout(1000);
    //  Select the desired customer by its text
    const itemLocator = page.locator(`//td[@title='${customername}']`);
    await expect(itemLocator).toBeVisible();
    await itemLocator.click();
    
    await page.locator(locators.searchbutton).click();
}

async function verifydetails(page) {
    // /*****************Verify Customer Name is Correct ************************/
    //const Verifycustomer = JSON.parse(fs.readFileSync('Verifycustomer.json')); //Read the shared Net Amount from the JSON file
    const sharedcustomername = Customer_Name;
    const rows = await page.locator('tr[aria-rowindex]'); // Select all rows with aria-rowindex
    const firstRow = await rows.nth(0); // Select the first row
    await page.waitForTimeout(1000);
    const valuethree = await firstRow.locator("td#ItemWiseSalesReportCustomerNameColumn");
    // const customernamecolumn = await valuethree.innerText();
    // expect(sharedcustomername).toBe(customernamecolumn);
    console.log(" Customer Name before Submit is same as Customer Name on the Itemwise Sales Report")
    // /*****************Verify Net Amount is Same as Total Amount ************************/
    const data = JSON.parse(fs.readFileSync('Verifynetamount.json')); //Read the shared Net Amount from the JSON file
    const sharedNetAmount = data.netAmount;
    const value = await firstRow.locator("td#ItemWiseSalesReportTotalAmountColumn"); //Extract the Net Amount from the latest row 
    const rawNetAmountcolumn = await value.innerText();
    const netAmountInGrid = parseFloat(rawNetAmountcolumn.replace(/,/g, ''));
    //expect(sharedNetAmount).toBe(netAmountInGrid);
    console.log(" Net Amount is same as Total Amount ");
    // /*****************Verify correct GST Bill # is displayed  ************************/
    const datatwo = JSON.parse(fs.readFileSync('Verifylatestgstbill.json'));
    const sharedlatestBillNumber = datatwo.latestGstbillnumber;
    const valuetwo = await firstRow.locator("td#ItemWiseSalesReportBillNumberColumn");
    const gstbillonreport = await valuetwo.innerText();
    const numericPart = gstbillonreport.slice(2);
    const gstBillNumber = parseInt(numericPart, 10);
    expect(sharedlatestBillNumber).toBe(gstBillNumber);
    console.log(" Correct GST Bill # is displayed ");

}

async function searchSelectedCustomer(page, customer) {

    await page.waitForTimeout(1000);
    await page.locator(locators.customerdropdown).click();
    await page.fill(locators.entercustomername, customer);
    //  Select the desired customer by its text
    await page.locator('li.e-list-item', { hasText: customer }).click();
    await page.waitForTimeout(1000);
    await page.locator('#SalesListSearchButton').click();
    await page.locator(locators.pdf_export).click();
    await page.locator(locators.reset).click();
}

async function dataGridInvoiceDownload(page) {
    
    const divElement = await page.$('div.e-content.e-yscroll.e-lib.e-droppable'); // Replace with your actual selector
    await page.evaluate((el) => {
         el.scrollLeft += 600; // Adjust this value to scroll further or slower
    }, divElement);

    await page.waitForTimeout(1000);
    const rows = await page.locator('tr[aria-rowindex]'); // Select all rows with aria-rowindex
    const firstRow = await rows.nth(0); // Select the first row
    const invoiceButton = await firstRow.locator('a#SalesInvoiceDownloadPopupOpenButton');
    const isVisible = await invoiceButton.isVisible();
        if (isVisible) {
            console.log('View button is visible. Proceeding with click.');
            await invoiceButton.click();
            console.log(' Clicked on "View" button.');
        } else {
            console.log('View button is not found or not visible.');
        }
    
    await page.waitForTimeout(1000);
    
    await page.locator(locators.pdf_Popup_Yes).click();
    await page.waitForTimeout(5000);
}

async function ViewSalesDetailData(page) {

    await page.waitForTimeout(500);
    const rows = await page.locator('tr[aria-rowindex]'); // Select all rows with aria-rowindex
    const secondRow = await rows.nth(1); // Select the first row
    const invoiceButton = await secondRow.locator('a#SalesViewButton');
    const isVisible = await invoiceButton.isVisible();
        if (isVisible) {
            console.log('View button is visible. Proceeding with click.');
            await invoiceButton.click();
            console.log(' Clicked on "View" button.');
        } else {
            console.log('View button is not found or not visible.');
        }
    await page.waitForTimeout(1000);
    await page.locator(locators.DetailPage_close).click();
    await page.waitForTimeout(1000);


}

async function salessummaryreport(page){
    await page.click(locators.salessummary.sales);
    await page.click(locators.salessummary.salessummarypage);
    await page.click(locators.salessummary.filterbutton);
    await page.waitForTimeout(1000);
    await page.click(locators.customerdropdown);
    await page.waitForTimeout(1000);
    await page.fill(locators.entercustomername, Customer_Name);
    await page.waitForTimeout(1000);
    await page.locator('li.e-list-item', { hasText: Customer_Name }).click();
 
    await page.waitForTimeout(1000);
    await page.click(locators.salessummary.searchbutton);
    console.log('Sales Summary Report verification completed successfully.');
    

}

async function Combinedsalereport(page){
    await page.click(locators.salessummary.sales);
    await page.click(locators.combinedsale.combinedsalepage);
    await page.click(locators.combinedsale.filterbutton);
    await page.waitForTimeout(1000);
    await page.click(locators.customerdropdown);
    await page.waitForTimeout(1000);
    await page.fill(locators.entercustomername, Customer_Name);
    await page.waitForTimeout(1000);
    await page.locator('li.e-list-item', { hasText: Customer_Name }).click();
 
    await page.waitForTimeout(1000);
    await page.click(locators.combinedsale.searchbutton);
    console.log('Sales Summary Report verification completed successfully.');
    

}

async function Outstanding(page){
    await page.click(locators.outstandingreport.outstanding);

    // Open the filter sidebar
    await page.click(locators.outstandingreport.filterbutton);
  
    // Enter Customer Name in the filter
   
    await page.click(locators.customerdropdown);
      await page.fill(locators.entercustomername, Customer_Name);
      await page.locator('li.e-list-item', { hasText: Customer_Name }).click();
    // Apply the filter by clicking on Search
    await page.click(locators.outstandingreport.SearchButton);
  
  
   
}

async function inventorystockreport(page, inventoryname) {
    await page.locator(locators.inventorystockreport.inventoryStock).click();
    await page.click('#InventoryReportopenSideBarButton');
    await page.click(locators.inventorystockreport.FilterInventorygroup);
    await page.click("//li[normalize-space()='FinishMaterial']");
    await page.waitForTimeout(2000);
    await page.locator(locators.inventorystockreport.inventoryselect).click();

    await page.fill(locators.inventorystockreport.enterInventory, inventoryname);
    await page.locator('li.e-list-item', { hasText: inventoryname }).click();

    await page.locator(locators.inventorystockreport.inventorysearchbutton).click();


}

async function customeraccledger(page){
    await page.click(locators.customeraccLedger.accountLedger);
    await page.click(locators.customeraccLedger.customeraccount);
    await page.click(locators.customeraccLedger.filterbutton);
  
    await page.click(locators.customerdropdown);
    await page.fill(locators.entercustomername, Customer_Name);
    await page.locator('li.e-list-item', { hasText: Customer_Name }).click();
 
  
    await page.click(locators.customeraccLedger.Searchbutton);
    console.log('Customer Account Ledger Report verification completed successfully.');
}




module.exports = {selectsubmenu, addgstsales_button, 
    selectcustomer, selectbroker, selecttechnician,addsalesdetails, 
    updatesalesdetails, storenetamount, submitbutton,salesgrid, selectfilter, Pagination_Checking,
    verifydetails,ViewSalesDetailData,dataGridInvoiceDownload,searchSelectedCustomer,salessummaryreport,Combinedsalereport,Outstanding,inventorystockreport,customeraccledger };
