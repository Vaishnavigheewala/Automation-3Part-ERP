const { test, expect } = require('@playwright/test');
const locators = require('./dashboard.json');
/**
 * Reusable function to log in to the application.
 * 
 * @param {object} page - Playwright page object.
 * @param {string} Menu - MenuItem to be clicked
 */
async function selectmenu(page, menu) {

    if (menu == "Transaction") {
        //console.log('Menu is Transaction');

        await page.locator(locators.menu.transaction).click();

    }
    else if (menu == "Master") {
        //console.log('Menu is Master');
        await page.locator(locators.menu.master).click();
    }
    else if (menu == "Reports") {
        await page.click(locators.menu.reports);
    }
    else if (menu == "GSTRReports") {
        await page.locator(locators.menu.GSTRreports).click();
    }
    else if (menu == "Delete") {
        await page.locator(locators.menu.delete).click();
    }
    else if (menu == "Tools") {
        await page.locator(locators.menu.tools).click();
    }
    console.log(menu, "Menu Clicked");

}
module.exports = { selectmenu };