const { test, expect } = require('@playwright/test');
const locators = require('./Inventory.json');
const { TIMEOUT } = require('dns');
const fs = require('fs');


async function selectsubmenuofInventory(page, menu) {

    if (menu == "Reports") {
        await page.locator(locators.reports_menu.reports).click();
        await page.locator(locators.reports_menu.Inventory_menu).click();
        await expect(page.locator('li.breadcrumb-item.active', { hasText: 'Inventory Stock Report' })).toBeVisible();

    }
}
async function selectfilterResetInventory(page, InventoryGroup, Inventory) {

    const backButton = page.locator('button:has-text("Back")');
    const pdfExportButton = page.locator('button:has-text("PDF Export")');
    const filterButton = page.locator('button:has-text("Filter")');

    await expect(backButton).toBeVisible();
    await expect(pdfExportButton).toBeVisible();
    await expect(filterButton).toBeVisible();

    console.log(' Back, PDF Export, and Filter buttons are visible');

    await page.locator(locators.Inventory.Inventory_filter).click();

    await page.locator(locators.Inventory_group).click();
    //await page.fill(locators.enteritemname, InventoryGroup);
    await page.locator('li.e-list-item', { hasText: InventoryGroup }).click();
    await page.waitForTimeout(1000);

    await page.locator(locators.Inventory_item).click();
    await page.fill(locators.enteritemname, Inventory);
    await page.locator('li.e-list-item', { hasText: Inventory }).click();
    await page.waitForTimeout(1000);

    await page.locator(locators.Inventory.Inventory_reset).click();
    await page.waitForTimeout(1000);
    await page.locator(locators.Inventory.Inventory_close).click();
}

async function selectfilterSearchInventory(page, Inventory) {
    await page.locator(locators.Inventory.Inventory_filter).click();

    await page.locator(locators.Inventory_item).click();
    await page.fill(locators.enteritemname, Inventory);
    await page.locator('li.e-list-item', { hasText: Inventory }).click();
    await page.waitForTimeout(1000);

    await page.locator(locators.Inventory.Inventory_search).click();
    await page.waitForTimeout(1000);

    await page.locator(locators.Inventory.Inventory_view).click();
    await page.locator(locators.Inventory.Inventory_viewback).click();
    await page.locator(locators.Inventory.Inventory_back).click();
    await page.locator(locators.Inventory.Inventory_pdf).dblclick();


}

async function sortingInventory(page) {
    await page.locator(locators.Inventory_name).dblclick();
    await page.waitForTimeout(1000);
    await page.locator(locators.Inventory_name).click();
    console.log(" Records are sorted by Inventory Name");

}



module.exports = { selectsubmenuofInventory, selectfilterResetInventory, selectfilterSearchInventory, sortingInventory }