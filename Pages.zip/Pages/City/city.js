const { test, expect } = require('@playwright/test');
const locators = require('./city.json');
const fs = require('fs');

async function selectcityentry(page) {

  await page.locator(locators.cityentry).click();

}

async function Verifypage(page, cityname) {

  await page.locator(locators.cityNameInput).fill(cityname);  // Fill the City Name field
  await page.locator(locators.Reset).click();
  console.log('Reset ');
  await page.waitForTimeout(6000);
  await page.locator(locators.PDF_Export).click();
  console.log('Pdf dow');

  console.log(' Verify City Entry Section is Displayed');
  const cityEntrySection = page.locator(locators.cityEntryForm);
  await expect(cityEntrySection).toBeVisible();

  console.log(' Verify City Grid is Displayed');
  const cityGrid = page.locator(locators.cityGrid);
  await expect(cityGrid).toBeVisible();

  console.log(' Verify Grid Contains Data');
  const rows = await page.locator('tr[aria-rowindex]');
  const rowCount = await rows.count();
  console.log(`Row Count in Grid: ${rowCount}`);
  await expect(rowCount).toBeGreaterThan(0);

  console.log('City Entry Page Verification Completed');

  console.log(' Verify City Entry Fields');
  const countryField = page.locator(locators.countryField);
  const cityInput = page.locator(locators.cityNameInput);
  // const stateDropdown= page.locator(locators.stateDropdown);
  const isActiveChecked = await page.locator('input#cityIsActive');


  await expect(countryField).toHaveValue('India');
  await expect(cityInput).toBeVisible();
  // await expect(stateDropdown).toBeVisible();
  await expect(isActiveChecked).toBeVisible();
  console.log('City Entry Section Verified');

  console.log(' Verify Grid Column Headers');
  const stateColumn = page.locator('th', { hasText: 'State Name' });
  const cityColumn = page.locator('th', { hasText: 'City Name' });
  const isActiveColumn = page.locator('th', { hasText: 'IsActive' });
  const actionsColumn = page.locator('th', { hasText: 'Action' });

  await expect(stateColumn).toBeVisible();
  await expect(cityColumn).toBeVisible();
  await expect(isActiveColumn).toBeVisible();
  await expect(actionsColumn).toBeVisible();
  console.log('Grid Columns Verified');

  console.log(' Verify Edit Links');
  const row = await page.locator('tr[aria-rowindex]');
  const rowCounts = await row.count();
  console.log(`Row Count: ${rowCounts}`);

  for (let i = 0; i < rowCount; i++) {
    const editLink = rows.nth(i).locator(locators.editcitylink);
    await expect(editLink).toBeVisible();
  }
  console.log('All Edit Links Verified');

  const isPagerVisible = await page.locator('div.e-pagercontainer').isVisible();

  if (isPagerVisible) {
    console.log('Pager is visible.');
    await expect(page.locator('div.e-pagercontainer')).toBeVisible();
  } else {
    console.log('Pager is not found.');
  }




}

async function validation(page) {

  await page.locator(locators.citysavebtn).click();
  await page.locator(locators.Reset).click();

}

async function addNewCity(page, cityname, statename) {
  // Enter the City Name
  await page.locator(locators.cityNameInput).fill(cityname);  // Fill the City Name field
  await page.locator(locators.stateDropdown).click();
  await page.waitForTimeout(2000);
  await page.fill(locators.enterstatename, statename);
  await page.locator('li.e-list-item', { hasText: statename }).click();
  await page.locator(locators.citysavebtn).click();  // Click the Save button


}

async function editCityRecord(page, newCityName, newStateName) {


  // const Verifycityname = JSON.parse(fs.readFileSync('../../Dynamic_Variables_Manage/Dynamic_Variable.json')); //Read the shared Net Amount from the JSON file
  // const sharedcityname = Verifycityname.City_Name;
  const rows = await page.locator('tr[aria-rowindex]'); // Select all rows with aria-rowindex
  const firstRow = await rows.nth(0); // Select the first row
  // const valueone = await firstRow.locator("td#CityName"); //Extract the Net Amount from the latest row
  // const citynamecolumn = await valueone.innerText();
  // expect(sharedcityname).toBe(citynamecolumn);
  console.log(" city Name before Submit is same as city Name on the grid")
  /*********Scroll Right******************/
  await page.waitForTimeout(3000);
  const divElement = await page.$('div.e-content.e-yscroll.e-lib.e-droppable'); // Replace with your actual selector
  await page.evaluate((el) => {
    el.scrollLeft += 600; // Adjust this value to scroll further or slower
  }, divElement);

  //Locate and click the "view" Button
  const viewButton = await firstRow.locator('a#CityEditLinks'); //Adjust this with the actual selector for the "View"
  await viewButton.click();

  await page.waitForTimeout(3000);

  // Edit the City Name
  await page.locator(locators.cityNameInput).fill(newCityName); // Change the city name

  // Change the State
  await page.locator(locators.stateDropdown).click(); // Open the state dropdown
  await page.waitForTimeout(1000);
  await page.fill(locators.enterstatename, newStateName); // Fill state input with new state
  await page.locator('li.e-list-item', { hasText: newStateName }).click(); // Select the new state
  await page.waitForTimeout(1000);

  // Turn off the IsActive radio button (assume it's currently checked)
  const isActiveChecked = await page.locator('input#cityIsActive').isChecked();
  if (isActiveChecked) {
    await page.locator('input#cityIsActive').click(); // Turn it off if it’s checked
  }
  await page.waitForTimeout(1000);

  // Click the "Update" button to save changes
  await page.locator(locators.cityupdatebtn).click();  // Click the Update button
}

async function selectareaentry(page) {

  await page.locator(locators.areaentry).click();
  console.log("Navigate area page");


}

async function verifyCityInAreaDropdown(page, statename, cityname) {


  // Select the state
  await page.locator(locators.stateDropdownInArea).click();
  await page.fill(locators.enterstatename, statename);
  await page.locator('li.e-list-item', { hasText: statename }).click();

  // Verify the city in the city dropdown


  const cityDropdown = await page.locator('span.e-ddl.e-lib.e-input-group.e-control-container.e-control-wrapper.style-size.AreaEntryCityName.e-valid-input.valid')  // Adjust this locator if needed
  await cityDropdown.click(); // Click the city dropdown to load city options
  await page.waitForTimeout(2000);

  await page.fill(locators.enterstatename, cityname);
  const cityOptions = await page.locator('li.e-list-item');  // Adjust the locator for your city list

  let cityFound = false;

  // Loop through the options and check if the city is available
  const optionCount = await cityOptions.count();
  for (let i = 0; i < optionCount; i++) {
    const optionText = await cityOptions.nth(i).innerText();
    if (optionText === cityname) {
      cityFound = true;
      break;
    }
  }

  // Assert that the city is found in the dropdown
  expect(cityFound).toBe(true);
  console.log(` City "${cityname}" found in dropdown`);
}

async function selectaccountentry(page) {

  await page.locator(locators.accountentry).click();
  console.log("Navigate area page");


}

async function verifyCityInAccountDropdown(page, statename, cityname) {


  // Select the state
  await page.locator(locators.stateDropdownInAccount).click();
  await page.fill(locators.enterstatename, statename);
  await page.locator('li.e-list-item', { hasText: statename }).click();

  // Verify the city in the city dropdown


  const cityDropdown = await page.locator('span.e-ddl.e-lib.e-input-group.e-control-container.e-control-wrapper.CustomerCity.e-valid-input.valid')  // Adjust this locator if needed
  await cityDropdown.click(); // Click the city dropdown to load city options
  await page.waitForTimeout(1000);

  await page.fill(locators.enterstatename, cityname);
  const cityOptions = await page.locator('li.e-list-item');  // Adjust the locator for your city list

  let cityFound = false;

  // Loop through the options and check if the city is available
  const optionCount = await cityOptions.count();
  for (let i = 0; i < optionCount; i++) {
    const optionText = await cityOptions.nth(i).innerText();
    if (optionText === cityname) {
      cityFound = true;
      break;
    }
  }

  // Assert that the city is found in the dropdown
  expect(cityFound).toBe(true);
  console.log(` City "${cityname}" found in dropdown`);
}



async function verifyCityNotInAreaDropdown(page, statename, cityname) {


  // Select the state
  await page.locator(locators.stateDropdownInArea).click();
  await page.fill(locators.enterstatename, statename);
  await page.locator('li.e-list-item', { hasText: statename }).click();

  // Verify the city in the city dropdown


  const cityDropdown = await page.locator('span.e-ddl.e-lib.e-input-group.e-control-container.e-control-wrapper.style-size.AreaEntryCityName.e-valid-input.valid')  // Adjust this locator if needed
  await cityDropdown.click(); // Click the city dropdown to load city options
  await page.waitForTimeout(2000);

  await page.fill(locators.enterstatename, cityname);
  const cityOptions = await page.locator('li.e-list-item');  // Adjust the locator for your city list

  let cityFound = false;

  // Loop through the options and check if the city is available
  const optionCount = await cityOptions.count();
  for (let i = 0; i < optionCount; i++) {
    const optionText = await cityOptions.nth(i).innerText();
    if (optionText === cityname) {
      cityFound = true;
      break;
    }
  }

  // Assert that the city is found in the dropdown
  expect(cityFound).toBe(false);
  console.log(` City "${cityname}" not found in Area dropdown`);
}



async function verifyCityNotInAccountDropdown(page, statename, cityname) {


  // Select the state
  await page.locator(locators.stateDropdownInAccount).click();
  await page.fill(locators.enterstatename, statename);
  await page.locator('li.e-list-item', { hasText: statename }).click();

  // Verify the city in the city dropdown


  const cityDropdown = await page.locator('span.e-ddl.e-lib.e-input-group.e-control-container.e-control-wrapper.CustomerCity.e-valid-input.valid')  // Adjust this locator if needed
  await cityDropdown.click(); // Click the city dropdown to load city options
  await page.waitForTimeout(6000);

  await page.fill(locators.enterstatename, cityname);
  const cityOptions = await page.locator('li.e-list-item');  // Adjust the locator for your city list

  let cityFound = false;

  // Loop through the options and check if the city is available
  const optionCount = await cityOptions.count();
  for (let i = 0; i < optionCount; i++) {
    const optionText = await cityOptions.nth(i).innerText();
    if (optionText === cityname) {
      cityFound = true;
      break;
    }
  }

  // Assert that the city is found in the dropdown
  expect(cityFound).toBe(false);
  console.log(` City "${cityname}" not found in Account dropdown`);
}


module.exports = {
  selectcityentry, Verifypage, validation, addNewCity, editCityRecord,
  selectareaentry, verifyCityInAreaDropdown, selectaccountentry, verifyCityInAccountDropdown,
  verifyCityNotInAreaDropdown, verifyCityNotInAccountDropdown
};