const { test, expect } = require('@playwright/test');
//const { NULL } = require('mysql/lib/protocol/constants/types');
const { loadEnvFile } = require('process');
const { pathToFileURL } = require('url');
const locators = require('./AMC_Contract_Plan.json');

async function AMC_Menu(page) {
    // code for navigate to the AMC Contrsct page
    await page.locator(locators.AMC_Contract_Plan_menu).click();
    await page.waitForSelector('li.breadcrumb-item.active', { timeout: 10000 });

    const breadcrumbText = await page.locator('li.breadcrumb-item.active').textContent();
    console.log('Breadcrumb text:', breadcrumbText);

    if (!breadcrumbText.includes("Amc Contract")) {
        console.warn("Unexpected breadcrumb text. Capturing screenshot...");
        await page.screenshot({ path: 'breadcrumb-mismatch.png' });
    }
}


async function PDF_Export(page) {
    // PDF Export Code
    await page.locator(locators.PDF_Export).click();
    console.log('Sucessfully PDF Exported.');
}

async function Reset_Demo(page) {
    // code for the Edit selection for the latest or first from the Grid
    const divElement = await page.locator(locators.Action_Column).first();
    if (!divElement) {
        throw new Error('divElement is not found');
    }

    const elementHandle = await divElement.elementHandle();
    if (elementHandle) {
        await page.evaluate((el) => {
            el.scrollLeft += 600; // Adjust this value to scroll further or slower
        }, elementHandle);
    } else {
        throw new Error('Element handle is not found for divElement');
    }

    await page.waitForTimeout(1000);
    const rows = await page.locator('tr[aria-rowindex]');
    const firstRow = await rows.nth(0); // Select the first row
    await firstRow.locator(locators.Edit).click();
    await page.waitForTimeout(3000);
    // reset Data
    await page.locator(locators.AMC_Entry.Reset).click();
    console.log(' Sucessfully Clicked on Reset.');
}

async function Add_AMC_Contract_plan(page, Name, Active) {

    await page.waitForTimeout(1000);
    await page.fill(locators.AMC_Entry.AMC_Contract_Name, Name);
    await page.waitForTimeout(500);
    // Intialy is not check if want to check than this condion apply
    if (Active == "Yes") {
        await page.locator(locators.AMC_Entry.Active).check();
        await page.waitForTimeout(1000);
        console.log('Active Checked');
    }
    // Save data
    await page.locator(locators.AMC_Entry.Save).click();
    await page.waitForTimeout(3000);
    console.log('Data Added Sucessfully');

}

async function Edit_AMC_Contract_Plan(page, Name, Active) {
    // code for the Edit selection for the latest or first from the Grid
    const divElement = await page.locator(locators.Action_Column).first();
    if (!divElement) {
        throw new Error('divElement is not found');
    }

    const elementHandle = await divElement.elementHandle();
    if (elementHandle) {
        await page.evaluate((el) => {
            el.scrollLeft += 600; // Adjust this value to scroll further or slower
        }, elementHandle);
    } else {
        throw new Error('Element handle is not found for divElement');
    }
    await page.waitForTimeout(1000);
    const rows = await page.locator('tr[aria-rowindex]');
    const firstRow = await rows.nth(0); // Select the first row
    await firstRow.locator(locators.Edit).click();
    await page.waitForTimeout(2000);
    // Edit name 
    await page.fill(locators.AMC_Entry.AMC_Contract_Name, Name);
    await page.waitForTimeout(500);
    // If condition for active state in contract 
    if (Active != null) {
        if (Active == "Yes") {
            await page.locator(locators.AMC_Entry.Active).check();
            await page.waitForTimeout(1000);
            console.log('Active Checked');
        }
        else if (Active == "No") {
            await page.locator(locators.AMC_Entry.Active).uncheck();
            await page.waitForTimeout(1000);
            console.log('Active Checked');
        }
        await page.locator(locators.AMC_Entry.Save).click();
        await page.waitForTimeout(3000);
    }
    else {

        await page.locator(locators.AMC_Entry.Save).click();
        await page.waitForTimeout(3000);
    }


}

async function viewInAE(page, CP) {
    // Navigation to AMC Invoice menu
    await page.locator(locators.AMC_Invoice.AMC_Invoice_menu).click();
    await page.waitForTimeout(1000);

    // Add new AMC
    await page.locator(locators.AMC_Invoice.AE_Add).click();
    await page.waitForTimeout(400);

    // Open the dropdown for contract selection
    await page.locator(locators.AMC_Invoice.AE_Dropdown_Class).click();
    await page.waitForTimeout(1000);

    // Ensure that the dropdown is visible and in an editable state
    const dropdownInput = await page.locator(locators.AMC_Invoice.AE_D_Input);
    
    // If the input is readonly, try interacting with the dropdown directly
    const isReadonly = await dropdownInput.evaluate(el => el.hasAttribute('readonly'));
    
    if (isReadonly) {
        console.log('Dropdown input is readonly, interacting with the dropdown directly.');
        // Directly select the contract from the dropdown list
        await page.locator('li.e-list-item', { hasText: CP }).waitFor({ state: 'visible' });
        await page.locator('li.e-list-item', { hasText: CP }).click();
    } else {
        // If the input is editable, fill it
        await page.fill(locators.AMC_Invoice.AE_D_Input, CP);
        await page.locator('li.e-list-item', { hasText: CP }).waitFor({ state: 'visible' });
        await page.locator('li.e-list-item', { hasText: CP }).click();
    }

    await page.waitForTimeout(2000); // Wait for any actions to complete
}


async function viewInSAC(page, CP) {
    // Navigation 
    await page.locator(locators.salesmenu.sales_menu).click();
    await page.locator(locators.salesmenu.AMC_Invoice).click();
    await page.waitForSelector('li.breadcrumb-item.active', { timeout: 10000 });
    const breadcrumbText = await page.locator('li.breadcrumb-item.active').textContent();
    console.log('Breadcrumb text:', breadcrumbText);


    // add new AMC 
    await page.waitForTimeout(1000);
    await page.locator(locators.AMC_Invoice_SAC.SAC_Add).click();
    await page.waitForTimeout(400);
    // Select Data in Contract dropdown
    await page.locator(locators.AMC_Invoice_SAC.SAC_Dropdown_class).click();
    await page.waitForTimeout(1000);
    const dropdownInput =  await page.locator(locators.AMC_Invoice_SAC.SAC_D_Input);

    const isReadonly = await dropdownInput.evaluate(el => el.hasAttribute('readonly'));
    
    if (isReadonly) {
        console.log('Dropdown input is readonly, interacting with the dropdown directly.');
        // Directly select the contract from the dropdown list
        await page.locator('li.e-list-item', { hasText: CP }).waitFor({ state: 'visible' });
        await page.locator('li.e-list-item', { hasText: CP }).click();
    } else {
        // If the input is editable, fill it
        await page.fill(locators.AMC_Invoice.AE_D_Input, CP);
        await page.locator('li.e-list-item', { hasText: CP }).waitFor({ state: 'visible' });
        await page.locator('li.e-list-item', { hasText: CP }).click();
    }

}

module.exports = { AMC_Menu, PDF_Export, Reset_Demo, Add_AMC_Contract_plan, Edit_AMC_Contract_Plan, viewInAE, viewInSAC }; 
