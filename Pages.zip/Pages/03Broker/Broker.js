const { test, expect } = require('@playwright/test');
const locators = require('./Broker.json');

async function add_broker_data(page, broker, mobile, address) {
    await page.locator(locators.broker_name).click();
    await page.fill(locators.broker_name, broker);
    await page.waitForTimeout(1000);

    await page.locator(locators.mobile).click();
    await page.fill(locators.mobile, mobile);
    await page.waitForTimeout(1000);

    await page.locator(locators.address).click();
    await page.fill(locators.address, address);
    await page.waitForTimeout(1000);

    await page.locator(locators.submit_btn).click();
}

async function editlink(page) {
    // const rows = await page.locator('tr[aria-rowindex]'); // Select all rows with aria-rowindex
    // const firstRow = await rows.nth(0); // Select the first row
    // const edit = await firstRow.locator('a[title="View tecnician detail"]');    
    // edit.click();

    await page.locator(locators.edit_broker).nth(0).click();

}

// async function update_broker_data(page , broker , mobile , address) {
//     await page.locator(locators.broker_name).click(); 
//     await page.fill(locators.broker_name, broker); 
//     await page.waitForTimeout(1000); 

//     await page.locator(locators.mobile).click(); 
//     await page.fill(locators.mobile, mobile); 
//     await page.waitForTimeout(1000);     

//     await page.locator(locators.address).click(); 
//     await page.fill(locators.address, address); 
//     await page.waitForTimeout(1000); 
// }

async function selectsubmenu(page, menu) {
    if (menu == "Transaction") {
        await page.locator(locators.proforma.sales_menu).click();
        await page.locator(locators.proforma.proforma_page).click();
        await expect(page.locator('li.breadcrumb-item.active', { hasText: 'Proforma Sales' })).toBeVisible();
    }
}

async function selectbroker(page, broker) {

    await page.locator(locators.brokerdropdown).click();
    await page.fill(locators.entercustomername, broker);
    await page.waitForTimeout(1000);
    // Step 4: Select the desired Broker by its text
    await page.locator('li.e-list-item', { hasText: broker }).nth(0).click();


}

module.exports = { add_broker_data, editlink, selectsubmenu, selectbroker }