const { test, expect } = require('@playwright/test');
const locators = require('./login.json');
const fs = require('fs');
const path = require('path');
/**
 * Reusable function to log in to the application.
 * 
 * @param {object} page - Playwright page object.
 * @param {object} locators - Locators for the login page.
 * @param {string} username - Username to log in.
 * @param {string} password - Password to log in.
 * @param {string} company - company to log in.
 */
async function log_in(page, username, password, company) {
  // Navigate to the login page

  //await page.goto('http://uat.aquacare.thinkhpconsultant.com/');
  //await page.goto('http://withidforautomation.aquacare.thinkhpconsultant.com:73/');
    await page.goto('http://withidforautomationsite2.aquacare.thinkhpconsultant.com/');


  // Verify the page title
 // await expect(page).toHaveTitle("Login : Shree Aqua Care Inc.");

  // Fill in the username and password
  await page.locator(locators.loginPage.usernameField).fill(username);
  await page.locator(locators.loginPage.passwordField).fill(password);

  // Click the login button
  await page.locator(locators.loginPage.loginButton).click();
  // Handle modal popup
  await page.waitForSelector(locators.loginPage.modalTitle, { visible: true });
  if (await page.isVisible(locators.loginPage.modalTitle)) {
    await page.locator(locators.loginPage.modalConfirmButton).click();
  }


  // Select Company name - Shree Aqua Care
  await page.locator(locators.loginPage.dropdown).click();
  if (company == "ShreeAquaCare") {
    await page.click(locators.loginPage.dropdownOption1);
  }
  else if (company == "ArchieEnterprice") {
    await page.click(locators.loginPage.dropdownOption2);
  }
  else if (company == "KishorbhaiBThakkar") {
    await page.click(locators.loginPage.dropdownOption3);
  }
  else if (company == "CashOnly") {
    await page.click(locators.loginPage.dropdownOption4);
  }

}

async function Get_Current_Date_Time() {
  let now = new Date();
  let year = now.getFullYear();
  let month = String(now.getMonth() + 1).padStart(2, '0');
  let day = String(now.getDate()).padStart(2, '0');
  let hours = String(now.getHours()).padStart(2, '0');
  let minutes = String(now.getMinutes()).padStart(2, '0');
  let seconds = String(now.getSeconds()).padStart(2, '0');

  let date = `${year}-${month}-${day}`;
  let time = `${hours}:${minutes}:${seconds}`;

  return `${date} ${time}`;
}

async function Generate_Unique_String(length) {
  let chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
  let result = '';
  let timestamp = Date.now().toString(36); // Convert timestamp to base-36 string

  for (let i = 0; i < length; i++) {
    let randomIndex = Math.floor(Math.random() * chars.length);
    result += chars[randomIndex];
  }
  // console.log("Time = ", timestamp);
  // console.log("result", result);
  return result;
}

async function Company_Change(page, companyname) {
  await page.locator(locators.Company_Dropdown_Two).click();
  await page.locator('li.e-list-item', { hasText: companyname }).click();
  await page.locator(locators.Change_Btn).click();
  console.log("Company Change to ", companyname);
}

function Variable_File_Path() {
  const filePath = path.join(process.cwd(), 'Dynamic_Variables_Manage/Dynamic_Variable.json');

  if (!fs.existsSync(filePath)) {
    console.error(`File not found: ${filePath}`);
    process.exit(1);
  }

  return filePath;
}

module.exports = { log_in, Get_Current_Date_Time, Generate_Unique_String, Company_Change, Variable_File_Path };
