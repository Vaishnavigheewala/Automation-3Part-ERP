const { test, expect } = require('@playwright/test');
const { loadEnvFile } = require('process');
const { pathToFileURL } = require('url');
const locators = require('./Edit_Cash_Ledger.json');

let Outstanding_Grand_Total = "";
let Customer_Account_Ledger_Grand_Total = "";

async function DisabledFields(page) {
    const Edit_Cash_Voucher_No = await page.locator(locators.Edit_Cash_Ledger.Voucher_No).isDisabled();
    const Edit_Cash_Voucher_Date = await page.locator(locators.Edit_Cash_Ledger.Voucher_Date).isDisabled();
    await page.waitForTimeout(500);
    const Edit_Cash_Payment_Nature = await page.locator(locators.Edit_Cash_Ledger.Payment_Nature).isDisabled();
    await page.waitForTimeout(500);
    const Edit_Cash_Payment_Mode = await page.locator(locators.Edit_Cash_Ledger.Payment_Mode).isDisabled();
    await page.waitForTimeout(500);
    console.log("Disabled Fields Voucher_No Voucher_Date Payment_Nature Payment_Mode User =", Edit_Cash_Voucher_No, Edit_Cash_Voucher_Date, Edit_Cash_Payment_Nature, Edit_Cash_Payment_Mode);
}

async function Search_User(page, Date, Account_Group, Customer, Vendor) {
    if (Date != null) {
        await page.fill(locators.Date, Date);
    }
    await page.waitForTimeout(500);

    if (Account_Group != null) {
        //Select account Group
        await page.locator(locators.Account_Group_Class).click();
        await page.waitForTimeout(500);
        await page.locator('li.e-list-item', { hasText: Account_Group }).click();
    }

    if (Customer != null) {
        //Select Customer
        await page.locator(locators.Customer_Class).click();
        await page.waitForTimeout(500);
        await page.locator(locators.Customer_Input).click();
        await page.waitForTimeout(800);
        await page.fill(locators.Customer_Input, Customer);
        await page.locator('li.e-list-item', { hasText: Customer }).waitFor({ state: 'visible' });
        await page.locator('li.e-list-item', { hasText: Customer }).click();
        await page.waitForTimeout(500);
    }

    if (Vendor != null) {
        // Select Vendor
       
        await page.locator(locators.Vendor_Class).click();
        await page.locator(locators.Vendor_Input).click();
        await page.fill(locators.Vendor_Input, Vendor);
        await page.locator('li.e-list-item', { hasText: Vendor }).waitFor({ state: 'visible' });
        await page.waitForTimeout(1000);
        await page.locator('li.e-list-item', { hasText: Vendor }).click();
        
    }
    await page.locator(locators.Search).click();
   
}

async function Open_View_Link(page) {
    const viewElements = await page.locator(locators.View).count(); // Get total number of View elements
    let found = false;
    for (let i = 0; i < viewElements; i++) {
        await page.locator(locators.View).nth(i).click(); // Click on nth View link
        await page.waitForTimeout(900);
        if (await page.locator(locators.Edit_Cash_Ledger.Edit).isVisible()) {
            await page.locator(locators.Edit_Cash_Ledger.Edit).click();
            found = true;
            break; // Exit the loop if the Edit button is found
            await page.waitForTimeout(500);
        } else {
            console.log(`Edit Button not visible at index ${i}. Trying next View link.`);
            await page.locator(locators.View_Close).click(); // Close the View if Edit is not found
            await page.waitForTimeout(500); // Add a small delay before proceeding to the next element
        }
    }
    if (!found) {
        console.log("Edit Button not found in any View links (Payment is full/ All Payments are full).");
    }
}

async function Edit_User(page) {
    const Recive_Column = await page.locator(locators.Edit_Cash_Ledger.Recive_Column).first();
    await Recive_Column.dblclick(); 
    await page.waitForTimeout(1000);
    await page.locator(locators.Edit_Cash_Ledger.Received_Amt)
    .fill((parseFloat((await page.locator("input#RecAmt").first().inputValue()) || 0) / 2).toFixed(2));

    // Get text content from the column
    
        await page.locator(locators.Edit_Cash_Ledger.Update).click();
        await page.waitForTimeout(1000);
        if (await page.locator(locators.Edit_Cash_Ledger.Partial_Payment_Pop_up).isVisible()) {
            await page.locator(locators.Edit_Cash_Ledger.Partial_Payment_Yes).click();
        }
        await page.waitForTimeout(500);
        await page.locator(locators.Edit_Cash_Ledger.OK_Update_Popup).click();
        await page.waitForTimeout(1000);
        await page.locator(locators.Edit_Cash_Ledger.Submit_Edit).click();
    }

    
async function Customer_Outstanding_Report(page, customername, date) {
    await page.locator(locators.Reports).click();
    await page.locator(locators.Outstanding_Report.Outstanding_Report_Menu).click();
    await page.locator(locators.Outstanding_Report.Outstanding_Report_Side_Bar).click();
    if (customername != null) {
        await page.locator(locators.Outstanding_Report.Filter_Class).click();
        await page.fill(locators.Outstanding_Report.Filter_Input, customername);
        await page.waitForTimeout(1000);
        const itemLocator = page.locator(`//td[@title='${customername}']`);
        await expect(itemLocator).toBeVisible();
        await itemLocator.click();
    }
    //  Select the desired customer by its text
    if (date != null) {
        const datepicker = '#OutstandingReportDateRangePickerForFilter'; //code to clear the date
        await page.fill(datepicker, ''); //code to clear the date
        await page.fill(datepicker, date); //code to enter current data
    }
    await page.locator(locators.Outstanding_Report.Search).click();
    await page.waitForTimeout(1000);

    await page.waitForSelector(`tr:has(td:has-text("${customername}"))`, { timeout: 60000 }); // wait up to 60 seconds
    // Now locate the row and get the balance
    await page.locator(`tr:has(td:has-text("${customername}"))`);
    Outstanding_Grand_Total = await page.locator('td.e-summarycell[data-cell="Balance"]').textContent();
    console.log(`Outstanding Report Overall Balance: ${Outstanding_Grand_Total}`);

}

async function Customer_Account_Ledger_Report(page, customername, date) {
    await page.locator(locators.Reports).click();
    await page.locator(locators.Customer_Account_Ledger.Accountledger).click();
    await page.locator(locators.Customer_Account_Ledger.CustomerAccountledger).click();
    await page.locator(locators.Customer_Account_Ledger.CustomerAccountfilterbutton).click();
    await page.waitForTimeout(1000);
    if (customername != null) {
        await page.locator(locators.Customer_Account_Ledger.Filter_Class).click();
        await page.waitForTimeout(1000);
        await page.fill(locators.Customer_Account_Ledger.Filter_Input, customername);
        await page.locator('li.e-list-item', { hasText: customername }).click();
        
    }
    if (date != null) {
        const datepicker = '#OutstandingReportDateRangePickerForFilter'; //code to clear the date
        await page.fill(datepicker, ''); //code to clear the date
        await page.fill(datepicker, date); //code to enter current data
    }
    
    await page.locator(locators.Customer_Account_Ledger.CustomerAccountsearchbutton).click();
    await page.waitForTimeout(1000);
    await page.waitForSelector(`tr:has(td:has-text("${customername}"))`, { timeout: 60000 });
    await page.locator(`tr:has(td:has-text("${customername}"))`);
    Customer_Account_Ledger_Grand_Total = await page.locator('td.e-summarycell[data-cell="Balance"]').textContent();
    console.log(`customer Ledger Report Overall Balance: ${Customer_Account_Ledger_Grand_Total}`);
    expect(parseFloat(Outstanding_Grand_Total)).toBe(parseFloat(Customer_Account_Ledger_Grand_Total));
    console.log('Consistency between Outstanding Report and Account Ledger verified successfully.');
}


async function Payble_Reoprt_Vendor(page, Vendor, Date) {

    await page.locator(locators.Reports).click();
    await page.locator(locators.Payable_Report.Payable_Report_Menu).click();
    await page.locator(locators.Payable_Report.Filter_Side_Bar).click();
    if (Vendor != null) {
        await page.locator(locators.Payable_Report.Filter_Class).click();
        
        await page.fill(locators.Payable_Report.Filter_Input, Vendor);
        await page.locator('li.e-list-item', { hasText: Vendor }).click();

    }
    if (Date != null) {
        const datepicker = '#PayableReportDatePickerForFilter'; //code to clear the date
        await page.fill(datepicker, ''); //code to clear the date
        await page.fill(datepicker, Date); //code to enter current data   
    }
    await page.locator(locators.Payable_Report.Search).click();
    
   
}

async function Vendor_Account_Ledger(page, Vendor, Date) {
    
    await page.locator(locators.Reports).click();
    await page.locator(locators.Vendor_Account_Ledger_Report.Accountledger).click();
    await page.locator(locators.Vendor_Account_Ledger_Report.Vendor_Account_Ledger_Menu).click();
   
    await page.locator(locators.Vendor_Account_Ledger_Report.Filter_Side_Bar).click();
    if (Vendor != null) {
        await page.locator(locators.Vendor_Account_Ledger_Report.Filter_Class).click();
        await page.fill(locators.Vendor_Account_Ledger_Report.Filter_Input, Vendor);
        await page.locator('li.e-list-item', { hasText: Vendor }).click();
        
    }
    if (Date != null) {
        const datepicker = '#VendorAccountLedgerReportDatePickerForFilter'; //code to clear the date
        await page.fill(datepicker, ''); //code to clear the date
        await page.fill(datepicker, Date); //code to enter current data   
    }
    await page.locator(locators.Vendor_Account_Ledger_Report.Search).click();
   
}

async function Cash_Ledger_Report(page, Payment_Nature, User) {
    await page.waitForTimeout(400);
    await page.locator(locators.Reports).click();
    await page.locator(locators.Cash_Ledger_Report.Ledger_Report).click();
    await page.locator(locators.Cash_Ledger_Report.Cash_Ledger_Report_Menu).click();
    await page.waitForTimeout(500);
    await page.locator(locators.Cash_Ledger_Report.Filter).click();
    if (Payment_Nature != null) {
        if (Payment_Nature == "Receive") {
            if (User != null) {
                await page.waitForTimeout(1000);
                await page.locator(locators.Cash_Ledger_Report.Customer_Class).click();
                await page.fill(locators.Cash_Ledger_Report.Input_Class, User);
                await page.locator('li.e-list-item', { hasText: User }).click();
                await page.waitForTimeout(500);
            }
        }
        else if (Payment_Nature == "Payable") {
            await page.locator(locators.Cash_Ledger_Report.Payment_Nature_Class).click();
            await page.locator('li.e-list-item', { hasText: Payment_Nature }).click();
            if (User != null) {
                await page.locator(locators.Cash_Ledger_Report.Vendor_Class).click();
                await page.waitForTimeout(1000);
                await page.fill(locators.Cash_Ledger_Report.Input_Class, User);
                await page.locator('li.e-list-item', { hasText: User }).click();
                
            }
        }
        await page.locator(locators.Cash_Ledger_Report.Search).click();
        
    }
}

module.exports = { Search_User, Open_View_Link, DisabledFields, Edit_User, Customer_Outstanding_Report, Customer_Account_Ledger_Report, Cash_Ledger_Report, Vendor_Account_Ledger, Payble_Reoprt_Vendor };