const { test, expect } = require('@playwright/test');
const { loadEnvFile } = require('process');
const { pathToFileURL } = require('url');
const locators = require('./Verify_Bank_Ledger_Page.json');

let Var_Received_Amt_Full;
let Var_Received_Amt_Partial;
let Bill_For_Dublicate;
let Bill_Type_For_Dublicate;
let Bill_Amt;
let Tbx_Total_Received_Amt, Tbx_Remaining_Amt;
let Var_Grid_Date, Var_Grid_Customer, Var_Grid_Bill_No, Var_Grid_Ledger_Voucher_No, Var_Grid_Amount;
let Page_Bill_Amt, Page_Net_Outstanding_Amt, Page_Received_Amt;


async function Search_User(page, Date, Account_Group, Customer, Vendor) {
    console.log("=== Search User ===");
    if (Date != null) {
        await page.fill(locators.Date, Date);
        console.log("Date =", Date);
    }
    await page.waitForTimeout(500);

    if (Account_Group != null) {
        //Select account Group
        await page.locator(locators.Account_Group_Class).click();
        await page.waitForTimeout(500);
        await page.locator('li.e-list-item', { hasText: Account_Group }).click();
        console.log("Account Group =", Account_Group);
        await page.waitForTimeout(500);
    }

    if (Customer != null) {
        //Select Customer
        await page.locator(locators.Customer_Drpodown_Class).click();
        await page.waitForTimeout(500);
        await page.locator(locators.Customer_Dropdown_Input).click();
        await page.waitForTimeout(800);
        await page.fill(locators.Customer_Dropdown_Input, Customer);
        await page.locator('li.e-list-item', { hasText: Customer }).waitFor({ state: 'visible' });
        await page.locator('li.e-list-item', { hasText: Customer }).click();
        console.log("Customer =", Customer);
        await page.waitForTimeout(500);
    }

    if (Vendor != null) {
        // Select Vendor
        await page.locator(locators.Vendor_Drpodown_Class).click();
        await page.waitForTimeout(500);
        await page.locator(locators.Vendor_Drpodown_Input).click();
        await page.waitForTimeout(800);
        await page.fill(locators.Vendor_Drpodown_Input, Vendor);
        await page.locator('li.e-list-item', { hasText: Vendor }).waitFor({ state: 'visible' });
        await page.locator('li.e-list-item', { hasText: Vendor }).click();
        console.log("Vendor =", Vendor);
        await page.waitForTimeout(500);
    }
    await page.locator(locators.Search).click();
    console.log("Search Btn Click");
    await page.waitForTimeout(1500);
}

async function PDF_Export(page) {
    await page.locator(locators.PDF_Export).click();
    console.log("PDF Export Btn Click");
    await page.waitForTimeout(1000);
}

async function Add_Bank_Ledger(page) {
    await page.locator(locators.Add_New).click();
    console.log("Add New Btn Click");
    await page.waitForTimeout(1000);
    await page.locator(locators.Close_Add_Bank_Ledger).click();
    console.log("Add New Close Btn Click");
    await page.waitForTimeout(500);
}

async function View_Bank_Ledger_link(page) {
    await page.waitForTimeout(500);
    await page.locator(locators.View).nth(1).click();
    console.log("Edit Btn Click");
    // Get by Title 
    //await page.getByLable('View Ledger detail').nth(0).click();
    await page.waitForTimeout(1000);
    await page.locator(locators.Close_View_Link).click();
    console.log("Edit Close Btn Click");
    await page.waitForTimeout(500);
}

async function Verify_Add_Bank_Ledger_Page(page) {
    console.log("=== Verify Add Bakn Ledger Page ===");
    let Verify_Voucher_No = await page.locator(locators.Add_Bank_Ledger.Voucher_No).isVisible();
    let Verify_Voucher_Date = await page.locator(locators.Add_Bank_Ledger.Voucher_Date).isVisible();
    let Verify_Payment_Method = await page.locator(locators.Add_Bank_Ledger.Payment_Method_Class).isVisible();
    let Verify_Bank_Charages = await page.locator(locators.Add_Bank_Ledger.Bank_Charges).isVisible();
    let Verify_Payment_Nature = await page.locator(locators.Add_Bank_Ledger.Payment_Nature_Class).isVisible();
    let Verify_Bill_Type = await page.locator(locators.Outstanding_Detail.Bill_Type_Class).isVisible();
    let Verify_Bill_No = await page.locator(locators.Outstanding_Detail.Bill_No_Class).isVisible();
    let Verify_Add_Btn = await page.locator(locators.Outstanding_Detail.Add).isVisible();
    let Verify_Close_Btn = await page.locator(locators.Add_Bank_Ledger.Cancel).isVisible();
    let Verify_Reset_Btn = await page.locator(locators.Add_Bank_Ledger.Reset).isVisible();
    let Verify_Submit_Btn = await page.locator(locators.Add_Bank_Ledger.Submit).isVisible();
    console.log("Voucher No = ", Verify_Voucher_No);
    console.log("Voucher Date = ", Verify_Voucher_Date);
    console.log("Payment Method = ", Verify_Payment_Method);
    console.log("Payment Nature = ", Verify_Payment_Nature);
    console.log("Bank Charages = ", Verify_Bank_Charages);
    console.log("Bill Type = ", Verify_Bill_Type);
    console.log("Bill No = ", Verify_Bill_No);
    console.log("Add Btn = ", Verify_Add_Btn);
    console.log("Close Btn = ", Verify_Close_Btn);
    console.log("Reset Btn = ", Verify_Reset_Btn);
    console.log("Submit Btn = ", Verify_Submit_Btn);
}

async function Add_New_Click(page) {
    await page.waitForTimeout(200);
    await page.locator(locators.Add_New).click();
    console.log("Add New Btn Click");
    await page.locator("#BankLedgerEntryCloseButton").click();
    console.log("Add New Close Btn Click");
}

async function Bank_Ledger_Menu(page) {
    await page.locator(locators.Ledger_menu).click();
    console.log("Ledger Menu Click");
    await page.waitForTimeout(500);
    await page.locator(locators.Bank_Ledger_Menu).click();
    console.log("Bank Ledger Menu Click");
}

//Add_Additional_Payment
async function Add_Bank_Ledger_For_User(page, Date_P, Dublicate_Bill, Payment_Method, Bank, Bank_Account_No, Cheque_No, Transaction_ID, Bank_Charges, Payment_Nature, Customer, Vendor, Full_Partial_Payment, Add_OD, Bill_Type, Bill_No,) {
    console.log("== Add new Bank Ledger for user ===");
    await page.waitForTimeout(600);
    if (Date_P != null) {
        await page.fill(locators.Add_Bank_Ledger.Date, Date_P);
        console.log("Date Fill");
    }
    if (Payment_Method != null) {
        if (Payment_Method == "Cheque") {
            ////Select Cheque
            await page.locator(locators.Add_Bank_Ledger.Payment_Method_Class).click();
            await page.waitForTimeout(300);
            await page.fill(locators.Add_Bank_Ledger.Input_Class, Payment_Method);
            await page.locator('li.e-list-item', { hasText: Payment_Method }).click();
            await page.waitForTimeout(600);
            console.log("Payment Method Select is ", Payment_Method);
            if (Bank != null) {
                //Select Bank name
                await page.locator(locators.Add_Bank_Ledger.Bank_Name_Class).click();
                await page.waitForTimeout(300);
                await page.fill(locators.Add_Bank_Ledger.Input_Class, Bank);
                await page.locator('li.e-list-item', { hasText: Bank }).click();
                await page.waitForTimeout(600);
                console.log("Bank Select is ", Bank);
            }
            if (Bank_Account_No != null) {
                // Fill Bank Account 
                await page.fill(locators.Add_Bank_Ledger.Bank_Account_No, Bank_Account_No);
                console.log("Bank Account No fill ", Bank_Account_No);
            }
            if (Cheque_No != null) {
                // Fill Bank Cheque No
                await page.fill(locators.Add_Bank_Ledger.Cheque_No, Cheque_No);
                console.log("Bank Cheque No fill ", Cheque_No);
            }
            if (Bank_Charges != null) {
                // Fill Bank Chareges
                await page.fill(locators.Add_Bank_Ledger.Bank_Charges, Bank_Charges);
                console.log("Bank Chareges fill ", Bank_Charges);
            }
        }
        else if (Payment_Method == "UPI" || Payment_Method == "NEFT" || Payment_Method == "RTGS") {
            //Select Payment Method UPI / NEFT / RTGS
            await page.locator(locators.Add_Bank_Ledger.Payment_Method_Class).click();
            await page.waitForTimeout(300);
            await page.fill(locators.Add_Bank_Ledger.Input_Class, Payment_Method);
            await page.locator('li.e-list-item', { hasText: Payment_Method }).click();
            await page.waitForTimeout(600);
            console.log("Payment Method Select is ", Payment_Method);
            if (Transaction_ID != null) {
                // Fill Transaction ID
                await page.fill(locators.Add_Bank_Ledger.Transaction_ID, Transaction_ID);
                console.log("Transaction ID fill ", Transaction_ID);
            }
            if (Bank_Charges != null) {
                // Fill Bank Carges
                await page.fill(locators.Add_Bank_Ledger.Bank_Charges, Bank_Charges);
                console.log("Bank Chareges fill ", Bank_Charges);
            }
        }
        if (Payment_Nature != null) {
            //Select Payment Nature Payable or Receive
            await page.locator(locators.Add_Bank_Ledger.Payment_Nature_Class).click();
            await page.waitForTimeout(300);
            await page.fill(locators.Add_Bank_Ledger.Input_Class, Payment_Nature);
            await page.locator('li.e-list-item', { hasText: Payment_Nature }).click();
            await page.waitForTimeout(600);
            console.log("Payment Nature Select is ", Payment_Nature);

            if (Payment_Nature == "Payable") {
                if (Vendor != null) {
                    //Select Vendor
                    await page.locator(locators.Add_Bank_Ledger.Vendor_Class).click();
                    await page.waitForTimeout(300);
                    await page.fill(locators.Add_Bank_Ledger.Input_Class, Vendor);
                    await page.locator('li.e-list-item', { hasText: Vendor }).click();
                    await page.waitForTimeout(600);
                    console.log("Vendor Select is ", Vendor);
                }
            }
        }
        if (Customer != null) {
            //Select Customer
            await page.locator(locators.Add_Bank_Ledger.Customer_Class).click();
            await page.waitForTimeout(300);
            await page.fill(locators.Add_Bank_Ledger.Input_Class, Customer);
            await page.locator('li.e-list-item', { hasText: Customer }).click();
            await page.waitForTimeout(600);
            console.log("Customer Select is ", Customer);
        }
        if (Add_OD == "Add") {
            await page.locator(locators.Outstanding_Detail.Add).click();
            if (Full_Partial_Payment != null) {
                if (Bill_Type != null && Bill_No != null) {
                    //Select Bill type
                    await page.locator(locators.Outstanding_Detail.Bill_Type_Class).click();
                    await page.waitForTimeout(300);
                    await page.locator('li.e-list-item', { hasText: Bill_Type }).click();
                    await page.waitForTimeout(300);
                    console.log("Bill Type Select is ", Bill_Type);
                    Bill_Type_For_Dublicate = Bill_Type;
                    //Select Bill No
                    await page.locator(locators.Outstanding_Detail.Bill_No_TD).click();
                    await page.locator(locators.Outstanding_Detail.Bill_No_Class).click();
                    await page.waitForTimeout(300);
                    await page.locator('li.e-list-item', { hasText: Bill_No }).click();
                    console.log("Bill No Select is ", Bill_No);
                    Bill_For_Dublicate = Bill_No;
                    await page.waitForTimeout(500);
                    await page.locator(locators.Outstanding_Detail.Received_Amt_TD).dblclick();
                    Bill_Amt = await page.locator(locators.Outstanding_Detail.Bill_Amt_TD).textContent();


                    if (Full_Partial_Payment == "Full") {
                        // Fill Full Amount in Receive Amt
                        Var_Received_Amt_Full = await page.locator(locators.Outstanding_Detail.Net_Outstanding).textContent();
                        await page.waitForTimeout(400);
                        await page.fill(locators.Outstanding_Detail.Received_Amt, Var_Received_Amt_Full);
                        // This is condition match if bill amt == net outstanding amt == First full payment
                        if (Bill_Amt == Var_Received_Amt_Full) {
                            console.log("Full Payment Amount is ", Var_Received_Amt_Full);
                        }
                        else {
                            // This is condition match if bill amt == net outstanding amt == Part full payment
                            console.log("Add Part Full Payment Amount is ", Var_Received_Amt_Full);
                        }
                    }
                    else if (Full_Partial_Payment == "Part") {
                        // Fill Part Amount in Receive Amt
                        Var_Received_Amt_Partial = await page.locator(locators.Outstanding_Detail.Net_Outstanding).textContent();
                        console.log("Net Payment Amount is ", Var_Received_Amt_Partial, "Bill Amt = ", Bill_Amt);
                        let Amount = Var_Received_Amt_Partial / 2;
                        if (Bill_Amt === Var_Received_Amt_Partial) {
                            console.log("First Part Payment Amount is ", Amount);
                        }
                        else {
                            console.log("Add Additional Part Payment Amount is ", Amount);
                        }

                        //let Convert_Amount = toString(Amount);
                        await page.waitForTimeout(300);
                        await page.fill(locators.Outstanding_Detail.Received_Amt, Amount.toString());
                        await page.locator(locators.Outstanding_Detail.Remaining_Amt).click();
                        await page.waitForTimeout(500);
                        if (await page.locator(locators.Outstanding_Detail.Partial_payment_Pop_Up).isVisible()) {
                            await page.waitForTimeout(500);
                            await page.locator(locators.Outstanding_Detail.Yes_Partial_payment_Pop_Up).click();
                            console.log("Part Payment Pop up Yes Clicked.");
                        }
                    }
                    await page.locator(locators.Outstanding_Detail.Update).click();
                    await page.waitForTimeout(300);
                    await page.waitForTimeout(500);
                    await page.locator(locators.Outstanding_Detail.Yes_Update_Pop_Up).click();
                    console.log("Update Grid Pop up Yes Clicked.");
                }
            }
            if (Dublicate_Bill == null) {
                await page.locator(locators.Add_Bank_Ledger.Submit).click();
                console.log("Submit Button Clicked, Data inserted.");
            }
        }
    }
}

async function Reset_Add_Bank_Ledger_Page(page) {
    await page.locator(locators.Add_Bank_Ledger.Reset).click();
    console.log("Reset Add Bank Ledger Page");
}

async function Dublicate_Bill_Entry(page) {
    await page.locator(locators.Outstanding_Detail.Add).click();
    //Select Bill type
    await page.locator(locators.Outstanding_Detail.Bill_Type_Class).click();
    await page.waitForTimeout(300);
    await page.locator('li.e-list-item', { hasText: Bill_Type_For_Dublicate }).click();
    await page.waitForTimeout(100);
    //console.log("Bill Type Select is ", Bill_Type_For_Dublicate);
    //Select Bill No
    await page.locator(locators.Outstanding_Detail.Bill_No_TD).nth(0).click();
    await page.locator(locators.Outstanding_Detail.Bill_No_Class).click();
    await page.waitForTimeout(100);
    await page.locator('li.e-list-item', { hasText: Bill_For_Dublicate }).click();
    console.log("Bill No Select is ", Bill_For_Dublicate);
    await page.waitForTimeout(100);
    await page.locator(locators.Outstanding_Detail.Received_Amt_TD).nth(0).click();
    if (await page.locator(locators.Outstanding_Detail.Same_Bill).isVisible) {
        console.log("Same Bill Toast pop Up Visible.");
    }
    await page.locator(locators.Add_Bank_Ledger.Cancel).click();
    await page.waitForTimeout(1000);
    console.log("Close Btn Clicked.");
}

async function Payble_Reoprt_Vendor(page, Vendor, Date_PR, Bill_No) {
    await page.locator(locators.Reports).click();
    console.log("Reports menu Click");
    await page.locator(locators.Payable_Report.Payable_Report_Menu).click();
    console.log("Payable Report menu Click");
    await page.waitForTimeout(200);
    await page.locator(locators.Payable_Report.Filter_Side_Bar).click();
    await page.waitForTimeout(400);
    if (Vendor != null) {
        await page.locator(locators.Payable_Report.Filter_Class).click();
        await page.waitForTimeout(200);
        await page.fill(locators.Payable_Report.Filter_Input, Vendor);
        await page.locator('li.e-list-item', { hasText: Vendor }).click();
        await page.waitForTimeout(1000);
        console.log("Vendor Selected");
    }
    if (Date_PR != null) {
        const datepicker = '#PayableReportDatePickerForFilter'; //code to clear the date
        await page.fill(datepicker, Date_PR); //code to enter current data   
    }
    await page.locator(locators.Payable_Report.Search).click();
    console.log("Payable Report User Data Searched");
    let tableSelector = locators.Payable_Report.Payable_Report_Grid; // e.g. "#OutstandingReportGrid"
    let columnXPath = locators.Payable_Report.Bill_No;
    await Find_ValueIn_Column(page, tableSelector, columnXPath, Bill_No);
}

async function Vendor_Account_Ledger_Report(page, Vendor, Date_VA, Voucher_No) {
    await page.locator(locators.Reports).click();
    console.log("Reports menu Click");
    await page.locator(locators.Vendor_Account_Ledger_Report.Accountledger).click();
    console.log("Account Ledger menu Click");
    await page.waitForTimeout(400);
    await page.locator(locators.Vendor_Account_Ledger_Report.Vendor_Account_Ledger_Menu).click();
    console.log("Vendor Account Ledger menu Click");
    await page.waitForTimeout(400);
    await page.locator(locators.Vendor_Account_Ledger_Report.Filter_Side_Bar).click();
    await page.waitForTimeout(200);
    if (Vendor != null) {
        await page.locator(locators.Vendor_Account_Ledger_Report.Filter_Class).click();
        await page.fill(locators.Vendor_Account_Ledger_Report.Filter_Input, Vendor);
        await page.locator('li.e-list-item', { hasText: Vendor }).click();
        await page.waitForTimeout(1000);
    }
    if (Date_VA != null) {
        const datepicker = '#VendorAccountLedgerReportDatePickerForFilter'; //code to clear the date
        await page.fill(datepicker, Date_VA); //code to enter current data   
    }
    await page.locator(locators.Vendor_Account_Ledger_Report.Search).click();
    await page.waitForTimeout(2000);
    console.log("Vendor Account Ledger User Data Searched");
    let tableSelector = locators.Vendor_Account_Ledger_Report.Vendor_Account_Ledger_Grid; // e.g. "#OutstandingReportGrid"
    let columnXPath = locators.Vendor_Account_Ledger_Report.Voucher_No_Column;
    await Find_ValueIn_Column(page, tableSelector, columnXPath, Voucher_No);
}

async function Bank_Ledger_Report(page, Date_BLR, Payment_Nature, Customer, Vendor, Voucher_No) {
    await page.locator(locators.Reports).click();
    await page.locator(locators.Bank_Ledger_Report.Ledger_Page_Menu).click();
    console.log("Ledger menu Click");
    await page.locator(locators.Bank_Ledger_Report.Bank_Ledger_Menu).click();
    console.log("Bank Ledger menu Click");
    await page.waitForTimeout(500);
    await page.locator(locators.Bank_Ledger_Report.Filter_Side_Bar).click();
    if (Date_BLR != null) {
        await page.fill(locators.Bank_Ledger_Report.Date, Date_BLR); //code to enter current data   
    }
    if (Payment_Nature != null) {
        await page.locator(locators.Bank_Ledger_Report.Payment_Nature_Class).click();
        await page.locator('li.e-list-item', { hasText: Payment_Nature }).click();
        await page.waitForTimeout(300);
    }
    if (Customer != null && Payment_Nature == "Receive") {
        await page.locator(locators.Bank_Ledger_Report.Customer_Class).click();
        await page.fill(locators.Bank_Ledger_Report.Filter_Input, Customer);
        await page.locator('li.e-list-item', { hasText: Customer }).click();
        await page.waitForTimeout(300);
    }
    if (Vendor != null && Payment_Nature == "Payable") {
        await page.locator(locators.Bank_Ledger_Report.Vendor_Class).click();
        await page.fill(locators.Bank_Ledger_Report.Filter_Input, Vendor);
        await page.locator('li.e-list-item', { hasText: Vendor }).click();
        await page.waitForTimeout(500);
    }
    await page.locator(locators.Bank_Ledger_Report.Search).click();
    await page.waitForTimeout(2000);
    console.log("Bank Ledger Report User Data Searched");
    let tableSelector = locators.Bank_Ledger_Report.Bank_Ledger_Grid; // e.g. "#OutstandingReportGrid"
    let columnXPath = locators.Bank_Ledger_Report.Voucher_No;
    await Find_ValueIn_Column(page, tableSelector, columnXPath, Voucher_No);
}

async function Get_Current_Date_Time() {
    let now = new Date();
    let year = now.getFullYear();
    let month = String(now.getMonth() + 1).padStart(2, '0');
    let day = String(now.getDate()).padStart(2, '0');
    let hours = String(now.getHours()).padStart(2, '0');
    let minutes = String(now.getMinutes()).padStart(2, '0');
    let seconds = String(now.getSeconds()).padStart(2, '0');

    let date = `${year}-${month}-${day}`;
    let time = `${hours}:${minutes}:${seconds}`;

    return `${date}_${time}`;
}

async function Generate_Unique_String(length = 6) {
    let chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
    let result = '';
    let timestamp = Date.now().toString(36); // Convert timestamp to base-36 string

    for (let i = 0; i < length; i++) {
        let randomIndex = Math.floor(Math.random() * chars.length);
        result += chars[randomIndex];
    }
    console.log("Time = ", timestamp);
    console.log("result", result);
    return timestamp + result;
}

async function Try_Para(page, Customer) {
    console.log("Function Value = ", Customer);
}

async function Verify_Bank_Ledger_Page(page) {
    console.log("=== Bank Ledger files verification ===");
    let date = await page.locator(locators.Date).isDisabled();
    let customerdrop = await page.locator(locators.Customer_Drpodown_Class).isVisible();
    let search = await page.locator(locators.Search).isVisible();
    let Reset = await page.locator(locators.Reset).isVisible();
    let add_new = await page.locator(locators.Add_New).isVisible();
    let PDF_Export = await page.locator(locators.PDF_Export).isVisible();

    let Voucher_No = await page.locator(locators.verify_bank_ledger.Voucher_No).isVisible();
    let Bill_NO = await page.locator(locators.verify_bank_ledger.Bill_NO).isVisible();
    let Voucher_Date = await page.locator(locators.verify_bank_ledger.Voucher_Date).isVisible();
    let customer = await page.locator(locators.verify_bank_ledger.customer).isVisible();
    let paytype = await page.locator(locators.verify_bank_ledger.paytype).isVisible();
    let bank_name = await page.locator(locators.verify_bank_ledger.bank_name).isVisible();
    let Bank_Account_No = await page.locator(locators.verify_bank_ledger.Bank_Account_No).isVisible();
    let Cheque_No = await page.locator(locators.verify_bank_ledger.Cheque_No).isVisible();
    let Transaction_no = await page.locator(locators.verify_bank_ledger.Transaction_no).isVisible();
    let bank_charges = await page.locator(locators.verify_bank_ledger.bank_charges).isVisible();
    let net_amt = await page.locator(locators.verify_bank_ledger.net_amt).isVisible();

    console.log("Date = ", date);
    console.log("Customer = ", customerdrop);
    console.log("Search Button = ", search);
    console.log("Resert Button = ", Reset);
    console.log("Add New Button = ", add_new);
    console.log("PDF Export Button = ", PDF_Export);

    console.log("Voucher No = ", Voucher_No);
    console.log("Bill No = ", Bill_NO);
    console.log("Voucher Date = ", Voucher_Date);
    console.log("Customer = ", customer);
    console.log("Pay Type = ", paytype);
    console.log("Bank Name = ", bank_name);
    console.log("Bank Account No = ", Bank_Account_No);
    console.log("Cheque No = ", Cheque_No);
    console.log("Transaction No = ", Transaction_no);
    console.log("Bank Charges = ", bank_charges);
    console.log("Net Amount = ", net_amt);
}

async function Total_Receving_Amt(page, Payment_Nature, Customer, Vendor, Total_Receving_Paid_Amt, Remaining_Amt_Bill, Bill_Type, Bill_NO) {
    console.log("===============================================");
    console.log("Total Receive and paid amount Checking");
    await page.waitForTimeout(300);
    Tbx_Total_Received_Amt = await page.locator(locators.Add_Bank_Ledger.Total_Receving_Paid_Amt_Id).inputValue();
    await page.waitForTimeout(1000);
    Tbx_Remaining_Amt = await page.locator(locators.Add_Bank_Ledger.Remaining_Amt).inputValue();
    console.log("Total Received Amt =", Tbx_Total_Received_Amt);
    console.log("Total Remaining Amt =", Tbx_Remaining_Amt);
    if (Tbx_Remaining_Amt == Tbx_Total_Received_Amt) {
        console.log("Initial values Both values are zero");
    }
    await page.locator(locators.Outstanding_Detail.Add).click();
    await page.waitForTimeout(1000);
    // Cheks toast Message PopUp is visible or not for without selecting payment nature
    if (await page.locator(locators.Add_Bank_Ledger.Toast_Message_PopUp).isVisible()) {
        console.log("Toast Message PopUp for select Paymnet nature");
    }
    // Cheks toast Message PopUp is visible or not
    if (Payment_Nature != null) {
        await page.locator(locators.Add_Bank_Ledger.Payment_Nature_Class).click();
        await page.locator('li.e-list-item', { hasText: Payment_Nature }).click();
        console.log("Payment Nature Select is ", Payment_Nature);
        await page.waitForTimeout(300);
    }
    await page.waitForTimeout(4000);
    // Cheks toast Message PopUp is visible or not customer selection or vendor 
    if (Customer != null && Payment_Nature == "Receive") {
        await page.locator(locators.Outstanding_Detail.Add).click();
        await page.waitForTimeout(1000);
        if (await page.locator(locators.Add_Bank_Ledger.Toast_Message_PopUp).isVisible()) {
            console.log("Toast Message PopUp for select Customer");
        }
        await page.locator(locators.Bank_Ledger_Report.Customer_Class).click();
        await page.fill(locators.Bank_Ledger_Report.Filter_Input, Customer);
        await page.locator('li.e-list-item', { hasText: Customer }).click();
        console.log("Customer Select is ", Customer);
        await page.waitForTimeout(300);
        // Cheks toast Message PopUp is visible or not for Total receiving amt
        await page.waitForTimeout(4000);
        await page.locator(locators.Outstanding_Detail.Add).click();
        await page.waitForTimeout(1000);
        if (await page.locator(locators.Add_Bank_Ledger.Toast_Message_PopUp).isVisible()) {
            console.log("Toast Message PopUp for Add Total Receiving Amount");
        }
        await page.waitForTimeout(2000);
        // Enter total receiving smount
        if (Total_Receving_Paid_Amt != null) {
            console.log("Total Receive Paid amt ", Total_Receving_Paid_Amt);
            await page.locator(locators.Add_Bank_Ledger.Total_Receving_Paid_Amt_Id).click();
            await page.fill(locators.Add_Bank_Ledger.Total_Receving_Paid_Amt_Id, Total_Receving_Paid_Amt);
            await page.waitForTimeout(2500);
            console.log("Total Receive Paid amt ", Total_Receving_Paid_Amt);
        }
        await page.locator(locators.Outstanding_Detail.Add).click();

        console.log(typeof Remaining_Amt_Bill);
        // Dublication bill entry demo
        await Bill_Add_In_Bank_Ledger(page, Bill_Type, Bill_NO, Remaining_Amt_Bill);
        await Partial_payment_Pop_Up_Btn(page);
        await page.locator(locators.Outstanding_Detail.Add).click();
        await Bill_Add_In_Bank_Ledger(page, Bill_Type, Bill_NO, Remaining_Amt_Bill);
        await Partial_payment_Pop_Up_Btn(page);
        await Update_Btn(page);
    }
    if (Vendor != null && Payment_Nature == "Payable") {
        await page.locator(locators.Outstanding_Detail.Add).click();
        await page.waitForTimeout(1000);
        if (await page.locator(locators.Add_Bank_Ledger.Toast_Message_PopUp).isVisible()) {
            console.log("Toast Message PopUp for select Vendor");
        }
        await page.locator(locators.Bank_Ledger_Report.Vendor_Class).click();
        await page.fill(locators.Bank_Ledger_Report.Filter_Input, Vendor);
        await page.locator('li.e-list-item', { hasText: Vendor }).click();
        await page.waitForTimeout(500);
        console.log("Vendor Select is ", Vendor);
        // Cheks toast Message PopUp is visible or not for Total receiving amt
        await page.waitForTimeout(4000);
        await page.locator(locators.Outstanding_Detail.Add).click();
        await page.waitForTimeout(1000);
        if (await page.locator(locators.Add_Bank_Ledger.Toast_Message_PopUp).isVisible()) {
            console.log("Toast Message PopUp for Add Total Receiving Amount");
        }
        await page.waitForTimeout(2000);
        // Enter total receiving smount
        if (Total_Receving_Paid_Amt != null) {
            console.log("Total Receive Paid amt ", Total_Receving_Paid_Amt);
            await page.locator(locators.Add_Bank_Ledger.Total_Receving_Paid_Amt_Id).click();
            await page.fill(locators.Add_Bank_Ledger.Total_Receving_Paid_Amt_Id, Total_Receving_Paid_Amt);
            await page.waitForTimeout(2500);
            console.log("Total Receive Paid amt ", Total_Receving_Paid_Amt);
        }
        await page.locator(locators.Outstanding_Detail.Add).click();

        console.log(typeof Remaining_Amt_Bill);
        // Dublication bill entry demo
        await Bill_Add_In_Bank_Ledger(page, Bill_Type, Bill_NO, Remaining_Amt_Bill);
        await page.locator(locators.Outstanding_Detail.Add).click();
        await Bill_Add_In_Bank_Ledger(page, Bill_Type, Bill_NO, Remaining_Amt_Bill);
        await Update_Btn(page);
        await page.waitForTimeout(100);
    }
    if (await page.locator(locators.Add_Bank_Ledger.Toast_Message_PopUp).isVisible()) {
        console.log("Toast Message PopUp for Dublicate/Same Bill No");
    }
    Tbx_Total_Received_Amt = await page.locator(locators.Add_Bank_Ledger.Total_Receving_Paid_Amt_Id).inputValue();
    await page.waitForTimeout(1000);
    Tbx_Remaining_Amt = await page.locator(locators.Add_Bank_Ledger.Remaining_Amt).inputValue();
    console.log("Total Received Amt =", Tbx_Total_Received_Amt);
    console.log("Total Remaining Amt =", Tbx_Remaining_Amt);
    if (Tbx_Remaining_Amt == Tbx_Total_Received_Amt) {
        console.log("Both values are Same and Somthing went wrong!!!!");
    }
    await page.waitForTimeout(3000);
    // cancel Grid data 
    await page.locator(locators.Outstanding_Detail.Cancel).click();
    await page.waitForTimeout(400);
    await page.locator(locators.Outstanding_Detail.Yes_Update_Pop_Up).click();
    console.log("Cancel Grid Pop up Yes Clicked.");
    Tbx_Total_Received_Amt = await page.locator(locators.Add_Bank_Ledger.Total_Receving_Paid_Amt_Id).inputValue();
    await page.waitForTimeout(1000);
    Tbx_Remaining_Amt = await page.locator(locators.Add_Bank_Ledger.Remaining_Amt).inputValue();
    console.log("Total Received Amt =", Tbx_Total_Received_Amt);
    console.log("Total Remaining Amt =", Tbx_Remaining_Amt);
    if (Tbx_Remaining_Amt == Tbx_Total_Received_Amt) {
        console.log("After Cancel Both values are same.");
    }
    // Cheks toast Message PopUp is visible or not for negative value in total Remaning amount
    let MAx_Total_Receving_Paid_Amt = parseFloat(Total_Receving_Paid_Amt) + 10;
    await page.locator(locators.Outstanding_Detail.Add).click();
    await Bill_Add_In_Bank_Ledger(page, Bill_Type, Bill_NO, String(MAx_Total_Receving_Paid_Amt));
    await page.locator(locators.Outstanding_Detail.Net_Outstanding).nth(0).click();
    await page.waitForTimeout(1000);
    if (await page.locator(locators.Add_Bank_Ledger.Toast_Message_PopUp).isVisible()) {
        console.log("Toast Message PopUp for Negative Remeining amt ");
    }
    await Update_Btn(page);
    await page.waitForTimeout(2600);
    await page.locator(locators.Add_Bank_Ledger.Submit).click();
    console.log("Submit Click");
    if (await page.locator(locators.Add_Bank_Ledger.Toast_Message_PopUp).isVisible()) {
        console.log("After Submit Toast Message PopUp for Negative Remeining amt ");
    }
    await page.locator(locators.Outstanding_Detail.Delete).click();
    console.log("Delete Click");
    await page.waitForTimeout(600);
    await Update_Btn(page);
    await page.locator(locators.Add_Bank_Ledger.Total_Receving_Paid_Amt_Id).click();
    Tbx_Total_Received_Amt = await page.locator(locators.Add_Bank_Ledger.Total_Receving_Paid_Amt_Id).inputValue();
    await page.waitForTimeout(1000);
    Tbx_Remaining_Amt = await page.locator(locators.Add_Bank_Ledger.Remaining_Amt).inputValue();
    console.log("Total Received Amt =", Tbx_Total_Received_Amt);
    console.log("Total Remaining Amt =", Tbx_Remaining_Amt);
    if (Tbx_Remaining_Amt == Tbx_Total_Received_Amt) {
        console.log("After delete and update both text box values are same.");
    }
}

async function Bill_Add_In_Bank_Ledger(page, Bill_Type, Bill_No, Received_Amt) {
    console.log("=====================");
    console.log("Oustsanding Detil");
    if (Bill_Type != null && Bill_No != null && Received_Amt != null) {
        //Select Bill type
        await page.locator(locators.Outstanding_Detail.Bill_Type_Class).nth(0).click();
        await page.waitForTimeout(300);
        await page.locator('li.e-list-item', { hasText: Bill_Type }).click();
        await page.waitForTimeout(300);
        console.log("Bill Type Select is ", Bill_Type);
        Bill_Type_For_Dublicate = Bill_Type;
        //Select Bill No
        await page.locator(locators.Outstanding_Detail.Bill_No_TD).nth(0).click();
        await page.locator(locators.Outstanding_Detail.Bill_No_Class).nth(0).click();
        await page.waitForTimeout(300);
        await page.locator('li.e-list-item', { hasText: Bill_No }).click();
        console.log("Bill No Select is ", Bill_No);
        Bill_For_Dublicate = Bill_No;
        await page.waitForTimeout(500);
        await page.locator(locators.Outstanding_Detail.Received_Amt_TD).nth(0).click();
        await page.fill(locators.Outstanding_Detail.Received_Amt, Received_Amt);
        console.log("Receive Amount is ", Received_Amt);
    }
    //     console.log("Part Payment Pop up Yes Clicked.");
    await page.locator(locators.Outstanding_Detail.Net_Outstanding).nth(0).click();
}

async function Update_Btn(page) {
    await page.locator(locators.Outstanding_Detail.Update).click();
    console.log("Update Btn Clicked.");
    await page.waitForTimeout(500);
    await page.locator(locators.Outstanding_Detail.Yes_Update_Pop_Up).click();
    await page.waitForTimeout(1200);
    console.log("Update Grid Pop up Yes Clicked.");
}
async function Partial_payment_Pop_Up_Btn(page) {
    if (await page.locator(locators.Outstanding_Detail.Yes_Partial_payment_Pop_Up).isVisible) {
        await page.waitForTimeout(500);
        await page.locator(locators.Outstanding_Detail.Yes_Partial_payment_Pop_Up).click();
        console.log("Part Payment Pop up Yes Clicked.");
    }
}

async function Select_Payment_Method(page, Payment_Method, Bank, Bank_Account_No, Cheque_No, Bank_Charges, Transaction_ID) {
    console.log("===============================================");
    console.log("Select Payment Method");
    await page.waitForTimeout(300);
    if (Payment_Method != null) {
        if (Payment_Method == "Cheque") {
            ////Select Cheque
            await page.locator(locators.Add_Bank_Ledger.Payment_Method_Class).click();
            await page.waitForTimeout(300);
            await page.fill(locators.Add_Bank_Ledger.Input_Class, Payment_Method);
            await page.locator('li.e-list-item', { hasText: Payment_Method }).click();
            await page.waitForTimeout(600);
            console.log("Payment Method Select is ", Payment_Method);
            if (Bank != null) {
                //Select Bank name
                await page.locator(locators.Add_Bank_Ledger.Bank_Name_Class).click();
                await page.waitForTimeout(300);
                await page.fill(locators.Add_Bank_Ledger.Input_Class, Bank);
                await page.locator('li.e-list-item', { hasText: Bank }).click();
                await page.waitForTimeout(600);
                console.log("Bank Select is ", Bank);
            }
            if (Bank_Account_No != null) {
                // Fill Bank Account 
                await page.fill(locators.Add_Bank_Ledger.Bank_Account_No, Bank_Account_No);
                console.log("Bank Account No fill ", Bank_Account_No);
            }
            if (Cheque_No != null) {
                // Fill Bank Cheque No
                await page.fill(locators.Add_Bank_Ledger.Cheque_No, Cheque_No);
                console.log("Bank Cheque No fill ", Cheque_No);
            }
            if (Bank_Charges != null) {
                // Fill Bank Chareges
                await page.fill(locators.Add_Bank_Ledger.Bank_Charges, Bank_Charges);
                console.log("Bank Chareges fill ", Bank_Charges);
            }
        }
        else if (Payment_Method == "UPI" || Payment_Method == "NEFT" || Payment_Method == "RTGS") {
            //Select Payment Method UPI / NEFT / RTGS
            await page.locator(locators.Add_Bank_Ledger.Payment_Method_Class).click();
            await page.waitForTimeout(300);
            await page.fill(locators.Add_Bank_Ledger.Input_Class, Payment_Method);
            await page.locator('li.e-list-item', { hasText: Payment_Method }).click();
            await page.waitForTimeout(600);
            console.log("Payment Method Select is ", Payment_Method);
            if (Transaction_ID != null) {
                await page.waitForTimeout(600);
                // Fill Transaction ID
                await page.fill(locators.Add_Bank_Ledger.Transaction_ID, Transaction_ID);
                console.log("Transaction ID fill ", Transaction_ID);
            }
            if (Bank_Charges != null) {
                // Fill Bank Carges
                await page.fill(locators.Add_Bank_Ledger.Bank_Charges, Bank_Charges);
                console.log("Bank Chareges fill ", Bank_Charges);
            }
        }
    }
}

async function Bank_Ledger_Section_Data(page, Payment_Nature, Customer, Vendor, Total_Receving_Paid_Amt) {
    console.log("===============================================");
    console.log("Bank Ledger Section Data");
    await page.waitForTimeout(300);
    if (Payment_Nature != null) {
        await page.locator(locators.Add_Bank_Ledger.Payment_Nature_Class).click();
        await page.locator('li.e-list-item', { hasText: Payment_Nature }).click();
        console.log("Payment Nature Select is ", Payment_Nature);
        await page.waitForTimeout(300);
    }
    if (Customer != null && Payment_Nature == "Receive") {
        await page.locator(locators.Bank_Ledger_Report.Customer_Class).click();
        await page.fill(locators.Bank_Ledger_Report.Filter_Input, Customer);
        await page.locator('li.e-list-item', { hasText: Customer }).click();
        console.log("Customer Select is ", Customer);
        await page.waitForTimeout(300);
    }
    if (Vendor != null && Payment_Nature == "Payable") {
        await page.locator(locators.Bank_Ledger_Report.Vendor_Class).click();
        await page.fill(locators.Bank_Ledger_Report.Filter_Input, Vendor);
        await page.locator('li.e-list-item', { hasText: Vendor }).click();
        await page.waitForTimeout(500);
        console.log("Vendor Select is ", Vendor);
    }
    if (Total_Receving_Paid_Amt != null) {
        await page.locator(locators.Add_Bank_Ledger.Total_Receving_Paid_Amt_Id).click();
        await page.fill(locators.Add_Bank_Ledger.Total_Receving_Paid_Amt_Id, Total_Receving_Paid_Amt);
        await page.waitForTimeout(2500);
        console.log("Total Receive Paid amt ", Total_Receving_Paid_Amt);
    }

}

async function Checks_Grid_After_New_Data_Added_Edit(page) {
    await page.waitForTimeout(1000);
    console.log("=======================================");
    console.log("Cash Ledger Data Checks in CL Grid  ");
    console.log("=======================================");
    Var_Grid_Date = await page.locator(locators.Grid_Archie_Cash_Ledger.Voucher_Date).textContent();
    await page.waitForTimeout(1000);
    Var_Grid_Customer = await page.locator(locators.Grid_Archie_Cash_Ledger.Account_Name).textContent();
    Var_Grid_Bill_No = await page.locator(locators.Grid_Archie_Cash_Ledger.Bill_No).textContent();
    await page.waitForTimeout(1000);
    Var_Grid_Amount = await page.locator(locators.Grid_Archie_Cash_Ledger.Net_Amount).textContent();
    Var_Grid_Ledger_Voucher_No = await page.locator(locators.Grid_Archie_Cash_Ledger.Voucher_No).textContent();
    console.log("5 Values =", Var_Grid_Date, Var_Grid_Customer, Var_Grid_Bill_No, Var_Grid_Amount, Var_Grid_Ledger_Voucher_No);
    console.log("Amt", Var_Grid_Amount, "Para", Recevied_Amt_para);
    console.log("Bills from Para", Bill_No_From_Parameter, "customer from Para", Customer_From_Parameter);
    console.log("============");

    if (Var_Grid_Amount == Recevied_Amt_para && Var_Grid_Bill_No == Bill_No_From_Parameter || Customer_From_Parameter == Var_Grid_Customer) {
        console.log("Amt", Var_Grid_Amount, "Amount", Recevied_Amt_para);
        console.log("Bills from Para", Bill_No_From_Parameter, "customer from Para", Customer_From_Parameter);
        console.log("============");
        console.log("Bills from Para", Bill_No_From_Parameter, "customer from Para", Customer_From_Parameter);
        console.log("Newly Added / Edited Record Visible in Grid");
        // store value in Dynamic Bsnk array variable in JSON file
        await Generate_Variable('Bank_Ledger.Voucher_No', async () => `${Var_Grid_Bill_No}`);

    }
}

async function Find_ValueIn_Column(page, Page_Grid_ID, Column, searchValue) {
    console.log("🔍 Searching for:", searchValue);
    let tableSelector = Page_Grid_ID;
    let columnXPath = Column;

    let previousFirstRowText = ""; // Track first row’s content

    while (true) {
        // ✅ Step 1: Ensure the table is loaded
        await page.waitForSelector(`${tableSelector} tr`, { timeout: 5000 }).catch(() => console.log("⚠️ Table took too long to load."));

        // ✅ Step 2: Find the Column Index
        let columnHandles = await page.locator(`xpath=${columnXPath}`).elementHandles();
        if (columnHandles.length === 0) {
            console.log("❌ Column not found!");
            return false;
        }

        let columnIndex = await page.evaluate(el => [...el.parentElement.children].indexOf(el), columnHandles[0]) + 1;
        console.log(`✅ Column index found: ${columnIndex}`);

        // ✅ Step 3: Get all rows
        let rows = await page.locator(`${tableSelector} tr`).all();

        if (rows.length === 0) {
            console.log("⚠️ No rows found on this page.");
            return false;
        }

        let currentFirstRowText = await rows[0].innerText(); // Store first row text

        for (let row of rows) {
            let columnValueLocator = row.locator(`td:nth-child(${columnIndex})`);
            if (await columnValueLocator.count() > 0) {
                let columnValue = await columnValueLocator.innerText();
                if (columnValue.includes(searchValue)) {
                    console.log(`✅ Found "${searchValue}" in row:`, await row.innerText());
                    return true;
                }
            }
        }

        // ✅ Step 4: Check if there's a next page
        try {
            let nextPageElement = await page.locator("//div[contains(@class, 'e-next')]").first();

            if (!(await nextPageElement.isVisible())) {
                console.log("⚠️ No next page button is visible or all pages searched.");
                return false;
            }

            let isNextDisabled = await nextPageElement.getAttribute('class');
            if (isNextDisabled.includes('e-disabled')) {
                console.log(`❌ Value "${searchValue}" not found in any page.`);
                return false;
            }

            // 🛑 Stop if the first row’s text doesn’t change (to prevent infinite loop)
            if (currentFirstRowText === previousFirstRowText) {
                console.log("🚨 No new data loaded. Stopping pagination.");
                return false;
            }

            previousFirstRowText = currentFirstRowText; // Update first row’s text
            console.log("➡️ Moving to next page...");
            await nextPageElement.click();

            // ✅ Wait for new data to load
            await page.waitForTimeout(3000); // Short delay to allow data rendering

        } catch (error) {
            console.log("⚠️ Error while navigating pagination:", error.message);
            return false;
        }
    }
}

async function Add_New_Bank_Ledger(page, Payment_Method, Bank, Bank_Account_No, Cheque_No, Bank_Charges, Transaction_ID, Payment_Nature, Customer, Vendor, Total_Receving_Paid_Amt, Bill_Type, Bill_No, Received_Amt) {
    await Select_Payment_Method(page, Payment_Method, Bank, Bank_Account_No, Cheque_No, Bank_Charges, Transaction_ID);
    await Bank_Ledger_Section_Data(page,Payment_Nature, Customer, Vendor, Total_Receving_Paid_Amt);
    await Bill_Add_In_Bank_Ledger(page, Bill_Type, Bill_No, Received_Amt);
    await Full_Part_Payment_Check(page);
    if (Customer != null){
        Partial_payment_Pop_Up_Btn(page);
    }
    await Update_Btn(page);
    await Checked_Remaining_Amt_Submit(page);
}

async function Full_Part_Payment_Check(page) {
    console.log("==========================");
    console.log("Payment cheking Full or Part");
    //await page.waitForTimeout(1000);
    Page_Bill_Amt = await page.locator(locators.Outstanding_Detail.Bill_Amt_TD).nth(0).textContent();
    Page_Net_Outstanding_Amt = await page.locator(locators.Outstanding_Detail.Net_Outstanding).nth(0).textContent();
    Page_Received_Amt = await page.locator(locators.Outstanding_Detail.Received_Amt_TD).nth(0).textContent();
    if (Page_Bill_Amt == Page_Net_Outstanding_Amt == Page_Received_Amt) {
        console.log("*First and Full* Payment");
    }
    else if (Page_Bill_Amt == Page_Net_Outstanding_Amt != Page_Received_Amt) {
        console.log("*Part* Payment");
    }
    else if (Page_Bill_Amt != Page_Net_Outstanding_Amt == Page_Received_Amt) {
        console.log("*First Additional* Payment");
    }
    else {
        console.log("*Additional* Payment");
    }
}

async function Checked_Remaining_Amt_Submit(page) {
    console.log("=== Submit Btn Clicked.");
    Tbx_Total_Received_Amt = await page.locator(locators.Add_Bank_Ledger.Total_Receving_Paid_Amt_Id).inputValue();
    Tbx_Remaining_Amt = await page.locator(locators.Add_Bank_Ledger.Remaining_Amt).inputValue();
    if (Tbx_Total_Received_Amt != Tbx_Remaining_Amt && Tbx_Remaining_Amt >= 0) {
        await page.locator(locators.Add_Bank_Ledger.Submit).click();
        console.log("Submit Checked");
    }
    else {
        console.log("While Update Btn Clicked some error of the remaining or total receive Amt Tbx.");
        console.log("Remaining Amt", Tbx_Remaining_Amt);
        console.log("Total Receive Amt", Tbx_Total_Received_Amt);
    }
}


module.exports = {
    Search_User, PDF_Export, Add_Bank_Ledger, Bank_Ledger_Menu, Get_Current_Date_Time, View_Bank_Ledger_link,
    Try_Para, Verify_Add_Bank_Ledger_Page, Generate_Unique_String, Add_Bank_Ledger_For_User, Dublicate_Bill_Entry,
    Add_New_Click, Reset_Add_Bank_Ledger_Page, Payble_Reoprt_Vendor, Vendor_Account_Ledger_Report, Bank_Ledger_Report,Find_ValueIn_Column,
    Verify_Bank_Ledger_Page, Total_Receving_Amt, Select_Payment_Method, Bank_Ledger_Section_Data, Checks_Grid_After_New_Data_Added_Edit,
    Bill_Add_In_Bank_Ledger, Update_Btn, Full_Part_Payment_Check, Checked_Remaining_Amt_Submit, Add_New_Bank_Ledger
};

