const { test, expect } = require('@playwright/test');
const locators = require('./editpurchase.json');
const { verify } = require('crypto');
const fs = require('fs');


async function selectsubmenu(page, menu) {
    if (menu == "Transaction") {
        await page.locator(locators.purchasemenu.purchase_menu).click();
        await page.locator(locators.purchasemenu.purchase).click();
        await expect(page.locator('li.breadcrumb-item.active', { hasText: 'Purchase' })).toBeVisible();
    }

}

async function viewlink(page) {

    await page.evaluate(() => { window.scrollTo(0, document.body.scrollHeight); });
    const rows = await page.locator('tr[aria-rowindex]'); // Select all rows with aria-rowindex
    const firstRow = await rows.nth(0); // Select the first row
    await firstRow.locator("td#PurchaseVendorNameColumn"); //Extract the Net Amount from the latest row
    console.log(" Vendor Name before Submit is same as vendor Name on the grid")
    /*********Scroll Right******************/
    await page.waitForTimeout(3000);
    const divElement = await page.$('div.e-content.e-yscroll.e-lib.e-droppable'); // Replace with your actual selector
    await page.evaluate((el) => {
        el.scrollLeft += 600; // Adjust this value to scroll further or slower
    }, divElement);

    //Locate and click the "view" Button
    const viewButton = await firstRow.locator('a#PurchaseViewButton'); //Adjust this with the actual selector for the "View" 

    // Check if the "View" button is visible
    const isVisible = await viewButton.isVisible();
    if (isVisible) {
        console.log('View button is visible. Proceeding with click.');
        await viewButton.click();
        console.log(' Clicked on "View" button.');
    } else {
        console.log('View button is not found or not visible.');
    }
    await page.waitForTimeout(2000);

}

async function Editbutton(page) {

    //  Wait for the Edit button to be visible
    await page.evaluate(() => { window.scrollTo(0, document.body.scrollHeight); });
    await page.waitForTimeout(3000);

    const editButton = page.locator(locators.verifyeditfunctionality.editbtn);
    const isVisible = await editButton.isVisible();

    if (isVisible) {
        console.log('Edit button is visible. Clicking on it.');
        await editButton.click();
        await page.waitForTimeout(2000);
    } else {
        console.log('Edit button is not visible... click on Close button');
        const closeButton = page.locator(locators.verifyeditfunctionality.closebtn);
        await expect(closeButton).toBeVisible();
        await closeButton.click();

    }
}

async function EditPurchaseEntry(page, vendorbillno, vendor) {

    await page.locator(locators.vendorbillno).fill(vendorbillno);  // Fill the Vendor Bill No field
    await page.waitForTimeout(1000);
    await page.locator(locators.vendordropdown).click();
    await page.waitForTimeout(1000);
    await page.fill(locators.entervendorname, vendor);
    await page.locator('li.e-list-item', { hasText: vendor }).click();

}

async function Editpurchasedetails(page, qty, rate) {


    await page.locator(locators.clickquantity).dblclick();
    await page.waitForTimeout(2000);
    await page.locator(locators.enterquantity).fill(qty);
    await page.locator(locators.clickrate).dblclick();
    await page.waitForTimeout(2000);
    await page.locator(locators.enterrate).fill(rate);
    await page.waitForTimeout(2000);

}
async function updatepurchasesdetails(page) {


    await page.locator(locators.updateinventorypurchasesdetails).click();
    await page.waitForTimeout(2000);
    await page.locator(locators.updateok).click();
    await page.waitForTimeout(2000);

}
async function storenetamount(page, selector) {

    await page.locator(selector).click();
    const value = await page.locator(selector);
    const rawNetAmount = await value.inputValue();
    const netAmount = parseFloat(rawNetAmount.replace(/,/g, ''));
    return netAmount;
}
async function submitbutton(page) {

    await page.locator(locators.submitbtn).click();

}

async function selectpurchasereturn(page, menu) {
    if (menu == "Transaction") {
        await page.locator(locators.purchasereturn.purchase).click();
        await page.locator(locators.purchasereturn.purchasereturn).click();
    }
}



async function selectpurchasereturnbillno(page, vendor) {
    await page.locator(locators.purchasereturnaddnew).click();
    await page.waitForTimeout(1000);
    await page.locator(locators.vendordropdown).click();
    await page.waitForTimeout(1000);
    await page.fill(locators.entervendorname, vendor);
    await page.locator('li.e-list-item', { hasText: vendor }).click();

    await page.waitForTimeout(1000);
    await page.locator(locators.billdropdown).click();
    console.log('Bill no visible in dropdown');
    await page.waitForTimeout(1000);
    await page.locator(locators.closepurchasereturn).click();





}


async function SelectItemwiseReport(page, menu) {

    if (menu == "Reports") {
        await page.locator(locators.reportsmenu.purchase_menu).click();
        await page.locator(locators.reportsmenu.reportitemwise).click();
        // await expect(page.locator('li.breadcrumb-item.active', { hasText: 'Item Wise Sales Report' })).toBeVisible();
        const button = await page.locator('span.e-ungroupbutton[title="Ungroup by this column"]');
        await button.click();
    }

}


async function selectfilteritemwise(page, vendor, date) {

    await page.locator(locators.Filterbtnpurchaseitemwisereport).click();
    await page.locator(locators.Filtervensitemwise).click();
    await page.fill(locators.entervendorname, vendor);
    await page.locator('li.e-list-item', { hasText: vendor }).click();
    
    await page.locator(locators.Searchbtnpurchaseitemwise).click();

}

async function SelectsummaryReport(page, menu) {

    if (menu == "Reports") {
        await page.locator(locators.reportsmenu.purchase_menu).click();
        await page.locator(locators.reportsmenu.reportsummary).click();
        // await expect(page.locator('li.breadcrumb-item.active', { hasText: 'Item Wise Sales Report' })).toBeVisible();
        const button = await page.locator('span.e-ungroupbutton[title="Ungroup by this column"]');
        await button.click();
    }

}

async function selectfiltersummary(page, vendor, date) {

    await page.locator(locators.Filterbtnpurchasesummaryreport).click();
    await page.locator(locators.Filtervenpurchasesummary).click();
    await page.fill(locators.entervendorname, vendor);
    await page.locator('li.e-list-item', { hasText: vendor }).click();
    await page.waitForTimeout(1000);
    await page.locator(locators.Searchbtnpurchasesummary).click();

}

async function verifydetailssummary(page) {

    const rows = await page.locator('tr[aria-rowindex]'); // Select all rows with aria-rowindex
    const firstRow = await rows.nth(0); // Select the first row
    const viewButton = await firstRow.locator('a#ViewVendorPurchaseButton'); //Adjust this with the actual selector for the "View" 
    await page.waitForTimeout(3000);

    // Check if the "View" button is visible
    const isVisible = await viewButton.isVisible();
    if (isVisible) {
        console.log('View button is visible. Proceeding with click.');
        await viewButton.click();
        console.log('Clicked on "View" button.');
    } else {
        console.log('View button is not found or not visible.');
    }
    await page.waitForTimeout(3000);
    console.log("successfully click on view link")

}

async function SelectpaybleReport(page, menu) {

    if (menu == "Reports") {
        await page.locator(locators.reportsmenu.reportpayble).click();
        // await expect(page.locator('li.breadcrumb-item.active', { hasText: 'Item Wise Sales Report' })).toBeVisible();
        const button = await page.locator('span.e-ungroupbutton[title="Ungroup by this column"]');
        await button.click();
    }

}

async function selectfilterpayble(page, vendor, date) {

    await page.locator(locators.FilterbtnpurchasePayblereport).click();
    await page.locator(locators.FiltervenpurchasePayble).click();
    await page.fill(locators.entervendorname, vendor);
    await page.locator('li.e-list-item', { hasText: vendor }).click();
    await page.waitForTimeout(1000);
    await page.locator(locators.SearchbtnpurchasePayble).click();

}

async function SelectvendorledgerReport(page, menu) {

    if (menu == "Reports") {
        await page.locator(locators.reportsmenu.accountledger).click();
        await page.locator(locators.reportsmenu.reportvendoraccountledger).click();
        // await expect(page.locator('li.breadcrumb-item.active', { hasText: 'Item Wise Sales Report' })).toBeVisible();
        const button = await page.locator('span.e-ungroupbutton[title="Ungroup by this column"]');
        await button.click();
    }

}

async function selectfiltervendorledger(page, vendor, date) {

    await page.locator(locators.Filterbtnpurchasevendorledgerreport).click();
    await page.locator(locators.Filtervenpurchasevendorledger).click();
    await page.fill(locators.entervendorname, vendor);
    await page.locator('li.e-list-item', { hasText: vendor }).click();
    await page.waitForTimeout(1000);
    await page.locator(locators.Searchbtnpurchasevendorledger).click();

}


async function SelectInventorystockReport(page, menu) {

    if (menu == "Reports") {
        await page.locator(locators.reportsmenu.reportinventorystock).click();
        // await expect(page.locator('li.breadcrumb-item.active', { hasText: 'Item Wise Sales Report' })).toBeVisible();

    }
}
async function selectfilterInventorystock(page, inventoryName) {

    await page.locator(locators.FilterbtnpurchaseInventorystockreport).click();
    await page.click(locators.FilterInventorygroup);
    await page.click("//li[normalize-space()='FinishMaterial']");
    console.log("Selected inventory group.");
    await page.locator(locators.FilterInventoryItem).click();
    await page.fill(locators.enterInventory, inventoryName);
    await page.locator('li.e-list-item', { hasText: inventoryName }).click();
    await page.waitForTimeout(1000);
    await page.locator(locators.SearchbtnpurchaseInventorystock).click();

    const rows = await page.locator('tr[aria-rowindex]'); // Select all rows with aria-rowindex
    const firstRow = await rows.nth(0); // Select the first row

    /*********Scroll Right******************/
    await page.waitForTimeout(3000);
    const divElement = await page.$('div.e-content.e-yscroll.e-lib.e-droppable'); // Replace with your actual selector
    await page.evaluate((el) => {
        el.scrollLeft += 600; // Adjust this value to scroll further or slower
    }, divElement);

    const viewButton = await page.locator('a#InventoryReportViewDetailedinventoryReportButton'); //Adjust this with the actual selector for the "View"

    // Check if the "View" button is visible
    const isVisible = await viewButton.isVisible();
    if (isVisible) {
        console.log('View button is visible. Proceeding with click.');
        await viewButton.click();
        console.log(' Clicked on "View" button.');
    } else {
        console.log('View button is not found or not visible.');
    }
    await page.waitForTimeout(3000);


    


}




module.exports = {
    selectsubmenu, viewlink, Editbutton, EditPurchaseEntry,
    Editpurchasedetails, updatepurchasesdetails, storenetamount, submitbutton,
    SelectItemwiseReport, selectfilteritemwise, SelectsummaryReport, selectfiltersummary,
    verifydetailssummary, SelectpaybleReport, selectfilterpayble, SelectvendorledgerReport,
    selectfiltervendorledger, SelectInventorystockReport, selectfilterInventorystock,
    selectpurchasereturn, selectpurchasereturnbillno
}