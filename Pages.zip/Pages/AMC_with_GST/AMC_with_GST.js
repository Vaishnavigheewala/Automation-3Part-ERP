const { test, expect } = require('@playwright/test');
const locators = require('./AMC_with_GST.json');
const { stat } = require('fs');
const fs = require('fs');
const path = require('path');
 
// Define the file path for the variable storage
let filePath = path.join(process.cwd(), 'Dynamic_Variables_Manage/Dynamic_Variable.json');
 
// Ensure the variable file exists
if (!fs.existsSync(filePath)) {
    console.error(`File not found: ${filePath}`);
    process.exit(1);
}
let updatedVariables = JSON.parse(fs.readFileSync(filePath, 'utf-8'));
let Customer_Name = updatedVariables.Customer.Customer_Account_Name;
let InventoryRO_Name = updatedVariables.Inventory.InventoryRO_Name;
let Raw_inventory = updatedVariables.Inventory.Raw_inventory;


async function selectsubmenu(page, menu) {
    if (menu == "Transaction") {
        await page.locator(locators.AMC_with_GST.AMC_with_GST_page).click();


    }
    else if (menu == "Reports") {
        await page.locator(locators.reportsmenu.sales_menu).click();
        await page.locator(locators.reportsmenu.reportitemwise).click();
        await expect(page.locator('li.breadcrumb-item.active', { hasText: 'Item Wise Sales Report' })).toBeVisible();

    }

}

async function selectcustomer(page, customer) {

    //await page.locator(locators.verify_sales_returnpage.sales_search).click();
    if (customer != null) {
        await page.waitForTimeout(1000);
        await page.locator(locators.AMC_with_GST.customerdropdown).click();
        await page.waitForTimeout(2000);
        await page.fill(locators.AMC_with_GST.nameinput, customer);
        await page.locator('li.e-list-item', { hasText: customer }).click();
        await page.waitForTimeout(3000);
    }
    await page.locator(locators.AMC_with_GST.btn_submit).click();
    await page.waitForTimeout(3000);

    await page.locator(locators.AMC_with_GST.btn_reset).click();

}

async function pdfexport(page) {

    await page.locator(locators.AMC_with_GST.export_pdf).click();

}

async function addnew(page) {
    await page.locator(locators.AMC_with_GST.addnew_btn).click();
}


async function amc_add_new(page, customer, contract, technician, payment, noofservice, product) {


    await page.locator(locators.AMC_add_new.customer).nth(0).click();
    await page.fill(locators.AMC_add_new.nameinput, customer);
    await page.locator('li.e-list-item', { hasText: customer }).click();
    await page.waitForTimeout(3000);

    await page.locator(locators.AMC_add_new.contract).waitFor({ state: 'visible' });
    await page.locator(locators.AMC_add_new.contract).click();
    await page.locator(locators.AMC_add_new.nameinput, contract);
    await page.locator('li.e-list-item', { hasText: contract }).waitFor({ state: 'visible' });
    await page.waitForTimeout(1000);
    await page.locator('li.e-list-item', { hasText: contract }).click();

    await page.locator(locators.AMC_add_new.technician).waitFor({ state: 'visible' });
    await page.locator(locators.AMC_add_new.technician).click();
    await page.locator(locators.AMC_add_new.nameinput, technician);
    await page.locator('li.e-list-item', { hasText: technician }).waitFor({ state: 'visible' });
    await page.waitForTimeout(1000);
    await page.locator('li.e-list-item', { hasText: technician }).click();

    await page.locator(locators.AMC_add_new.payment_type).waitFor({ state: 'visible' });
    await page.locator(locators.AMC_add_new.payment_type).click();
    await page.locator(locators.AMC_add_new.nameinput, payment);
    await page.locator('li.e-list-item', { hasText: payment }).waitFor({ state: 'visible' });
    await page.waitForTimeout(1000);
    await page.locator('li.e-list-item', { hasText: payment }).click();


    await page.locator(locators.AMC_add_new.no_of_service).click();
    await page.fill(locators.AMC_add_new.no_of_service, noofservice);
    await page.waitForTimeout(3000);

    await page.locator(locators.AMC_add_new.product).nth(0).waitFor({ state: 'visible' });
    await page.locator(locators.AMC_add_new.product).nth(0).click();
    await page.locator(locators.AMC_add_new.nameinput, product);
    await page.locator('li.e-list-item', { hasText: product }).waitFor({ state: 'visible' });
    await page.waitForTimeout(1000);
    await page.locator('li.e-list-item', { hasText: product }).click();

    await page.evaluate(() => { window.scrollTo(0, document.body.scrollHeight); });

    await page.locator(locators.AMC_add_new.add_inventory).click();
    await page.waitForTimeout(1000);

    await page.locator(locators.AMC_add_new.item).click();
    await page.locator('li.e-list-item', { hasText:Raw_inventory }).waitFor({ state: 'visible' });
    await page.locator('li.e-list-item', { hasText: Raw_inventory }).click();

    await page.locator(locators.AMC_add_new.qty).nth(1).click();
    await page.locator(locators.AMC_add_new.qty1).click();
    await page.fill(locators.AMC_add_new.qty1, "5");

    await page.locator(locators.AMC_add_new.update).click();
    await page.waitForTimeout(1000);
    await page.locator(locators.AMC_add_new.update_ok).click();

}

async function Expire_amc(page) {

    await page.locator(locators.AMC_with_GST.Expire).nth(0).click();

}

async function Reactivate_amc(page) {

    await page.locator(locators.AMC_with_GST.reactivate).nth(0).click();

}

module.exports = { selectsubmenu, selectcustomer, pdfexport, addnew, amc_add_new, Expire_amc, Reactivate_amc };