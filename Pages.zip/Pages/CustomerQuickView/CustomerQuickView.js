const { test, expect } = require('@playwright/test');
const locators = require('./CustomerQuickView.json');


async function customerquickview(page,deaddress) {
    await page.click(locators.customerquickview.customerquickviewpage);

    await expect(page.locator(locators.customerquickview.deliveryaddress)).toBeVisible();
    await expect(page.locator(locators.customerquickview.customerdropdown)).toBeVisible();

    await page.click(locators.customerquickview.deliveryaddress);
    await page.fill(locators.customerquickview.entercustomername, deaddress);
    await page.locator('li.e-list-item', { hasText: deaddress }).click();

    // Select Customer Name
    // await page.click(locators.customerquickview.customerdropdown);
    // await page.fill(locators.customerquickview.entercustomername, "ZinalAutomation");
    // await page.locator('li.e-list-item', { hasText: "ZinalAutomation" }).click();

    // Verify Fields

    
    await expect(page.locator(locators.customerquickview.mobile)).toBeDisabled(); 
    await expect(page.locator(locators.customerquickview.mobile)).toHaveText('');// Expect populated with customer details
    await expect(page.locator(locators.customerquickview.alternatemobile)).toBeDisabled(); 
    await expect(page.locator(locators.customerquickview.alternatemobile)).toHaveText('');
    await expect(page.locator(locators.customerquickview.area)).toBeDisabled(); 
    await expect(page.locator(locators.customerquickview.area)).toHaveText('');
    await expect(page.locator(locators.customerquickview.address)).toBeDisabled(); 
    await expect(page.locator(locators.customerquickview.address)).toHaveText('');
  //  await page.click(locators.customerquickview.resetbutton);

    //verify grid
    const columns = [
        '#CustomerQuickViewInventoryName',
        '#CustomerQuickViewOutsideProduct',
        '#CustomerQuickViewBillingAddress',
        '#CustomerQuickViewFormattedProductAmcBillDate',
        '#CustomerQuickViewWarrantyStatus',
        '#CustomerQuickViewAMCStatus',
        '#CustomerQuickViewContractPeriod',
        '#CustomerQuickViewContractType',
        '#CustomerQuickViewRemark'
    ];

    for (const column of columns) {
        const isVisible = await page.isVisible(column);
        console.log(`${column} visible: ${isVisible}`);
    }
    


    //select billing address
   // await expect(page.locator(locators.customerquickview.deliveryaddress)).toBeVisible();
   

    await page.click(locators.customerquickview.searchbutton);

    const CUSTOMERNAME = page.locator(locators.customerquickview.customerdropdown);
    console.log(`CUSTOMERNAME Non-Editable and Populated: ${CUSTOMERNAME}`);
    const mobile = page.locator(locators.customerquickview.mobile);
    console.log(`mobile Non-Editable and Populated: ${mobile}`);
    const alternatemobile = page.locator(locators.customerquickview.alternatemobile);
    console.log(`alternatemobile Non-Editable and Populated: ${alternatemobile}`);
    const area = page.locator(locators.customerquickview.area);
    console.log(`mobile Non-Editable and Populated: ${area}`);
    const address = page.locator(locators.customerquickview.address);
    console.log(`address Non-Editable and Populated: ${address}`);
   

    const gridRows = page.locator('#sfgridxrwhte5w2rp_header_table'); // Replace '.e-row' with the actual row class if different
       // Ensure at least one record is displayed

      
            const row = gridRows.nth(0);
            const rowData = await row.allTextContents();

            // Check that each cell in the row has content (non-empty)
            for (const cell of rowData) {
                expect(cell.trim().length).toBeGreaterThan(0);
            }
}

module.exports = {customerquickview };