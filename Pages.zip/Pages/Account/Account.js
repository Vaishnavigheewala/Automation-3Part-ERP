const { test, expect } = require('@playwright/test');
const { loadEnvFile } = require('process');
const { pathToFileURL } = require('url');
const locators = require('./Account.json');

async function AccountMenuSelected(page) {
    await page.locator(locators.Master).click();
    await page.locator(locators.AccountEntry_Menu).click();
    console.log("Account entry Menu click ");
}

async function VerifyAccountPage(page) {
    // For Create new User
    console.log("=======================================");
    console.log("Verify Account Page");
    console.log("=======================================");
    await page.waitForTimeout(1000);
    const Var_GSTINNO = await page.locator(locators.Entry_Edit.GSTIN_No).isEnabled();
    const Var_ClientCode = await page.locator(locators.Entry_Edit.Client_Code).isEnabled();
    await page.waitForTimeout(1000);
    const Var_EMAIL = await page.locator(locators.Entry_Edit.Email).isEnabled();
    const Var_Account_Name = await page.locator(locators.Entry_Edit.Account_Name).isEnabled();
    const Var_Mobile = await page.locator(locators.Entry_Edit.Mobile).isEnabled();
    const Var_Alter_Mobile = await page.locator(locators.Entry_Edit.Alternate_Mobile).isEnabled();
    await page.waitForTimeout(700);
    const Var_Pincode = await page.locator(locators.Entry_Edit.Pincode).isEnabled();
    const Var_Address = await page.locator(locators.Entry_Edit.Address).isEnabled();
    await page.waitForTimeout(800);
    const Var_Submit = await page.locator(locators.Entry_Edit.Submit).isVisible();
    const Var_Reset = await page.locator(locators.Entry_Edit.Reset).isVisible();
    const Var_PDF = await page.locator(locators.PDF_Export).isVisible();
    console.log("+++++++++++++++++++");
    console.log("Enabled Fileds");
    console.log("+++++++++++++++++++");
    console.log(" GSTINNO =", Var_GSTINNO);
    console.log("Client Code =", Var_ClientCode);
    console.log("Email =", Var_EMAIL);
    console.log("Account Name =", Var_Account_Name);
    console.log("Mobile =", Var_Mobile);
    console.log("Alter Mobile =", Var_Alter_Mobile);
    console.log("Mobile =", Var_Mobile);
    console.log("Pincode =", Var_Pincode);
    console.log("Address =", Var_Address);
    console.log("All Abow fileds Editsble  & Below fields are Visible")
    console.log("+++++++++++++++++++");
    console.log("Submit Btn =", Var_Submit);
    console.log("Reset Btn =", Var_Reset);
    console.log("PDF Export Btn =", Var_PDF);
    await page.waitForTimeout(700);
    // PDF Download
    await page.locator(locators.PDF_Export).click();
    await page.waitForTimeout(3000);
    console.log('Clicked on "PDF Export" button.');
    const rows = await page.locator('tr[aria-rowindex]'); // Select all rows with aria-rowindex
    const secondRow = await rows.nth(0); // Select the first row
    const invoiceButton = await secondRow.locator(locators.Edit);
    const isVisible = await invoiceButton.isVisible();
    if (isVisible) {
        console.log('Edit button is visible. Proceeding with click.');
        await invoiceButton.click();
        console.log('Clicked on "Edit" button.');
    } else {
        console.log('Edit button is not found or not visible.');
    }
    await page.waitForTimeout(2000);
    let Account_Name_Tbx = await page.locator(locators.Entry_Edit.Account_Name).textContent();
    console.log("Account Name from Tbx =", Account_Name_Tbx);
    await page.locator(locators.Entry_Edit.Reset).click();
    console.log("Reset Btn Clicked");
    await page.waitForTimeout(3000);
}

async function Pagination_Checking(page) {
    let Pagination = await page.locator(locators.Entry_Edit.Pagination).isVisible();
    console.log("Pagination Available = ", Pagination);
}

async function AddUser(page, User, GST_No, Client_Code, Email, Name, Mobile, Alter_mobile, Pincode, Address, State, City, Area) {
    console.log("=======================================");
    console.log("Add/Create New User");
    console.log("=======================================");
    // Filling User details which pass in parameters
    if (User != null) {
        await page.locator(locators.Entry_Edit.Account_Group_SpanClass).waitFor({ state: 'visible' });
        await page.locator(locators.Entry_Edit.Account_Group_SpanClass).click();
        await page.locator(locators.Entry_Edit.Account_Group_Input, User);
        await page.locator('li.e-list-item', { hasText: User }).waitFor({ state: 'visible' });
        await page.waitForTimeout(1000);
        await page.locator('li.e-list-item', { hasText: User }).click();
        console.log("User Selected = ", User);
    }
    if (GST_No != null) {
        await page.fill(locators.Entry_Edit.GSTIN_No, GST_No);
        console.log("GST No fill = ", GST_No);
    }
    if (Client_Code != null) {
        await page.fill(locators.Entry_Edit.Client_Code, Client_Code);
        console.log("Client Code fill = ", Client_Code);
    }
    if (Email != null) {
        await page.fill(locators.Entry_Edit.Email, Email);
        console.log("Email fill = ", Email);
        await page.waitForTimeout(1000);
    }
    if (Name != null) {
        await page.fill(locators.Entry_Edit.Account_Name, Name);
        console.log("Name fill = ", Name);
        await page.waitForTimeout(1000);
    }
    if (Mobile != null) {
        await page.fill(locators.Entry_Edit.Mobile, Mobile);
        console.log("Mobile fill = ", Mobile);
        await page.waitForTimeout(1000);
    }
    if (Alter_mobile != null) {
        await page.fill(locators.Entry_Edit.Alternate_Mobile, Alter_mobile);
        console.log("Alter Mobile fill = ", Alter_mobile);
    }
    if (Pincode != null) {

        await page.fill(locators.Entry_Edit.Pincode, Pincode);
        console.log("Pincode = ", Pincode);
        await page.waitForTimeout(1000);
    }
    if (Address != null) {
        await page.fill(locators.Entry_Edit.Address, Address);
        console.log("Address fill = ", Address);
        await page.waitForTimeout(1000);
    }

    if (State != null) {
        // +++++++++++++++ Stale Selection +++++++++++++++++
        await page.locator(locators.Entry_Edit.State_SpanClass).click();
        await page.waitForTimeout(1000);
        await page.fill(locators.Entry_Edit.State_Input, State);
        await page.waitForTimeout(1000);
        await page.locator('li.e-list-item', { hasText: State }).click();
        console.log("State Selected = ", State);
        //await page.waitForTimeout(5000);   
    }
    // +++++++++++++++ City Selection +++++++++++++++++
    if (City != null) {
        await page.locator(locators.Entry_Edit.City_SpanClass).click();
        await page.waitForTimeout(1000);
        await page.fill(locators.Entry_Edit.City_Input, City);
        await page.waitForTimeout(1000);
        await page.locator('li.e-list-item', { hasText: City }).waitFor({ state: 'visible' });
        await page.waitForTimeout(4000);
        await page.locator('li.e-list-item', { hasText: City }).click();
        console.log("City Selected = ", City);
    }
    // +++++++++++++++ AREA Selection +++++++++++++++++
    if (Area != null) {
        await page.locator(locators.Entry_Edit.Area_SpanClass).click();
        await page.waitForTimeout(1000);
        await page.fill(locators.Entry_Edit.Area_Input, Area);
        await page.waitForTimeout(1000);
        await page.locator('li.e-list-item', { hasText: Area }).waitFor({ state: 'visible' });
        await page.waitForTimeout(4000);
        await page.locator('li.e-list-item', { hasText: Area }).click();
        await page.waitForTimeout(1000);
        console.log("Area Selected = ", Area);
    }
    await page.locator(locators.Entry_Edit.Submit).click();
    console.log("Submit Btn click  = ");
    await page.waitForTimeout(3000);
}

async function Area(page, Area) {
    await page.waitForTimeout(1000);

    if (Area != null) {
        await page.locator(locators.Entry_Edit.Area_SpanClass).click();
        await page.fill(locators.Entry_Edit.Area_Input, Area);
        await page.waitForTimeout(1000);
        await page.locator('li.e-list-item', { hasText: Area }).click();
        await page.waitForTimeout(1000);
        console.log("Area Selected = ", Area);
    }
}

async function Reset_Demo(page) {
    const divElement = await page.locator(locators.Action_Column).first();
    if (!divElement) {
        throw new Error('divElement is not found');
    }

    const elementHandle = await divElement.elementHandle();
    if (elementHandle) {
        await page.evaluate((el) => {
            el.scrollLeft += 600; // Adjust this value to scroll further or slower
        }, elementHandle);
    } else {
        throw new Error('Element handle is not found for divElement');
    }
    await page.waitForTimeout(1000);
    const rows = await page.locator('tr[aria-rowindex]');
    const firstRow = await rows.nth(0); // Select the first row
    await firstRow.locator(locators.Edit).click();
    await page.waitForTimeout(3000);
    await page.locator(locators.Entry_Edit.Reset).click();
    console.log("Reset Btn click");
}

async function ViewCustomer(page, Customer) {
    // View Customer in Sales page
    console.log("=======================================");
    console.log("Sales Page new added Customer View");
    console.log("=======================================");
    await page.locator(locators.salesmenu.transaction).click();
    await page.locator(locators.salesmenu.sales_menu).click();
    await page.locator(locators.salesmenu.sales_gstsales).click();
    console.log("Navigate to Sales page");
    if (Customer != null) {
        await page.locator(locators.salesmenu.class_Customer).click();
        await page.locator(locators.salesmenu.customer_Input, Customer);
        await page.locator('li.e-list-item', { hasText: Customer }).click();
        console.log("Customer Selected = ", Customer);
    }

}

async function ViewVendor(page, Vendor) {
    console.log("=======================================");
    console.log("Purchase Page new added Vendor View");
    console.log("=======================================");
    await page.locator(locators.purchasemenu.transaction).click();
    await page.locator(locators.purchasemenu.purchase_menu).click();
    console.log("Purchase Menu click ");
    await page.locator(locators.purchasemenu.purchase).click();
    if (Vendor != null) {
        await page.locator(locators.purchasemenu.Vendor_Class).click();
        await page.locator(locators.purchasemenu.Vendor_Id, Vendor);
        await page.locator('li.e-list-item', { hasText: Vendor }).click();
        console.log("Vendor Selected = ", Vendor);
    }
}

async function EditUser(page, Name, GST_No, Client_Code, Email, Mobile, Alter_mobile, Pincode, Address, State, City, Area) {
    // Edit User which was lates Added
    console.log("=======================================");
    console.log("Edit Added User");
    console.log("=======================================");
    const divElement = await page.locator(locators.Action_Column).first();
    if (!divElement) {
        throw new Error('divElement is not found');
    }

    const elementHandle = await divElement.elementHandle();
    if (elementHandle) {
        await page.evaluate((el) => {
            el.scrollLeft += 600; // Adjust this value to scroll further or slower
        }, elementHandle);
    } else {
        throw new Error('Element handle is not found for divElement');
    }

    await page.waitForTimeout(1000);
    const rows = await page.locator('tr[aria-rowindex]');
    const firstRow = await rows.nth(0); // Select the first row
    await firstRow.locator(locators.Edit).click();
    await page.waitForTimeout(3000);

    if (GST_No != null) {
        await page.fill(locators.Entry_Edit.GSTIN_No, GST_No);
        console.log("GST No fill = ", GST_No);
    }

    if (Client_Code != null) {
        await page.fill(locators.Entry_Edit.Client_Code, Client_Code);
        console.log("Client Code fill = ", Client_Code);
    }

    if (Email != null) {
        await page.fill(locators.Entry_Edit.Email, Email);
        console.log("Email fill = ", Email);
        await page.waitForTimeout(1000);
    }

    if (Name != null) {
        await page.fill(locators.Entry_Edit.Account_Name, Name);
        await page.waitForTimeout(1000);
        console.log("Name fill = ", Name);
    }
    if (Mobile != null) {
        await page.fill(locators.Entry_Edit.Mobile, Mobile);
        await page.waitForTimeout(1000);
        console.log("Mobile fill = ", Mobile);
    }

    if (Alter_mobile != null) {
        await page.fill(locators.Entry_Edit.Alternate_Mobile, Alter_mobile);
        console.log("Alter Mobile fill = ", Alter_mobile);
    }

    if (Pincode != null) {
        await page.fill(locators.Entry_Edit.Pincode, Pincode);
        await page.waitForTimeout(1000);
        console.log("Pincode = ", Pincode);
    }

    if (Address != null) {
        await page.fill(locators.Entry_Edit.Address, Address);
        await page.waitForTimeout(1000);
        console.log("Address fill = ", Address);
    }

    if (State != null) {
        await page.locator(locators.Entry_Edit.State_SpanClass).click();
        await page.waitForTimeout(1000);
        await page.fill(locators.Entry_Edit.State_Input, State);
        await page.locator('li.e-list-item', { hasText: State }).waitFor({ state: 'visible' });
        await page.waitForTimeout(2000);
        await page.locator('li.e-list-item', { hasText: State }).click();
        console.log("State Selected = ", State);
    }

    // +++++++++++++++ City Selection +++++++++++++++++
    if (City != null) {
        await page.locator(locators.Entry_Edit.City_SpanClass).click();
        await page.waitForTimeout(1000);
        await page.fill(locators.Entry_Edit.City_Input, City);
        await page.waitForTimeout(1000);
        await page.locator('li.e-list-item', { hasText: City }).waitFor({ state: 'visible' });
        await page.waitForTimeout(4000);
        await page.locator('li.e-list-item', { hasText: City }).click();
        console.log("City Selected = ", City);
    }
    // +++++++++++++++ AREA Selection +++++++++++++++++
    if (Area != null) {
        await page.waitForTimeout(1000);
        await page.locator(locators.Entry_Edit.Area_SpanClass).waitFor({ state: 'visible' });
        await page.locator(locators.Entry_Edit.Area_SpanClass).click();
        await page.fill(locators.Entry_Edit.Area_Input, Area);
        await page.locator('li.e-list-item', { hasText: Area }).waitFor({ state: 'visible' });
        await page.waitForTimeout(1000);
        await page.locator('li.e-list-item', { hasText: Area }).click();
        console.log("Area Selected = ", Area);
    }
    await page.waitForTimeout(1000);
    await page.locator(locators.Entry_Edit.Submit).click();
    console.log("Submit Btn click");
    await page.waitForTimeout(3000);
}

async function AMC_With_GST_Customer(page, customer) {
    console.log("=======================================");
    console.log("AMC With GST Page added Customer View");
    console.log("=======================================");
    await page.locator(locators.purchasemenu.transaction).click();
    await page.locator(locators.AMC_With_GST.AMC_with_GST_page).click();
    console.log("AMC With GST Menu click ");
    // await page.waitForTimeout(1000);
    // await page.locator(locators.AMC_With_GST.Add_New_AMC_GST).click();
    // console.log("Add new AMC With GST Menu click ");
    // await page.waitForTimeout(700);
    // AMC with GST page customer search 
    if (customer != null) {
        await page.locator(locators.AMC_With_GST.Customerdropdown).click();
        await page.fill(locators.AMC_With_GST.Input, customer);
        //await page.locator('li.e-list-item', { hasText: customer }).waitFor({ state: 'visible' });
        // await page.waitForTimeout(1000);
        // await locator.press("Enter");
        await page.locator('li.e-list-item', { hasText: customer }).click();
        console.log("AMC customer Selected = ", customer);
        await page.waitForTimeout(3000);
    }
    await page.locator(locators.AMC_With_GST.Search).click();
    await page.waitForTimeout(400);
    console.log("AMC With GST Search click ");
}

async function Sales_Return_Customer(page, Customer) {
    // Sales Return Customer data
    console.log("=======================================");
    console.log("Sales Return Page new added Customer View");
    console.log("=======================================");
    await page.waitForTimeout(1000);
    await page.locator(locators.purchasemenu.transaction).click();
    await page.locator(locators.Sales_Return.Sales_Menu).click();
    console.log("Sales Menu click ");
    await page.locator(locators.Sales_Return.Sales_Return).click();
    if (Customer != null) {
        await page.locator(locators.Sales_Return.Customerdropdown).click();
        await page.locator(locators.Sales_Return.Input, Customer);
        // await page.locator('li.e-list-item', { hasText: Area }).waitFor({ state: 'visible' });
        await page.locator('li.e-list-item', { hasText: Customer }).click();
        console.log("Sales return customer Selected = ", Customer);
        await page.waitForTimeout(2000);
    }
    await page.locator(locators.Sales_Return.Search).click();
    console.log("Sales return Search click ");
}

async function Bank_Ledger(page, Account_Group, Customer, Vendor) {
    console.log("=======================================");
    console.log("Bank Ledger Page new added User View");
    console.log("=======================================");
    await page.locator(locators.salesmenu.transaction).click();
    await page.waitForTimeout(1000);
    await page.locator(locators.Bank_Ledger.Ledger_menu).click();
    await page.waitForTimeout(1000);
    await page.locator(locators.Bank_Ledger.Bank_Ledger_Menu).click();
    console.log("bank ledger Menu click ");
    if (Customer != null) {
        //Select Customer
        await page.locator(locators.Bank_Ledger.Customer_Drpodown_Class).click();
        await page.waitForTimeout(1000);
        await page.fill(locators.Bank_Ledger.Customer_Dropdown_Input, Customer);
        await page.locator('li.e-list-item', { hasText: Customer }).click();
        await page.waitForTimeout(1000);
        console.log("Bank Ledger customer Selected = ", Customer);

    }
    if (Account_Group != null) {
        //Select account Group
        await page.locator(locators.Bank_Ledger.Account_Group_Class).click();
        await page.waitForTimeout(1000);
        await page.locator('li.e-list-item', { hasText: Account_Group }).click();
        console.log("Bank Ledger Account Group Selected = ", Account_Group);
        await page.waitForTimeout(1000);
    }
    if (Vendor != null) {
        // Select Vendor
        await page.locator(locators.Bank_Ledger.Vendor_Drpodown_Class).click();
        await page.waitForTimeout(1000);
        await page.fill(locators.Bank_Ledger.Vendor_Drpodown_Input, Vendor);
        await page.locator('li.e-list-item', { hasText: Vendor }).click();
        await page.waitForTimeout(1000);
        console.log("Bank Ledger Vendor Selected = ", Vendor);
    }
    await page.locator(locators.Bank_Ledger.Search).click();
    console.log("Bank Ledger Search click ");
}

async function Purchase_Return(page, vendor) {
    // Purchase Return Vendor data 
    console.log("=======================================");
    console.log("Purchase Return Page new added Vendor View");
    console.log("=======================================");
    await page.locator(locators.salesmenu.transaction).click();
    await page.locator(locators.Purchase_Return.purchase).click();
    await page.locator(locators.Purchase_Return.purchasereturn).click();
    console.log("Purchase Return Menu click ");
    if (vendor != null) {
        await page.locator(locators.Purchase_Return.vendorname).click();
        await page.fill(locators.Purchase_Return.nameinput, vendor);
        await page.locator('li.e-list-item', { hasText: vendor }).click();
        console.log("Purchase Return customer Selected = ", vendor);

    }
    await page.locator(locators.Purchase_Return.search_btn).click();
}

async function Cash_Ledger(page, Account_Group, Customer, Vendor) {
    // Cash Ledger page new added user
    console.log("=======================================");
    console.log("Cash Ledger Page new added User View");
    console.log("=======================================");
    await page.locator(locators.salesmenu.transaction).click();
    await page.waitForTimeout(1000);
    await page.locator(locators.Cash_Ledger.Ledger).click();
    await page.waitForTimeout(1000);
    await page.locator(locators.Cash_Ledger.CashLedgerpage).click();
    console.log("cash ledger Menu click ");


    if (Account_Group != null) {
        //Select account Group
        await page.locator(locators.Cash_Ledger.AccountGroup).click();
        await page.locator('li.e-list-item', { hasText: Account_Group }).click();
        await page.waitForTimeout(1000);
        console.log("Cash Ledger Account Group Selected = ", Account_Group);
    }
    if (Customer != null) {
        //Select Customer
        await page.waitForTimeout(2000);
        await page.locator(locators.Cash_Ledger.Customer_Class).click();
        await page.fill(locators.Cash_Ledger.Input, Customer);
        await page.locator('li.e-list-item', { hasText: Customer }).click();
        console.log("Cash Ledger customer Selected = ", Customer);
    }
    if (Vendor != null) {
        // Select Vendor
        await page.locator(locators.Cash_Ledger.Vendor).click();
        await page.waitForTimeout(1000);
        await page.fill(locators.Cash_Ledger.Input, Vendor);
        await page.locator('li.e-list-item', { hasText: Vendor }).click();
        await page.waitForTimeout(1000);
        console.log("Cash Ledger Vendor Selected = ", Vendor);
    }
    await page.locator(locators.Cash_Ledger.Searchbutton).click();
}

async function Debit_Note(page, Vendor) {
    console.log("=======================================");
    console.log("Debit Note Page new added User View");
    console.log("=======================================");
    await page.locator(locators.salesmenu.transaction).click();
    await page.locator(locators.Debit_Note.Debitnotemenu).click();
    console.log("Debit Note Menu click ");
    if (Vendor != null) {
        await page.waitForTimeout(1000);
        await page.locator(locators.Debit_Note.Vendorname_Class).click();
        await page.waitForTimeout(1000);
        await page.fill(locators.Debit_Note.Vendorname_Input, Vendor);
        await page.locator('li.e-list-item', { hasText: Vendor }).click();
        console.log("Debit Note Vendor Selected = ", Vendor);
        await page.waitForTimeout(1000);
    }
    await page.locator(locators.Debit_Note.Search).click();
    await page.waitForTimeout(2000);
}

async function Customer_Search_CreditNote(page, Customer) {
    console.log("=======================================");
    console.log("Credit Note Page new added User View");
    console.log("=======================================");
    await page.waitForTimeout(1000);
    await page.locator(locators.salesmenu.transaction).click();
    await page.locator(locators.Credit_Note.Credit_Note_Menu).click();
    console.log("Credit Note Menu click ");
    if (Customer != null) {
        await page.waitForTimeout(1000);
        // Use force click to bypass intercepting elements
        await page.locator(locators.Credit_Note.Customer_Class).click();
        await page.fill(locators.Credit_Note.Customer_ID, Customer);
        await page.locator('li.e-list-item', { hasText: Customer }).click();

        console.log("Credit Note customer Selected = ", Customer);
    }
    // Search Customer
    await page.locator(locators.Credit_Note.Search).click();
    await page.waitForTimeout(1000);
}


async function Get_Current_Date_Time() {
    let now = new Date();
    let year = now.getFullYear();
    let month = String(now.getMonth() + 1).padStart(2, '0');
    let day = String(now.getDate()).padStart(2, '0');
    let hours = String(now.getHours()).padStart(2, '0');
    let minutes = String(now.getMinutes()).padStart(2, '0');
    let seconds = String(now.getSeconds()).padStart(2, '0');

    let date = `${year}-${month}-${day}`;
    let time = `${hours}:${minutes}:${seconds}`;

    return `${date}_${time}`;
}

async function Generate_Unique_String(length = 6) {
    let chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
    let result = '';
    let timestamp = Date.now().toString(36); // Convert timestamp to base-36 string

    for (let i = 0; i < length; i++) {
        let randomIndex = Math.floor(Math.random() * chars.length);
        result += chars[randomIndex];
    }
    console.log("Time = ", timestamp);
    console.log("result", result);
    return timestamp + result;
}

async function Generate_Unique_Address(length = 10) {
    let chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let result = '';
    let timestamp = Date.now().toString(36); // Convert timestamp to base-36 string

    for (let i = 0; i < length; i++) {
        let randomIndex = Math.floor(Math.random() * chars.length);
        result += chars[randomIndex];
    }
    console.log("Time = ", timestamp);
    console.log("result", result);
    return timestamp + result;
}


/*
// User Edit name wise try
async function EditUser(page, Find_Name, Name, GST_No, Client_Code, Email, Mobile, Alter_mobile, Pincode, Address, State, City, Area) {
    await page.waitForSelector('tr[aria-rowindex]', { state: 'visible', timeout: 120000 });

    let userFound = false;
    let currentPage = 1;
    
    while (!userFound) {
        console.log(`Searching page ${currentPage}...`);
        const rows = await page.locator('tr[aria-rowindex]');
        const rowCount = await rows.count();
        console.log(`Page ${currentPage}, Row Count: ${rowCount}`);
    
        for (let i = 0; i < rowCount; i++) {
            const row = await rows.nth(i);
            const userNameElement = await row.locator('td').nth(1); // Adjust column index if necessary
    
            try {
                const userName = await userNameElement.textContent({ timeout: 8000 });
                console.log(`Row ${i}: ${userName?.trim()}`);
                if (userName && userName.trim() === Find_Name) {
                    console.log(`User found at row ${i} on page ${currentPage}`);
                    await row.locator(locators.Edit).click();
                    userFound = true;
                    break;
                }
            } catch (e) {
                console.error(`Error at row ${i}: ${e.message}`);
            }
        }
    
        if (!userFound) {
            try {
                const nextPageButton = page.locator('button[aria-label="Next Page"]'); // Adjust selector
                if (await nextPageButton.isVisible({ timeout: 5000 })) {
                    console.log(`Navigating to next page (${currentPage + 1})`);
                    await nextPageButton.click();
                    await page.waitForTimeout(3000); // Wait for next page to load
                    currentPage++;
                } else {
                    console.log("Next Page button not visible. Ending pagination.");
                    break; // Exit the loop if no more pages
                }
            } catch (e) {
                console.error(`Pagination error on page ${currentPage}: ${e.message}`);
                break; // Exit the loop if an error occurs
            }
        }
    }
    
    if (!userFound) {
        throw new Error(`User with name ${Find_Name} not found`);
    }
    

    // Wait for the edit page to load
    await page.waitForSelector(locators.Entry_Edit.Account_Name, { state: 'visible' });

    // Fill in the details
    await page.fill(locators.Entry_Edit.Account_Name, Name);
    await page.fill(locators.Entry_Edit.Mobile, Mobile);
    await page.fill(locators.Entry_Edit.Address, Address);

    // State Selection
    await page.locator(locators.Entry_Edit.State_SpanClass).click();
    await page.fill(locators.Entry_Edit.State_Input, State);
    await page.locator('li.e-list-item', { hasText: State }).click();

    // City Selection
    await page.locator(locators.Entry_Edit.City_SpanClass).click();
    await page.fill(locators.Entry_Edit.City_Input, City);
    await page.locator('li.e-list-item', { hasText: City }).click();

    // Area Selection
    await page.locator(locators.Entry_Edit.Area_SpanClass).click();
    await page.fill(locators.Entry_Edit.Area_Input, Area);
    await page.locator('li.e-list-item', { hasText: Area }).click();

    // Submit the form
    await page.locator(locators.Entry_Edit.Submit).click();

    // Wait for success confirmation
    await page.waitForSelector('div.success-message', { timeout: 10000 });
}*/

async function User_GST_State_Edit_By_Enterin_Name(page, Customer, GST_No, State) {
    await page.waitForTimeout(1000);
    let Customer_Grid, j;
    console.log("==== Edit User ==== ");
    if (Customer != null) {
        await page.fill(locators.Full_Name_Grid, Customer);
        await page.keyboard.press('Enter');
        console.log("Enter User name ", Customer, "And Enter Clicked.");
        for (let i = 0; i <= 7; i++) {
            await page.locator(locators.Name_Cloumn).nth(i).click();
            Customer_Grid = await page.locator(locators.Name_Cloumn).nth(i).textContent();
            if (Customer_Grid == Customer) {
                j = i;
                await page.locator(locators.Action_Column).nth(j).click();
                console.log("Edit Column Click");
                // await page.locator(locators.Edit).nth(j).click();
                // console.log("Edit Btn Click");
                break;
            }
        }
    }
    if (j != null) {
        await page.waitForTimeout(2000);
        if (GST_No != null) {
            await page.locator(locators.Entry_Edit.GSTIN_No).click();
            await page.fill(locators.Entry_Edit.GSTIN_No, GST_No);
            console.log("GST No fill = ", GST_No);
        }
        if (GST_No == null) {
            await page.locator(locators.Entry_Edit.GSTIN_No).click();
            await page.press(locators.Entry_Edit.GSTIN_No, 'Control+A'); // Select all text
            await page.press(locators.Entry_Edit.GSTIN_No, 'Backspace'); // Delete selected text
            console.log("GST No fill Removed");
        }
        if (State != null) {
            await page.locator(locators.Entry_Edit.State_SpanClass).click();
            await page.waitForTimeout(1000);
            await page.fill(locators.Entry_Edit.State_Input, State);
            await page.locator('li.e-list-item', { hasText: State }).waitFor({ state: 'visible' });
            await page.waitForTimeout(1000);
            await page.locator('li.e-list-item', { hasText: State }).click();
            console.log("State Selected = ", State);
        }
        await page.waitForTimeout(1000);
        await page.locator(locators.Entry_Edit.Submit).click();
        console.log("Submit Btn click");
        j = null;
        await page.waitForTimeout(3000);
    }
}

module.exports = {
    VerifyAccountPage, Pagination_Checking, AccountMenuSelected, AddUser, EditUser, Reset_Demo,
    Area, ViewVendor, ViewCustomer, AMC_With_GST_Customer, Sales_Return_Customer, Bank_Ledger, Purchase_Return,
    Cash_Ledger, Debit_Note, Customer_Search_CreditNote, Get_Current_Date_Time, Generate_Unique_String,
    Generate_Unique_Address, User_GST_State_Edit_By_Enterin_Name
};