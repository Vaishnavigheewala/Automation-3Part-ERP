const { test, expect } = require('@playwright/test');
const locators = require('./deletepurchase.json');



async function DeletePage(page,vendor,Payment,inventoryName) {

    await page.click(locators.deletemenu.transaction);
    await page.click(locators.deletemenu.purchase_menu);
    await page.click(locators.deletemenu.purchase_gstpurchase);


 await page.locator("#PurchaseListSearchButton").click();

    await page.waitForSelector("//td[@id='PurchaseRegularBillNumberColumn']");

    // Fetch the latest ticket number from the ticket no column
    const latestBillNo = await page.locator("//td[@id='PurchaseRegularBillNumberColumn']").nth(0).textContent();

    if (!latestBillNo || latestBillNo.trim() === "") {
        console.log('No latest ticket number found. Exiting...');


    }

    console.log(`Latest Ticket No: ${latestBillNo.trim()}`);

    await page.waitForTimeout(3000);

    await page.locator(locators.deletemenu.delete_menu).click();
    await page.locator(locators.deletemenu.delete_purchase).click();
    await page.locator(locators.deletemenu.delete_gstpurchase).click();
    await page.waitForTimeout(2000);
    // Enter the sales bill number
    await page.locator(locators.deletesalepage.purchaseNoField).fill(latestBillNo);
    await page.waitForTimeout(2000);
    // Select the "Purchase without Ledger (Payment)" radio button
    await page.locator(locators.deletesalepage.purchaseRadioButton).scrollIntoViewIfNeeded();
    await page.locator(locators.deletesalepage.purchaseRadioButton).check({ force: true });
    // Click the Delete button
    await page.waitForTimeout(2000);
    await page.locator(locators.deletesalepage.purchaseDeleteButton).click();
    await page.waitForTimeout(2000);

    //verify purchase grid

    await page.click(locators.deletemenu.transaction);
    await page.click(locators.deletemenu.purchase_menu);
    await page.click(locators.deletemenu.purchase_gstpurchase);

    await page.waitForTimeout(2000);

    await page.evaluate(() => window.scrollTo(0, document.body.scrollHeight));

    let billFound = false;

    // Get all rows in the grid
    await page.waitForSelector('tr[aria-rowindex]', { state: 'visible' });
    const rows = await page.locator('tr[aria-rowindex]');
    const rowCount = await rows.count();
    console.log(` Total rows in grid: ${rowCount}`);


    // Iterate through each row to check if the deleted amc number exists
    for (let i = 0; i < rowCount; i++) {
        const currentRow = await rows.nth(i);
        const billNumberCell = await currentRow.locator("td#PurchaseRegularBillNumberColumn").innerText();

        // Debug log for current amc number in grid
        console.log(`Row ${i + 1} Bill Number:`, billNumberCell);


        if (billNumberCell === latestBillNo) {
            billFound = true;
            break;
        }
    }

    // Assert that the deleted amc number is not found in the grid
    expect(billFound).toBe(false);
    if (!billFound) {
        console.log(` Successfully verified that deleted bill number ${latestBillNo} is not present in the sales grid.`);
    } else {
        console.error(` Error - Deleted bill number ${latestBillNo} was found in the sales grid.`);
    }

    await page.waitForTimeout(2000);

    //purchase return page 
    await page.click(locators.deletemenu.transaction);
    await page.locator(locators.deletemenu.purchase_menu).click();
    await page.locator(locators.deletemenu.purchase_return).click();

    const AddpurchaseReturn = await page.locator(locators.AddpurchaseReturn);
    await expect(AddpurchaseReturn).toBeVisible();
    await page.locator(locators.AddpurchaseReturn).click();
    await page.waitForTimeout(2000);
    await page.locator(locators.vendordropdown).click();
    await page.waitForTimeout(1000);
    await page.fill(locators.entervendorname, vendor);
    await page.locator('li.e-list-item', { hasText: vendor }).click();
    await page.locator(locators.bildropdown).click(); // Update with the actual selector
    await page.waitForTimeout(2000);
    await page.fill(locators.entervendorname, latestBillNo);
    const purchaseReturnOptions = await page.locator('li.e-list-item');
    let billFoundpurchase = false;

    // Loop through the options and check if the city is available
    const optionCount = await purchaseReturnOptions.count();
    for (let i = 0; i < optionCount; i++) {
        const optionText = await purchaseReturnOptions.nth(i).innerText();
        if (optionText === latestBillNo) {
            billFoundpurchase = true;
            break;
        }
    }


    // Assert that the city is found in the dropdown
    expect(billFoundpurchase).toBe(false);
    console.log(` "${latestBillNo}" not found in  dropdown`);

       //cashLedger page
       await page.click(locators.deletemenu.transaction);
       await page.locator(locators.deletemenu.ledger).click();
       await page.locator(locators.deletemenu.cashLedger).click();
    
       const AddCashLeger = await page.locator(locators.AddCashLedger);
       await expect(AddCashLeger).toBeVisible();
       await page.locator(locators.AddCashLedger).click();
       await page.locator(locators.PaymentNatureDropdown).click();
       await page.waitForTimeout(2000);
       await page.fill(locators.enterPaymentNature, Payment);
       await page.locator('li.e-list-item', { hasText: Payment }).click();
       await page.locator(locators.vendordropdown).click();
       await page.waitForTimeout(2000);
       await page.fill(locators.entervendorname, vendor);
       await page.locator('li.e-list-item', { hasText: vendor }).click();
       await page.waitForTimeout(1000);
       await page.fill(locators.totalreceiveamt, "");
       await page.waitForTimeout(1000);
       await page.fill(locators.totalreceiveamt, "10000");
       await page.waitForTimeout(1000);
       await page.locator(locators.AddbuttonCash).click();
    await page.click(locators.selectbilltype);
    await page.click("//li[normalize-space()='Purchase']");
   
    await page.locator(locators.billno).click();
    await page.locator(locators.billno).click();
    const LedgerOptions = await page.locator('li.e-list-item');
    let billFoundLedger = false;

    // Loop through the options and check if the city is available
    const optionCount1 = await LedgerOptions.count();
    for (let i = 0; i < optionCount1; i++) {
        const optionText = await LedgerOptions.nth(i).innerText();
        if (optionText === latestBillNo) {
            billFoundLedger = true;
            break;
        }
    }


    // Assert that the city is found in the dropdown
    expect(billFoundLedger).toBe(false);
    console.log(` "${latestBillNo}" not found in  dropdown`);


    //Purchase itemwise Report 
    await page.locator(locators.reportsmenu.Reportmenu).click();
    await page.locator(locators.reportsmenu.purchase_menu).click();
    await page.locator(locators.reportsmenu.reportitemwise).click();
    await page.locator(locators.Itemwise.Filterbtnpurchaseitemwisereport).click();
    await page.locator(locators.Itemwise.Filtervensitemwise).click();
    await page.waitForTimeout(1000);
    await page.fill(locators.entervendorname, vendor);
    await page.locator('li.e-list-item', { hasText: vendor }).click();
    await page.waitForTimeout(1000);
    await page.locator(locators.Itemwise.Searchbtnpurchaseitemwise).click();
    await page.evaluate(() => window.scrollTo(0, document.body.scrollHeight));
    let billFounditem = false;
  
    // Get all rows in the grid
    await page.waitForSelector('tr[aria-rowindex]', { state: 'visible' });
    const rowitem = await page.locator('tr[aria-rowindex]');
    const rowCountitem = await rowitem.count();
    console.log(` Total rows in grid: ${rowCountitem}`);
    
    // Iterate through each row to check if the deleted bill number exists
    for (let i = 0; i < rowCountitem; i++) {  // Loop through all available rows
        const currentRow = await rowitem.nth(i);
      const billNumberCell = await currentRow.locator("td#ItemWisePurchaseReportBillNoColumn").innerText();
  
      // Debug log for current amc number in grid
      console.log(`Row ${i + 1} Bill Number:`, billNumberCell);
  
  
      if (billNumberCell === latestBillNo) {
        billFounditem = true;
        break;
      }
    }
  
    // Assert that the deleted amc number is not found in the grid
    expect(billFounditem).toBe(false);
    if (!billFounditem) {
      console.log(` Successfully verified that deleted bill number ${latestBillNo} is not present in the purchase return itemwise report.`);
    } else {
      console.error(` Error - Deleted bill number ${latestBillNo} was found in the purchase return itemwise report.`);
    }

//Purchase Summary Report 
await page.waitForTimeout(2000);
    await page.locator(locators.reportsmenu.Reportmenu).click();
    await page.locator(locators.reportsmenu.purchase_menu).click();
    await page.locator(locators.reportsmenu.reportsummary).click();
    await page.waitForTimeout(1000);
    await page.locator(locators.Purchasesummary.Filterbtnpurchasesummaryreport).click();
    await page.waitForTimeout(1000);
    await page.locator(locators.Purchasesummary.Filtervenpurchasesummary).click();
    await page.fill(locators.entervendorname, vendor);
    await page.locator('li.e-list-item', { hasText: vendor }).click();
    await page.waitForTimeout(1000);
    await page.locator(locators.Purchasesummary.Searchbtnpurchasesummary).click();
    await page.evaluate(() => window.scrollTo(0, document.body.scrollHeight));
    await page.waitForTimeout(2000);
    let billFoundsummary = false;
  
    // Get all rows in the grid
    await page.waitForSelector('tr[aria-rowindex]', { state: 'visible' });
    const rowsummry = await page.locator('tr[aria-rowindex]');
    const rowCountsummary = await rowsummry.count();
    console.log(` Total rows in grid: ${rowCountsummary}`);
    
    // Iterate through each row to check if the deleted bill number exists
    for (let i = 0; i < rowCountsummary; i++) {  // Loop through all available rows
        const currentRow = await rowsummry.nth(i);
      const billNumberCell = await currentRow.locator("td#PurchaseReportBillNoColumn").innerText();
  
      // Debug log for current amc number in grid
      console.log(`Row ${i + 1} Bill Number:`, billNumberCell);
  
  
      if (billNumberCell === latestBillNo) {
        billFoundsummary = true;
        break;
      }
    }
  
    // Assert that the deleted amc number is not found in the grid
    expect(billFoundsummary).toBe(false);
    if (!billFoundsummary) {
      console.log(` Successfully verified that deleted bill number ${latestBillNo} is not present in the purchase return Summary report.`);
    } else {
      console.error(` Error - Deleted bill number ${latestBillNo} was found in the purchase return Summary report.`);
    }

    //Payable Report
    await page.waitForTimeout(2000);
    await page.locator(locators.reportsmenu.Reportmenu).click();
    await page.locator(locators.reportsmenu.reportpayble).click();
    await page.locator(locators.Payble.FilterbtnpurchasePayblereport).click();
    await page.waitForTimeout(1000);
    await page.locator(locators.Payble.FiltervenpurchasePayble).click();
    await page.fill(locators.entervendorname, vendor);
    await page.locator('li.e-list-item', { hasText: vendor }).click();
    await page.waitForTimeout(1000);
    await page.locator(locators.Payble.SearchbtnpurchasePayble).click();

    await page.evaluate(() => window.scrollTo(0, document.body.scrollHeight));
    await page.waitForTimeout(2000);
    let billFoundpayable = false;
  
    // Get all rows in the grid
    await page.waitForSelector('tr[aria-rowindex]', { state: 'visible' });
    const rowpayable = await page.locator('tr[aria-rowindex]');
    const rowCountpayable = await rowpayable.count();
    console.log(` Total rows in grid: ${rowCountpayable}`);
    
    // Iterate through each row to check if the deleted bill number exists
    for (let i = 0; i < rowCountpayable; i++) {  // Loop through all available rows
        const currentRow = await rowpayable.nth(i);
      const billNumberCell = await currentRow.locator("td#PayableReportBillNoColumn").innerText();
  
      // Debug log for current amc number in grid
      console.log(`Row ${i + 1} Bill Number:`, billNumberCell);
  
  
      if (billNumberCell === latestBillNo) {
        billFoundpayable = true;
        break;
      }
    }
  
    // Assert that the deleted amc number is not found in the grid
    expect(billFoundpayable).toBe(false);
    if (!billFoundpayable) {
      console.log(` Successfully verified that deleted bill number ${latestBillNo} is not present in the payable report.`);
    } else {
      console.error(` Error - Deleted bill number ${latestBillNo} was found in the payable report.`);
    }


    //Vendor Account Ledger
    await page.locator(locators.reportsmenu.Reportmenu).click();
    await page.locator(locators.reportsmenu.accountledger).click();
        await page.locator(locators.reportsmenu.reportvendoraccountledger).click();
        await page.locator(locators.VendorLedger.Filterbtnpurchasevendorledgerreport).click();
        await page.locator(locators.VendorLedger.Filtervenpurchasevendorledger).click();
        await page.fill(locators.entervendorname, vendor);
        await page.locator('li.e-list-item', { hasText: vendor }).click();
        await page.waitForTimeout(1000);
        await page.locator(locators.VendorLedger.Searchbtnpurchasevendorledger).click();
    await page.evaluate(() => window.scrollTo(0, document.body.scrollHeight));
    await page.waitForTimeout(2000);
    let billFoundVAL = false;
  
    // Get all rows in the grid
    await page.waitForSelector('tr[aria-rowindex]', { state: 'visible' });
    const rowpayVAL = await page.locator('tr[aria-rowindex]');
    const rowCountVAL = await rowpayVAL.count();
    console.log(` Total rows in grid: ${rowCountVAL}`);
    
    // Iterate through each row to check if the deleted bill number exists
    for (let i = 0; i < rowCountVAL; i++) {  // Loop through all available rows
        const currentRow = await rowpayVAL.nth(i);
      const billNumberCell = await currentRow.locator("td#VendorAccountLedgerReportGridVendorTransactionNoColumn").innerText();
  
      // Debug log for current amc number in grid
      console.log(`Row ${i + 1} Bill Number:`, billNumberCell);
  
  
      if (billNumberCell === latestBillNo) {
        billFoundVAL = true;
        break;
      }
    }
  
    // Assert that the deleted amc number is not found in the grid
    expect(billFoundVAL).toBe(false);
    if (!billFoundVAL) {
      console.log(` Successfully verified that deleted bill number ${latestBillNo} is not present in the vendor acc ledger report.`);
    } else {
      console.error(` Error - Deleted bill number ${latestBillNo} was found in the vendor acc ledger report.`);
    }

    //Inventory Stock Report 
    await page.locator(locators.reportsmenu.Reportmenu).click();
    await page.locator(locators.reportsmenu.reportinventorystock).click();
    await page.locator(locators.InventoryStock.FilterbtnpurchaseInventorystockreport).click();
    await page.click(locators.InventoryStock.FilterInventorygroup);
    await page.click("//li[normalize-space()='FinishMaterial']");
    console.log("Selected inventory group.");
    await page.locator(locators.InventoryStock.FilterInventoryItem).click();
    await page.fill(locators.InventoryStock.enterInventory, inventoryName);
    await page.locator('li.e-list-item', { hasText: inventoryName }).click();
    await page.waitForTimeout(1000);
    await page.locator(locators.InventoryStock.SearchbtnpurchaseInventorystock).click();

    await page.click('a#InventoryReportViewDetailedinventoryReportButton');

    await page.evaluate(() => window.scrollTo(0, document.body.scrollHeight));
    await page.waitForTimeout(2000);
    let billFoundIV = false;
  
    // Get all rows in the grid
    await page.waitForSelector('tr[aria-rowindex]', { state: 'visible' });
    const rowpayIV = await page.locator('tr[aria-rowindex]');
    const rowCountIV = await rowpayIV.count();
    console.log(` Total rows in grid: ${rowCountIV}`);
    
    // Iterate through each row to check if the deleted bill number exists
    for (let i = 0; i < rowCountIV; i++) {  // Loop through all available rows
        const currentRow = await rowpayIV.nth(i);
      const billNumberCell = await currentRow.locator("td#DetailedInventoryReportGridBillNoColumn").innerText();
  
      // Debug log for current amc number in grid
      console.log(`Row ${i + 1} Bill Number:`, billNumberCell);
  
  
      if (billNumberCell === latestBillNo) {
        billFoundIV = true;
        break;
      }
    }
  
    // Assert that the deleted amc number is not found in the grid
    expect(billFoundIV).toBe(false);
    if (!billFoundIV) {
      console.log(` Successfully verified that deleted bill number ${latestBillNo} is not present in the inventory stock report.`);
    } else {
      console.error(` Error - Deleted bill number ${latestBillNo} was found in the inventory stock report.`);
    }





}



module.exports = {
     DeletePage
};