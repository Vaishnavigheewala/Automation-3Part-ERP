const { test, expect } = require('@playwright/test');
const locators = require('./deletesale.json');



async function DeletePage(page,customername,inventoryName) {

    await page.click(locators.TransactionMenu);
    await page.click(locators.sale);
    await page.click(locators.salepage);

    await page.waitForSelector("//td[@id='SalesRegularBillNumberColumn']");

    // Fetch the latest ticket number from the ticket no column
    const latestBillNo = await page.locator("//td[@id='SalesRegularBillNumberColumn']").nth(0).textContent();

    if (!latestBillNo || latestBillNo.trim() === "") {
        console.log('No latest ticket number found. Exiting...');
       
       
    }

    console.log(`Latest Ticket No: ${latestBillNo.trim()}`);
    await page.waitForTimeout(2000);
    await page.click(locators.delete);
    await page.click(locators.saled);
    await page.click(locators.deletepage);

    // Enter the sales bill number
    await page.locator(locators.deletesalepage.salesNoField).fill(latestBillNo);

    // Select the "Sales without Ledger (Payment)" radio button
    //await page.locator(locators.deletesalepage.salesRadioButton).check();
    await page.locator(locators.deletesalepage.salesRadioButton).scrollIntoViewIfNeeded();
    await page.locator(locators.deletesalepage.salesRadioButton).check({ force: true });
    // Click the Delete button
    await page.locator(locators.deletesalepage.salesDeleteButton).click();
    const successMessage = await page.locator('.e-toast-content');
    await expect(successMessage).toBeVisible();
    await expect(successMessage).toHaveText('GST Sales Deleted Successfully.');
    console.log(`Verified GST Sales record with bill number ${latestBillNo} is deleted.`)
    await page.waitForTimeout(2000);




    //verify Grid where deleted bill number is not present
    await page.click(locators.TransactionMenu);
    await page.click(locators.sale);
    await page.click(locators.salepage);
  /*****************Verify Amc No is not found ************************/
  await page.waitForTimeout(2000);

  await page.evaluate(() => window.scrollTo(0, document.body.scrollHeight));

  let billFound = false;

  // Get all rows in the grid
  await page.waitForSelector('tr[aria-rowindex]', { state: 'visible' });
  const rows = await page.locator('tr[aria-rowindex]');
  const rowCount = await rows.count();
  console.log(` Total rows in grid: ${rowCount}`);


  // Iterate through each row to check if the deleted amc number exists
  for (let i = 0; i < rowCount; i++) {
    const currentRow = await rows.nth(i);
    const billNumberCell = await currentRow.locator("td#SalesRegularBillNumberColumn").innerText();

    // Debug log for current amc number in grid
    console.log(`Row ${i + 1} Bill Number:`, billNumberCell);


    if (billNumberCell === latestBillNo) {
      billFound = true;
      break;
    }
  }

  // Assert that the deleted amc number is not found in the grid
  expect(billFound).toBe(false);
  if (!billFound) {
    console.log(` Successfully verified that deleted bill number ${latestBillNo} is not present in the sales grid.`);
  } else {
    console.error(` Error - Deleted bill number ${latestBillNo} was found in the sales grid.`);
  }

  await page.waitForTimeout(2000);

//Itemwise Report
await page.locator(locators.report).click();
await page.locator(locators.reportsmenu.sales_menu).click();
await page.locator(locators.reportitemwise1).click();
await page.locator(locators.filteritem).click();
await page.waitForTimeout(2000);

    await page.locator(locators.customerfiltersummary).click();
    await page.fill(locators.entercustomername, customername);
    await page.waitForTimeout(1000);
    //  Select the desired customer by its text
    const itemLocator = page.locator(`//td[@title='${customername}']`);
    await expect(itemLocator).toBeVisible();
    await itemLocator.click();
    await page.locator(locators.searchbutton).click();
    await page.waitForTimeout(3000);
    await page.evaluate(() => window.scrollTo(0, document.body.scrollHeight));

    let billFounditem = false;
  
    // Get all rows in the grid
    await page.waitForSelector('tr[aria-rowindex]', { state: 'visible' });
    const rowitem = await page.locator('tr[aria-rowindex]');
    const rowCountitem = await rowitem.count();
    console.log(` Total rows in grid: ${rowCountitem}`);
    
    // Iterate through each row to check if the deleted bill number exists
    for (let i = 0; i < rowCountitem; i++) {  // Loop through all available rows
        const currentRow = await rowitem.nth(i);
      const billNumberCell = await currentRow.locator("td#ItemWiseSalesReportBillNumberColumn").innerText();
  
      // Debug log for current amc number in grid
      console.log(`Row ${i + 1} Bill Number:`, billNumberCell);
  
  
      if (billNumberCell === latestBillNo) {
        billFounditem = true;
        break;
      }
    }
  
    // Assert that the deleted amc number is not found in the grid
    expect(billFounditem).toBe(false);
    if (!billFounditem) {
      console.log(` Successfully verified that deleted bill number ${latestBillNo} is not present in the sales grid.`);
    } else {
      console.error(` Error - Deleted bill number ${latestBillNo} was found in the sales grid.`);
    }

    //sales Summary Report 
    await page.locator(locators.report).click();
await page.locator(locators.reportsmenu.sales_menu).click();
await page.locator(locators.reportsmenu.summaryvise).click();
await page.locator(locators.fillterbuttonsummary).click();
await page.waitForTimeout(2000);

    await page.locator(locators.customerfiltersummary).click();
    await page.fill(locators.entercustomername, customername);
    await page.waitForTimeout(1000);
    //  Select the desired customer by its text
    const itemLocator1 = page.locator(`//td[@title='${customername}']`);
    await expect(itemLocator1).toBeVisible();
    await itemLocator1.click();
    await page.locator(locators.searchbuttonsummary).click();
    await page.waitForTimeout(3000);
    await page.evaluate(() => window.scrollTo(0, document.body.scrollHeight));

    let billFoundsummary = false;
  
    // Get all rows in the grid
    await page.waitForSelector('tr[aria-rowindex]', { state: 'visible' });
    const rowsummry = await page.locator('tr[aria-rowindex]');
    const rowCountsummry = await rowsummry.count();
    console.log(` Total rows in grid: ${rowCountsummry}`);
    
    // Iterate through each row to check if the deleted bill number exists
    for (let i = 0; i < rowCountsummry; i++) {  // Loop through all available rows
        const currentRow = await rowsummry.nth(i);
      const billNumberCell = await currentRow.locator("td#SalesSummaryReportBillNumberColumn").innerText();
  
      // Debug log for current amc number in grid
      console.log(`Row ${i + 1} Bill Number:`, billNumberCell);
  
  
      if (billNumberCell === latestBillNo) {
        billFoundsummary = true;
        break;
      }
    }
  
    // Assert that the deleted amc number is not found in the grid
    expect(billFoundsummary).toBe(false);
    if (!billFoundsummary) {
      console.log(` Successfully verified that deleted bill number ${latestBillNo} is not present in the sales grid.`);
    } else {
      console.error(` Error - Deleted bill number ${latestBillNo} was found in the sales grid.`);
    }

  
//Combine Sale Report
await page.waitForTimeout(1000);
 await page.locator(locators.report).click();
 await page.locator(locators.reportsmenu.sales_menu).click();
 await page.locator(locators.reportsmenu.Combinesales).click();
 await page.locator(locators.fillterbuttoncombine).click();
 await page.waitForTimeout(2000);
 
     await page.locator(locators.customerfiltersummary).click();
     await page.fill(locators.entercustomername, customername);
     await page.waitForTimeout(1000);
     //  Select the desired customer by its text
     const itemLocator2 = page.locator(`//td[@title='${customername}']`);
     await expect(itemLocator2).toBeVisible();
     await itemLocator2.click();
     await page.locator(locators.searchbuttoncombine).click();
     await page.waitForTimeout(3000);
     await page.evaluate(() => window.scrollTo(0, document.body.scrollHeight));
 
     let billFoundcombine = false;
   
     // Get all rows in the grid
     await page.waitForSelector('tr[aria-rowindex]', { state: 'visible' });
     const rowscombine = await page.locator('tr[aria-rowindex]');
     const rowCountcombine = await rowscombine.count();
     console.log(` Total rows in grid: ${rowCountcombine}`);
     
     // Iterate through each row to check if the deleted bill number exists
     for (let i = 0; i < rowCountcombine; i++) {  // Loop through all available rows
         const currentRow = await rowsummry.nth(i);
       const billNumberCell = await currentRow.locator("td#CombinedSalesReportBillNumberColumn").innerText();
   
       // Debug log for current amc number in grid
       console.log(`Row ${i + 1} Bill Number:`, billNumberCell);
   
   
       if (billNumberCell === latestBillNo) {
        billFoundcombine = true;
         break;
       }
     }
   
     // Assert that the deleted amc number is not found in the grid
     expect(billFoundcombine).toBe(false);
     if (!billFoundcombine) {
       console.log(` Successfully verified that deleted bill number ${latestBillNo} is not present in the sales grid.`);
     } else {
       console.error(` Error - Deleted bill number ${latestBillNo} was found in the sales grid.`);
     }
 
  //Outstanding Report
  await page.waitForTimeout(1000);
  await page.locator(locators.report).click();
  await page.locator(locators.reportsmenu.outstanding).click();
  await page.locator(locators.outstandingfilter).click();

  await page.waitForTimeout(2000);
  
      await page.locator(locators.customerfiltersummary).click();
      await page.fill(locators.entercustomername, customername);
      await page.waitForTimeout(1000);
      //  Select the desired customer by its text
      const itemLocator3 = page.locator(`//td[@title='${customername}']`);
      await expect(itemLocator3).toBeVisible();
      await itemLocator3.click();
      await page.locator(locators.outstandingserach).click();
      await page.evaluate(() => window.scrollTo(0, document.body.scrollHeight));
  
      let billFoundout = false;
    
      // Get all rows in the grid
      await page.waitForSelector('tr[aria-rowindex]', { state: 'visible' });
      const rowsout = await page.locator('tr[aria-rowindex]');
      const rowCountout = await rowsout.count();
      console.log(` Total rows in grid: ${rowCountout}`);
      
      // Iterate through each row to check if the deleted bill number exists
      for (let i = 0; i < rowCountout; i++) {  // Loop through all available rows
          const currentRow = await rowsout.nth(i);
        const billNumberCell = await currentRow.locator("td#OutstandingReportBillNumberColumn").innerText();
    
        // Debug log for current amc number in grid
        console.log(`Row ${i + 1} Bill Number:`, billNumberCell);
    
    
        if (billNumberCell === latestBillNo) {
            billFoundout = true;
          break;
        }
      }
    
      // Assert that the deleted amc number is not found in the grid
      expect(billFoundout).toBe(false);
      if (!billFoundout) {
        console.log(` Successfully verified that deleted bill number ${latestBillNo} is not present in the sales grid.`);
      } else {
        console.error(` Error - Deleted bill number ${latestBillNo} was found in the sales grid.`);
      }

//Inventory Stock Report

await page.locator(locators.report).click();
// await page.waitForTimeout(2000);
   await page.locator(locators.reportsmenu.inventoryStock).click();
   await page.click('#InventoryReportopenSideBarButton');
   await page.click(locators.selectinventorygroup);
   //await page.waitForTimeout(1000);
   await page.click("//li[normalize-space()='FinishMaterial']");
   await page.waitForTimeout(1000);
   await page.locator(locators.inventoryselect).click();
   await page.fill(locators.enterInventory, inventoryName);
   await page.locator('li.e-list-item', { hasText: inventoryName }).click();
      await page.locator(locators.inventorysearchbutton).click();
      await page.waitForTimeout(3000);
      await page.evaluate(() => window.scrollTo(0, document.body.scrollHeight));

    await page.click('a#InventoryReportViewDetailedinventoryReportButton');
  
      let billFoundINV = false;
    
      // Get all rows in the grid
      await page.waitForSelector('tr[aria-rowindex]', { state: 'visible' });
      const rowsINV = await page.locator('tr[aria-rowindex]');
      const rowCountINV = await rowsINV.count();
      console.log(` Total rows in grid: ${rowsINV}`);
      
      // Iterate through each row to check if the deleted bill number exists
      for (let i = 0; i < rowCountINV; i++) {  // Loop through all available rows
          const currentRow = await rowsINV.nth(i);
        const billNumberCell = await currentRow.locator("td#DetailedInventoryReportGridBillNoColumn").innerText();
    
        // Debug log for current amc number in grid
        console.log(`Row ${i + 1} Bill Number:`, billNumberCell);
    
    
        if (billNumberCell === latestBillNo) {
            billFoundINV = true;
          break;
        }
      }
    
      // Assert that the deleted amc number is not found in the grid
      expect(billFoundINV).toBe(false);
      if (!billFoundINV) {
        console.log(` Successfully verified that deleted bill number ${latestBillNo} is not present in the sales grid.`);
      } else {
        console.error(` Error - Deleted bill number ${latestBillNo} was found in the sales grid.`);
      }

      //CUSTOMER ACCOUNT LEDGER
      await page.locator(locators.report).click();
      await page.locator(locators.reportsmenu.Accountledger).click();
      await page.locator(locators.reportsmenu.CustomerAccountledger).click();
      await page.locator(locators.CustomerAccountfilterbutton).click();

  await page.waitForTimeout(2000);
  
      await page.locator(locators.customerfiltersummary).click();
      await page.fill(locators.entercustomername, customername);
      await page.waitForTimeout(1000);
      //  Select the desired customer by its text
      const itemLocator5 = page.locator(`//td[@title='${customername}']`);
      await expect(itemLocator5).toBeVisible();
      await itemLocator5.click();
      await page.locator(locators.CustomerAccountsearchbutton).click();
      await page.waitForTimeout(3000);
      await page.evaluate(() => window.scrollTo(0, document.body.scrollHeight));
  
      let billFoundAL = false;
    
      // Get all rows in the grid
      await page.waitForSelector('tr[aria-rowindex]', { state: 'visible' });
      const rowsAL = await page.locator('tr[aria-rowindex]');
      const rowCountAL = await rowsAL.count();
      console.log(` Total rows in grid: ${rowsAL}`);
      
      // Iterate through each row to check if the deleted bill number exists
      for (let i = 0; i < rowCountAL; i++) {  // Loop through all available rows
          const currentRow = await rowsAL.nth(i);
        const billNumberCell = await currentRow.locator("td#AccountLedgerReportGridTransactionNumberColumn").innerText();
    
        // Debug log for current amc number in grid
        console.log(`Row ${i + 1} Bill Number:`, billNumberCell);
    
    
        if (billNumberCell === latestBillNo) {
            billFoundAL = true;
          break;
        }
      }
    
      // Assert that the deleted amc number is not found in the grid
      expect(billFoundAL).toBe(false);
      if (!billFoundAL) {
        console.log(` Successfully verified that deleted bill number ${latestBillNo} is not present in the sales grid.`);
      } else {
        console.error(` Error - Deleted bill number ${latestBillNo} was found in the sales grid.`);
      }






}

module.exports = {
    DeletePage
};