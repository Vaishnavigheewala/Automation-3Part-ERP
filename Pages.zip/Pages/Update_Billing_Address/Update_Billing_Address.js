const { test, expect } = require('@playwright/test');
const { loadEnvFile } = require('process');
const { pathToFileURL } = require('url');
const locators = require('./Update_Billing_Address.json');

let Billing_Address_Text = "";
let Billing_Address_Cheking = "";
let Customer_Quick_View_Billing_Address = "";

async function Update_Billing_Address_Menu_Selection(page) {
    await page.locator(locators.Billing_Address_Menu).click();
    await page.waitForTimeout(600);
}

async function Verify_Page(page) {
    let Verify_Customer = await page.locator(locators.Update_Billing_Address.Customer_Class).isVisible();
    let Verify_Bill = await page.locator(locators.Update_Billing_Address.Bill_No_Class).isVisible();
    let Verify_Delivery_Address = await page.locator(locators.Update_Billing_Address.Delivery_Address).isVisible();
    console.log("Page Have Customer,Bill_No & Delivery_Address = ", Verify_Customer, Verify_Bill, Verify_Delivery_Address);
}

async function Update_Billing_Address(page, Select_Customer, Enter_Updated_Billing_Address) {
    if (Select_Customer != null) {
        // Customer Selection
        await page.locator(locators.Update_Billing_Address.Customer_Class).click();
        await page.waitForTimeout(300);
        await page.fill(locators.Update_Billing_Address.Customer_Input, Select_Customer);
        await page.locator('li.e-list-item', { hasText: Select_Customer }).click();
        await page.waitForTimeout(600);
    }
   
            // Click on the Billing Number field
            await page.locator(locators.Update_Billing_Address.Bill_No_Class).click();
            await page.waitForTimeout(300);

            // Click on the first item from the dropdown
            await page.locator('li.e-list-item').first().click();
            await page.waitForTimeout(600);
        
    
    if (Enter_Updated_Billing_Address != null) {
        await page.fill(locators.Update_Billing_Address.Delivery_Address, Enter_Updated_Billing_Address);
        Billing_Address_Text = Enter_Updated_Billing_Address;
    }
    await page.waitForTimeout(1000);
    await page.locator(locators.Update_Billing_Address.Update).click();
    await page.waitForTimeout(1000);
    let PopUp_After_Update = await page.locator(locators.Update_Billing_Address.Toast).isVisible();
    console.log("Pop Up for toast Message is Visible ? = ", PopUp_After_Update);
}

async function View_Change_Update_Billing_Address(page, Select_Customer) {
    if (Select_Customer != null) {
        // Customer Selection
        await page.locator(locators.Update_Billing_Address.Customer_Class).click();
        await page.waitForTimeout(300);
        await page.fill(locators.Update_Billing_Address.Customer_Input, Select_Customer);
        await page.locator('li.e-list-item', { hasText: Select_Customer }).click();
        await page.waitForTimeout(600);
    }
    // Click on the Billing Number field
    await page.locator(locators.Update_Billing_Address.Bill_No_Class).click();
    await page.waitForTimeout(300);

    // Click on the first item from the dropdown
    await page.locator('li.e-list-item').first().click();
    await page.waitForTimeout(600);

    await page.waitForTimeout(1000);
    Billing_Address_Cheking = await page.locator(locators.Update_Billing_Address.Delivery_Address).inputValue(); // this will store HTML Field Value/Text in variable
    console.log('Address = ', Billing_Address_Text, " & ", Billing_Address_Cheking);
    expect(await page.locator(locators.Update_Billing_Address.Delivery_Address)).toHaveValue(Billing_Address_Text); // this toHaveValue() Match the locator with Variable  
}

async function Customer_Quick_View(page) {
    if (Billing_Address_Text == Billing_Address_Cheking) {
        await page.locator(locators.Customer_Quick_View_Menu).click();
        await page.waitForTimeout(500);
        console.log(' Billing Address = ', Billing_Address_Text);
        // Select Billing Address
        await page.locator(locators.Customer_Quick_View.Delivery_Address_Class).click();
        await page.waitForTimeout(500);
        await page.fill(locators.Customer_Quick_View.Delivery_Address_Input, Billing_Address_Text);
        await page.locator('li.e-list-item', { hasText: Billing_Address_Text }).click();
        await page.waitForTimeout(1000);
        // Search Btn
        await page.locator(locators.Customer_Quick_View.Search).click();
        await page.waitForTimeout(3000);
        // Get Text from HTML Element
        // Customer_Quick_View_Billing_Address = await page.locator(locators.Customer_Quick_View.Grid_Billing_Address).textContent().first();
        // expect(Billing_Address_Text).toBe(Customer_Quick_View_Billing_Address); // this toBe() Match the locator with Variable  
        // console.log('Customer Quick View Billing Address = ', Customer_Quick_View_Billing_Address, "Updated Address = ", Billing_Address_Text);
    }
}

module.exports = { Update_Billing_Address_Menu_Selection, Update_Billing_Address, Verify_Page, View_Change_Update_Billing_Address, Customer_Quick_View };