const { test, expect } = require('@playwright/test');
const locators = require('./ledger.json');
const { TIMEOUT } = require('dns');
const fs = require('fs');


async function selectsubmenuofledger(page,menu) {
    
        if (menu == "Reports") {
            await page.locator(locators.reports_menu.reports).click();
            await page.locator(locators.reports_menu.ledger_menu).click();
            await page.locator(locators.reports_menu.bank_ledger).click();
            await expect(page.locator('li.breadcrumb-item.active', { hasText: 'Bank Ledger Report' })).toBeVisible();
    
        }
}
async function selectfilterResetbank(page,payment_nature, customername) {
    await page.locator(locators.bank_ledger.ledger_filter).click();
    await page.locator(locators.paymentbank).click();
    await page.locator('li.e-list-item', { hasText: payment_nature }).click();
    await page.waitForTimeout(1000);

    await page.locator(locators.customerdropdown).click();
    await page.fill(locators.entercustomername, customername);
    await page.locator('li.e-list-item', { hasText: customername }).click();
    await page.waitForTimeout(1000);
   
    // const datepicker = '#BankLedgerReportDatePicker'; //code to clear the date
    // await page.fill(datepicker, ''); //code to clear the date
    // await page.fill(datepicker, date); //code to enter current data
    await page.locator(locators.bank_ledger.ledger_reset).click();
    await page.locator(locators.bank_ledger.ledger_close).click();

}

async function selectfiltersearchbank(page,payment_nature, customername) {
    await page.locator(locators.bank_ledger.ledger_filter).click();
    await page.locator(locators.paymentbank).click();
    await page.locator('li.e-list-item', { hasText: payment_nature }).click();
    await page.waitForTimeout(1000);

    await page.locator(locators.customerdropdown).click();
    await page.fill(locators.entercustomername, customername);
    await page.locator('li.e-list-item', { hasText: customername }).click();
    await page.waitForTimeout(1000);
   
    // const datepicker = '#BankLedgerReportDatePicker'; //code to clear the date
    // await page.fill(datepicker, ''); //code to clear the date
    // await page.fill(datepicker, date); //code to enter current data
    await page.locator(locators.bank_ledger.ledger_search).click();
    await page.locator(locators.bank_ledger.ledger_back).click();

    const button = await page.locator('span.e-ungroupbutton[title="Ungroup by this column"]').nth(0);
    await button.click();
    await page.locator(locators.bank_ledger.ledger_pdf).click();

    const columns = [
        locators.bank_ledger.VoucherNo,
        locators.bank_ledger.VoucherDate,
        locators.bank_ledger.NatureType,
        locators.bank_ledger.PaymentType,
        locators.bank_ledger.BankName,
        locators.bank_ledger.BankAccNo,
        locators.bank_ledger.BankCharge,
        locators.bank_ledger.ChequeNo,
        locators.bank_ledger.TransactionNo,
        locators.bank_ledger.ExchangeAmt,
        locators.bank_ledger.Blance,

    ];

    for (const column of columns) {
        const isVisible = await page.isVisible(column);
        console.log(`${column} visible: ${isVisible}`);
    }

}

async function sortingbank(page) {
    await page.locator(locators.bank_ledger.voucher_no).dblclick();
    await page.locator(locators.bank_ledger.voucher_no).click();
    console.log(" Bank Ledger Records are sorted by Voucher No.");

}

async function selectfilterResetcash(page,payment_nature, vendorname,customername ) {
    await page.locator(locators.reports_menu.reports).click();
    await page.locator(locators.reports_menu.ledger_menu).click();
    await page.locator(locators.reports_menu.cash_ledger).click();

    await page.locator(locators.cash_ledger.ledger_filter).click();
    await page.locator(locators.paymentcash).click();
    await page.locator('li.e-list-item', { hasText: payment_nature }).click();
    await page.waitForTimeout(1000);

    if (vendorname) {
        console.log(`✅ Selecting Vendor: ${vendorname}`);
        await page.locator(locators.vendorcashdropdown).click();
        await page.fill(locators.entercustomername, vendorname);
        await page.locator('li.e-list-item', { hasText: vendorname }).click();
    } else if (customername) {
        console.log(`✅ Selecting Customer: ${customername}`);
        await page.locator(locators.customerdropdown).click();
        await page.fill(locators.entercustomername, customername);
        await page.locator('li.e-list-item', { hasText: customername }).click();
    } else {
        console.log("⚠️ No vendor or customer provided.");
    }
   
    // const datepicker = '#CashLedgerReportDatePicker'; //code to clear the date
    // await page.fill(datepicker, ''); //code to clear the date
    // await page.fill(datepicker, date); //code to enter current data
    await page.locator(locators.cash_ledger.ledger_reset).click();
    await page.locator(locators.cash_ledger.ledger_close).click();

}

async function selectfilterSearchcash(page,payment_nature, vendorname,customername ) {

    await page.locator(locators.cash_ledger.ledger_filter).click();
    await page.locator(locators.paymentcash).click();
    await page.locator('li.e-list-item', { hasText: payment_nature }).click();
    await page.waitForTimeout(1000);

    if (vendorname) {
        console.log(`✅ Selecting Vendor: ${vendorname}`);
        await page.locator(locators.vendorcashdropdown).click();
        await page.fill(locators.entercustomername, vendorname);
        await page.locator('li.e-list-item', { hasText: vendorname }).click();
    } else if (customername) {
        console.log(`✅ Selecting Customer: ${customername}`);
        await page.locator(locators.customerdropdown).click();
        await page.fill(locators.entercustomername, customername);
        await page.locator('li.e-list-item', { hasText: customername }).click();
    } else {
        console.log("⚠️ No vendor or customer provided.");
    }
   
    // const datepicker = '#CashLedgerReportDatePicker'; //code to clear the date
    // await page.fill(datepicker, ''); //code to clear the date
    // await page.fill(datepicker, date); //code to enter current data
    await page.locator(locators.cash_ledger.ledger_search).click();
    await page.waitForTimeout(1000);
    await page.locator(locators.cash_ledger.ledger_back).click();
    
    await page.locator(locators.cash_ledger.ledger_pdf).click();

}

async function sortingcash(page) {
    const button = await page.locator('span.e-ungroupbutton[title="Ungroup by this column"]').nth(0);
    await button.click();
    await page.locator(locators.cash_ledger.voucher_no).dblclick();
    await page.locator(locators.cash_ledger.voucher_no).click();
    console.log(" Cash Ledger Records are sorted by Voucher No.");

}
module.exports = { selectsubmenuofledger,selectfilterResetbank,selectfiltersearchbank,sortingbank,selectfilterResetcash,selectfilterSearchcash,sortingcash}
