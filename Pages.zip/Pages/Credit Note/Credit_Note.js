const { test, expect } = require('@playwright/test');
const { loadEnvFile } = require('process');
const { pathToFileURL } = require('url');
const locators = require('./Credit_Note.json');
const { Generate_Variable, Delete_Variable, Delete_All_Variables, List_Variables, Get_Current_Date_Time, Generate_Unique_String,
    Generate_Unique_Address, Generate_Random_Mobile_No, Remove_Empty_Strings } = require('../../Dynamic_Variables_Manage/Dynamic_Variable_Manage');

let Outstanding_Grand_Total = "";
let Customer_Account_Ledger_Grand_Total = "";
let Var_Total_Tax_Value;


async function Credit_Note_Menu(page) {
    await page.locator(locators.Credit_Note_Menu).click();
    await page.waitForTimeout(600);
}

async function VerifyCreditNotePage(page) {
    console.log("===============================================");
    console.log("Verify Credit Note page ");
    const Var_Date = await page.locator(locators.Credit_Note.Date).isEnabled();
    await page.waitForTimeout(500);
    //const Var_Customer = await page.locator(locators.Credit_Note.Customer_ID).isEnabled();
    //await page.waitForTimeout(500);
    const Var_PDF = await page.locator(locators.Credit_Note.PDF_Export).isEnabled();
    await page.waitForTimeout(500);
    const Var_Reset = await page.locator(locators.Credit_Note.Reset).isEnabled();
    await page.waitForTimeout(500);
    const Var_Add = await page.locator(locators.Credit_Note.Add_New).isEnabled();
    await page.waitForTimeout(500);
    const Var_Preview = await page.locator(locators.Credit_Note.Page_Preview).isVisible();
    console.log(Var_Date, Var_PDF, Var_Reset, Var_Add, Var_Preview, 'Are Enabled');
}

async function CustomerSearchCreditNote(page, Customer, Date) {

    //await page.locator(locators.Credit_Note.Customer_ID).waitFor({ state: 'visible' });

    if (Customer != null) {
        await page.locator(locators.Credit_Note.Customer_Class).click();
        // Use force click to bypass intercepting elements
        // await page.locator(locators.Credit_Note.Customer_ID).click();
        await page.fill(locators.Credit_Note.Customer_ID, Customer);
        await page.locator('li.e-list-item', { hasText: Customer }).waitFor({ state: 'visible' });
        await page.locator('li.e-list-item', { hasText: Customer }).click();
        console.log("Customer Selectd value is ", Customer);
        await page.waitForTimeout(1000);
    }

    if (Date != null) {
        await page.fill(locators.Credit_Note.Date, Date);
    }

    // Search Customer
    await page.locator(locators.Credit_Note.Search).click();
    console.log("Search Click");
    await page.waitForTimeout(1000);
    // Reset 
    await page.locator(locators.Credit_Note.Reset).click();
    console.log("Reset Click");
    await page.waitForTimeout(500);
}

async function PDFExport(page) {
    await page.locator(locators.Credit_Note.PDF_Export).click();
    console.log("PDF Export Click");
    await page.waitForTimeout(2000);
}

async function ADD_EDIT(page) {
    // Open Add Credit Note Page
    await page.locator(locators.Credit_Note.Add_New).click();
    console.log("Add New Click");
    await page.waitForTimeout(2000);

    // Open View Link  
    await page.locator(locators.Add_Credit_Note.Close_Entry).click();
    console.log("Close Click");
    await page.waitForTimeout(1000);
    const divElement = await page.locator(locators.Credit_Note.Action_Cloumn).first();
    if (!divElement) {
        throw new Error('divElement is not found');
    }
    const elementHandle = await divElement.elementHandle();
    if (elementHandle) {
        await page.evaluate((el) => {
            el.scrollLeft += 600; // Adjust this value to scroll further or slower
        }, elementHandle);
    } else {
        throw new Error('Element handle is not found for divElement');
    }
    await page.waitForTimeout(1000);
    // const rows = await page.locator('tr[aria-rowindex]');
    // const firstRow = await rows.nth(0); // Select the first row 
    // await firstRow.locator(locators.Credit_Note.View).click();
    await page.locator(locators.Credit_Note.View).nth(0).click();
    console.log("First view link Click");
    await page.waitForTimeout(1000);
    // Edit Page 
    await page.locator(locators.Edit).click();
    await page.waitForTimeout(1000);
    // Close Page 
    await page.locator(locators.Add_Credit_Note.Close_Entry).click();
    console.log("Close Click");
    await page.waitForTimeout(1000);
}

async function VerifyAddCreditNotePage(page) {
    console.log("===============================================");
    console.log("Verify Add Credit Note page ");
    // Clicked on Add 
    await page.locator(locators.Credit_Note.Add_New).click();
    console.log("Add New Click");
    await page.waitForTimeout(1000);

    //Editable Text Box
    console.log('Editable fields');
    const Var_Add_Reference_No = await page.locator(locators.Add_Credit_Note.Reference_No).isEnabled();
    //const Var_Add_Customer = await page.locator(locators.Add_Credit_Note.Customer_Input).isEnabled();
    await page.waitForTimeout(500);
    const Var_Add_Remark = await page.locator(locators.Add_Credit_Note.Remark).isEnabled();
    const Var_Add_Note_No = await page.locator(locators.Add_Credit_Note.Note_NO).isEnabled();
    await page.waitForTimeout(500);
    //const Var_Add_Praticulard = await page.locator(locators.Add_Credit_Note.Prticulars_Input).isEnabled();
    const Var_Add_Qty = await page.locator(locators.Add_Credit_Note.Qty).isEnabled();
    await page.waitForTimeout(500);
    const Var_Add_Net_Amount = await page.locator(locators.Add_Credit_Note.Net_Amount).isEnabled();

    console.log('Ensbled =', Var_Add_Reference_No, Var_Add_Remark, Var_Add_Note_No, Var_Add_Qty, Var_Add_Net_Amount);

    //Disabled Text Box
    console.log('Non-Editable fields');
    const Var_Add_Bill_NO = await page.locator(locators.Add_Credit_Note.Bill_No).isDisabled();
    await page.waitForTimeout(500);
    const Var_Add_Mobile = await page.locator(locators.Add_Credit_Note.Mobile).isDisabled();
    const Var_Add_Tex_Method = await page.locator(locators.Add_Credit_Note.Tex_Method).isDisabled();
    await page.waitForTimeout(500);
    // const Var_Add_State = await page.locator(locators.Add_Credit_Note.State_Input).isDisabled();
    const Var_Add_Pos_No = await page.locator(locators.Add_Credit_Note.POS_No).isDisabled();
    await page.waitForTimeout(500);
    const Var_Add_GST_Rate = await page.locator(locators.Add_Credit_Note.GST_Rate).isDisabled();
    const Var_Add_Unit = await page.locator(locators.Add_Credit_Note.Unit).isDisabled();
    await page.waitForTimeout(500);
    const Var_Add_Rate = await page.locator(locators.Add_Credit_Note.Rate).isDisabled();
    const Var_Add_Amount_Tbx = await page.locator(locators.Add_Credit_Note.Amount_Tbx).isDisabled();
    await page.waitForTimeout(500);
    const Var_Add_Total_amount = await page.locator(locators.Add_Credit_Note.Total_Amount).isDisabled();
    const Var_Add_Total_Value = await page.locator(locators.Add_Credit_Note.Total_Tax_Value).isDisabled();
    await page.waitForTimeout(500);
    console.log('Disabled = ', Var_Add_Bill_NO, Var_Add_Mobile, Var_Add_Tex_Method, Var_Add_Pos_No, Var_Add_GST_Rate, Var_Add_Unit, Var_Add_Rate, Var_Add_Amount_Tbx, Var_Add_Total_amount, Var_Add_Total_Value);

}

async function Add_Credit_Note(page, Customer_Add, Particulars_Add, Qty_Add, Net_Amount_Add) {
    console.log("===============================================");
    console.log("Add new Credit Note");
    await page.locator(locators.Credit_Note.Add_New).click();
    await page.waitForTimeout(1000);

    await page.fill(locators.Add_Credit_Note.Qty, Qty_Add);
    await page.fill(locators.Add_Credit_Note.Net_Amount, Net_Amount_Add);
    await page.waitForTimeout(1000);
    await page.locator(locators.Add_Credit_Note.Reset_Entry).click();
    await page.waitForTimeout(500);

    if (Customer_Add != null) {
        //Customer class Selction
        await page.locator(locators.Add_Credit_Note.Customer_Class).click();
        await page.waitForTimeout(500);
        await page.locator(locators.Add_Credit_Note.Customer_Input).click();
        await page.waitForTimeout(500);
        await page.fill(locators.Add_Credit_Note.Customer_Input, Customer_Add);
        await page.locator('li.e-list-item', { hasText: Customer_Add }).waitFor({ state: 'visible' });
        await page.locator('li.e-list-item', { hasText: Customer_Add }).click();
        await page.waitForTimeout(1000);
        console.log("Customer Selectd value is ", Customer_Add);
    }
    if (Particulars_Add != null) {
        //Particulars Selction
        await page.locator(locators.Add_Credit_Note.Prticulars_Class).click();
        await page.waitForTimeout(500);
        await page.locator(locators.Add_Credit_Note.Prticulars_Input).click();
        await page.fill(locators.Add_Credit_Note.Prticulars_Input, Particulars_Add);
        await page.locator('li.e-list-item', { hasText: Particulars_Add }).waitFor({ state: 'visible' });
        await page.locator('li.e-list-item', { hasText: Particulars_Add }).click();
        await page.waitForTimeout(1000);
        console.log("Particulars Selectd value is ", Particulars_Add);
    }
    if (Qty_Add != null) {
        await page.fill(locators.Add_Credit_Note.Qty, Qty_Add);
        console.log("Qut", Qty_Add);
    }
    if (Net_Amount_Add != null) {
        await page.fill(locators.Add_Credit_Note.Net_Amount, Net_Amount_Add);
        await page.waitForTimeout(500);
        console.log("Net Amount", Net_Amount_Add);
        await page.locator(locators.Add_Credit_Note.Total_Tax_Value).click();
        console.log("total tax value click.");
        await page.waitForTimeout(500);
        // Dynamic JSON store value of the net amount 
        Var_Total_Tax_Value = await page.locator(locators.Add_Credit_Note.Total_Tax_Value).inputValue();
        console.log("Total tax", Var_Total_Tax_Value);
        await page.waitForTimeout(1000);
        await Generate_Variable('Credit_Note.Net_Amount', async () => `${Net_Amount_Add}`);
        await Generate_Variable('Credit_Note.Total_Tax_Value', async () => `${Var_Total_Tax_Value}`);
        console.log("Credit note Net Amount & Total Tax Value stored in JSON file.");
    }
    await page.locator(locators.Add_Credit_Note.Submit_Entry).click();
    console.log("Submit Click");
    await page.waitForTimeout(5000);

}

async function Report_Credit_Note(page, Customer_Credit) {
    console.log("===============================================");
    console.log("Credit Note Report");
    // Navigate to Credit Report 
    await page.locator(locators.Report_Credit_Note.Report_Credit_Note).click();
    await page.waitForTimeout(1000);
    // Open Side Bar
    await page.locator(locators.Report_Credit_Note.Credit_Note_side_Bar).click();
    if (Customer_Credit != null) {
        // Select Customer
        await page.waitForTimeout(1000);
        await page.locator(locators.Report_Credit_Note.Filter_Class).click();
        await page.fill(locators.Report_Credit_Note.Filter_Input, Customer_Credit);
        await page.locator('li.e-list-item', { hasText: Customer_Credit }).waitFor({ state: 'visible' });
        await page.waitForTimeout(1000);
        await page.locator('li.e-list-item', { hasText: Customer_Credit }).click();
        console.log("Customer Selectd value is ", Customer_Credit);
    }
    // Search button
    await page.locator(locators.Report_Credit_Note.Search).click();
    console.log("Search Click");
    await page.waitForTimeout(1000);
}

async function Customer_Account_Ledger_Report(page, Customer_LR, OverallBalance) {
    console.log("===============================================");
    console.log("Customer Account Ledger Report");
    // For open the Account Ledger Report & Customer Account Ledger 
    await page.locator(locators.Customer_Account_Ledger.Account_Ledger_Report).click();
    await page.locator(locators.Customer_Account_Ledger.Customer_Account_Ledger_Report).click();
    await page.waitForTimeout(1000);

    // Open Side Bar
    await page.locator(locators.Customer_Account_Ledger.Customer_Account_Ledger_side_Bar).click();
    await page.waitForTimeout(1000);

    if (Customer_LR != null) {
        // Customer Selction 
        await page.locator(locators.Customer_Account_Ledger.Filter_Class).click();
        await page.locator(locators.Customer_Account_Ledger.Filter_Input, Customer_LR);
        await page.locator('li.e-list-item', { hasText: Customer_LR }).waitFor({ state: 'visible' });
        await page.waitForTimeout(1000);
        await page.locator('li.e-list-item', { hasText: Customer_LR }).click();
        console.log("Customer Selectd value is ", Customer_LR);
    }
    // Search Button
    await page.locator(locators.Customer_Account_Ledger.Search).click();
    console.log("Search Click");
    await page.waitForTimeout(1000);

    if (OverallBalance == "Yes") {
        await page.waitForSelector(`tr:has(td:has-text("${Customer_LR}"))`, { timeout: 60000 });
        await page.locator(`tr:has(td:has-text("${Customer_LR}"))`);
        Customer_Account_Ledger_Grand_Total = await page.locator('td.e-summarycell[data-cell="Balance"]').textContent(); // this will store the table cell value in variable
        console.log("customer Ledger Report Overall Balance:", Customer_Account_Ledger_Grand_Total);
        expect(parseFloat(Outstanding_Grand_Total)).toBe(parseFloat(Customer_Account_Ledger_Grand_Total)); // toBe() matchs variables Value are same or not
        console.log("Consistency between Outstanding Report and Account Ledger verified successfully.");
    }
}

async function Outstanding_Reports(page, Customer_OS, OverallBalance) {
    console.log("===============================================");
    console.log("Outstanding Report");
    //Open Outstanding Reports
    await page.locator(locators.Report_Outstanding.Outstanding_Report).click();
    await page.waitForTimeout(1000);

    //Open side Bar 
    await page.locator(locators.Report_Outstanding.Outstanding_Report_Side_Bar).click();
    await page.waitForTimeout(700);

    if (Customer_OS != null) {
        // Customer Selction 
        await page.locator(locators.Report_Outstanding.Filter_Class).click();
        await page.locator(locators.Report_Outstanding.Filter_Input, Customer_OS);
        await page.locator('li.e-list-item', { hasText: Customer_OS }).waitFor({ state: 'visible' });
        await page.waitForTimeout(1000);
        await page.locator('li.e-list-item', { hasText: Customer_OS }).click();
        console.log("Customer Selectd value is ", Customer_OS);
    }
    // Search Button
    await page.locator(locators.Report_Outstanding.Search).click();
    console.log("Search Click");
    await page.waitForTimeout(2000);

    if (OverallBalance == "Yes") {
        await page.waitForSelector(`tr:has(td:has-text("${Customer_OS}"))`, { timeout: 60000 }); // wait up to 60 seconds
        // Now locate the row and get the balance
        await page.locator(`tr:has(td:has-text("${Customer_OS}"))`);
        Outstanding_Grand_Total = await page.locator('td.e-summarycell[data-cell="Balance"]').textContent();
        console.log("Outstanding Report Overall Balance: ", Outstanding_Grand_Total);

    }
}

async function Open_Edit_Credit_Note_Link(page) {
    await page.locator(locators.Credit_Note.View).nth(0).click();
    await page.waitForTimeout(500);
    if (await page.locator(locators.Edit).isVisible() && await page.locator(locators.View_Close).isVisible()) {
        await page.locator(locators.Edit).click();
        console.log("Edit Click");
    }
}

async function Edit_Credit_Note_Page_Verfication(page) {
    console.log("===============================================");
    console.log("Edit Credit Note  Page Verification. ");
    await page.waitForTimeout(500);
    const Disabled_Bill_no = await page.locator(locators.Add_Credit_Note.Bill_No).isDisabled();
    const Disabled_Mobile = await page.locator(locators.Add_Credit_Note.Mobile).isDisabled();
    const Disabled_Tex_Method = await page.locator(locators.Add_Credit_Note.Tex_Method).isDisabled();
    await page.waitForTimeout(500);
    const Disabled_Customer_Address = await page.locator(locators.Add_Credit_Note.Customer_Address).isDisabled();
    const Disabled_State = await page.locator(locators.Add_Credit_Note.State).isDisabled();
    const Disabled_POS_No = await page.locator(locators.Add_Credit_Note.POS_No).isDisabled();
    await page.waitForTimeout(500);
    const Disabled_GSTIN_No = await page.locator(locators.Add_Credit_Note.GSTIN_No).isDisabled();
    const Disabled_Payment_Type = await page.locator(locators.Add_Credit_Note.Payment_Type).isDisabled();
    const Disabled_Invoice_Type = await page.locator(locators.Add_Credit_Note.Invoice_Type).isDisabled();
    await page.waitForTimeout(500);
    const Disabled_HSN_Code = await page.locator(locators.Add_Credit_Note.HSN_Code).isDisabled();
    const Disabled_GST_Rate = await page.locator(locators.Add_Credit_Note.GST_Rate).isDisabled();
    const Disabled_Unit = await page.locator(locators.Add_Credit_Note.Unit).isDisabled();
    await page.waitForTimeout(500);
    const Disabled_Rate = await page.locator(locators.Add_Credit_Note.Rate).isDisabled();
    const Disabled_Amount_Tbx = await page.locator(locators.Add_Credit_Note.Amount_Tbx).isDisabled();
    const Disabled_Total_Amt = await page.locator(locators.Add_Credit_Note.Total_Amount).isDisabled();
    await page.waitForTimeout(500);
    const Disabled_Total_Tax_Value = await page.locator(locators.Add_Credit_Note.Total_Tax_Value).isDisabled();
    console.log("Disabled Fields are following BillNo, Mobile, Tex_Method, Customer_Address, State, POS_No, GSTIN_No, Payment_Type, Invoice_Type,HNS_Code, GST_Rate_ Units, Rate, Amount, Total Amt, Total Taxable Value = ", Disabled_Bill_no, Disabled_Mobile, Disabled_Tex_Method, Disabled_Customer_Address, Disabled_State, Disabled_POS_No, Disabled_GSTIN_No, Disabled_Payment_Type, Disabled_Invoice_Type, Disabled_HSN_Code, Disabled_GST_Rate, Disabled_Unit, Disabled_Rate, Disabled_Amount_Tbx, Disabled_Total_Amt, Disabled_Total_Tax_Value);
}

async function Edit_Credit_Note(page, Edit_Date, Edit_Customer, Edit_Note_NO, Edit_Particulars, Edit_Qty, Edit_Net_Amount) {
    await page.waitForTimeout(1000);
    console.log("===============================================");
    console.log("Edit Credit Note");

    if (Edit_Qty != null) {
        await page.fill(locators.Add_Credit_Note.Qty, Edit_Qty);
        console.log("Qut", Edit_Qty);
        await page.waitForTimeout(500);
    }
    if (Edit_Net_Amount != null) {
        await page.fill(locators.Add_Credit_Note.Net_Amount, Edit_Net_Amount);
        console.log("Net Amount", Edit_Net_Amount);
    }
    await page.waitForTimeout(1000);
    await page.locator(locators.Add_Credit_Note.Submit_Entry).click();
    console.log("Submit Click");
    await page.waitForTimeout(500);
}

async function Newly_Added_Data_check_In_Grid(page) {
    let Bill_No = await page.locator(locators.Credit_Note.Grid.Bill_No).nth(1).textContent();
    console.log("New latest Bill = ",Bill_No); 
    await Generate_Variable('Credit_Note.Bill_No', async () => `${Bill_No}`);
}

module.exports = {
    VerifyCreditNotePage, CustomerSearchCreditNote, PDFExport, Credit_Note_Menu, ADD_EDIT, VerifyAddCreditNotePage,
    Add_Credit_Note, Report_Credit_Note, Customer_Account_Ledger_Report, Outstanding_Reports, Edit_Credit_Note,
    Edit_Credit_Note_Page_Verfication, Open_Edit_Credit_Note_Link, Newly_Added_Data_check_In_Grid
};