const { test, expect } = require('@playwright/test');
const locators = require('./AMC.json');
const fs = require('fs');
const path = require('path');
 
// Define the file path for the variable storage
let filePath = path.join(process.cwd(), 'Dynamic_Variables_Manage/Dynamic_Variable.json');
 
// Ensure the variable file exists
if (!fs.existsSync(filePath)) {
    console.error(`File not found: ${filePath}`);
    process.exit(1);
}
let updatedVariables = JSON.parse(fs.readFileSync(filePath, 'utf-8'));
let Customer_Name = updatedVariables.Customer.Customer_Account_Name;
let InventoryRO_Name = updatedVariables.Inventory.InventoryRO_Name;
let Raw_inventory = updatedVariables.Inventory.Raw_inventory;


async function addamc(page, Customer, Contract, Technician, paymenttype, P_Product, item) {
  await page.locator(locators.amcwithgst.AMC_with_GST_page).click();
  await expect(page.locator('li.breadcrumb-item.active', { hasText: 'AMC With GST Invoice' })).toBeVisible();
  await page.locator(locators.amcwithgst.amcaddnewbutton).click();

  // add customer
  const dropdown = page.locator('span.e-ddl.e-lib.e-input-group.e-control-container.e-control-wrapper.e-multi-column.CommonCustomerDropdownCustomerId').nth(0); // Adjust the index as needed
  await dropdown.click();
  await page.keyboard.press('Enter');
  await page.fill(locators.amcwithgst.entercustomername, Customer);
  await page.locator('li.e-list-item', { hasText: Customer }).click();
  await page.waitForTimeout(2000);

  //add contract
  await page.locator(locators.amcwithgst.contractDropdown).click();
  await page.waitForTimeout(2000);
  await page.locator('li.e-list-item', { hasText: Contract }).click();
  await page.waitForTimeout(2000);

  //add technician
  await page.locator(locators.amcwithgst.techniciandropdown).click();
  await page.waitForTimeout(2000);
  await page.locator('li.e-list-item', { hasText: Technician }).click();
  await page.waitForTimeout(2000);

  //add paymnet type
  await page.locator(locators.amcwithgst.paymenttype).click();
  await page.waitForTimeout(2000);
  await page.locator('li.e-list-item', { hasText: paymenttype }).click();
  await page.waitForTimeout(2000);

  //add number of service
  await page.fill(locators.amcwithgst.noofservice, '2');
  await page.waitForTimeout(2000);

  //add product

  await page.locator(locators.product).nth(0).click();
  await page.locator('li.e-list-item', { hasText: P_Product }).waitFor({ state: 'visible' });
  await page.locator('li.e-list-item', { hasText: P_Product }).click();

  //click on add inventory
  await page.locator(locators.amcwithgst.gridaddbutton).click();

  //select item
  await page.locator(locators.amcwithgst.itemselect).click();
  //await page.fill(locators.amcwithgst.entercustomername, item);
  await page.locator('li.e-list-item', { hasText: item }).click();
  await page.waitForTimeout(2000);

  // await page.locator('td.e-rowcell.e-lastrowcell.e-updatedtd.e-selectionbackground.e-active[aria-label=" Column Header Item"]').click();

  //add qty
  await page.click(locators.amcwithgst.qty);
  await page.fill(locators.amcwithgst.enterqty, '2');
  //  await page.waitForTimeout(2000);

  //add rate
  // await page.click(locators.amcwithgst.rate);
  // await page.waitForTimeout(2000);
  // await page.fill(locators.amcwithgst.enterrate, '2000');
  // await page.waitForTimeout(2000);

  await page.click(locators.amcwithgst.updategrid);
  await page.waitForTimeout(2000);
  await page.click(locators.amcwithgst.updateok);
  
  const netamount = await page.locator(locators.amcwithgst.netamount);
  const netamountValue = await netamount.inputValue();
  console.log(`netamount is Non-Editable and Populated: ${netamountValue}`);
  await page.click(locators.amcwithgst.submitbutton);
  //add amc name
  await page.fill(locators.amcwithgst.amcname, "zinalamc");
  await page.click(locators.amcwithgst.amcsubmit);
  await page.click(locators.amcwithgst.yesbutton);
  await page.waitForTimeout(2000);
  await page.click(locators.amcwithgst.serviceticketclosebutton);
  //check data in grid
  const rows = await page.locator('tr[aria-rowindex]'); // Select all rows with aria-rowindex
  const firstRow = await rows.nth(0);
  await firstRow.locator(locators.amcwithgst.customernamecol);
  await expect(firstRow).toContainText(Customer);
  await page.waitForTimeout(2000);

}



//reports
async function amcreport(page, Customer) {
  await page.locator(locators.Reports.amcreport).click();
  // await expect(page.locator('li.breadcrumb-item.active', { hasText: 'AMC Report' })).toBeVisible();
  await page.locator(locators.Reports.filterbutton).click();
  await page.waitForTimeout(2000);

  //select customer
  const dropdown = page.locator('span.e-ddl.e-lib.e-input-group.e-control-container.e-control-wrapper.e-multi-column.CommonCustomerDropdownCustomerId').nth(0); // Adjust the index as needed
  await dropdown.click();
  await page.waitForTimeout(2000);
  await page.fill(locators.amcwithgst.entercustomername, Customer);
  await page.locator('li.e-list-item', { hasText: Customer }).click();
  await page.waitForTimeout(2000);

  //click on searchbutton
  await page.locator(locators.Reports.searchbuttonamc).click();
}
async function outstanding(page,Customer) {
  await page.locator(locators.Reports.outstandingreport).click();
  // await expect(page.locator('li.breadcrumb-item.active', { hasText: 'AMC Report' })).toBeVisible();
  await page.locator(locators.Reports.filteroutstanding).click();
  await page.waitForTimeout(2000);

  //select customer
  const dropdown = page.locator('span.e-ddl.e-lib.e-input-group.e-control-container.e-control-wrapper.e-multi-column.CommonCustomerDropdownCustomerId').nth(0); // Adjust the index as needed
  await dropdown.click();
  await page.waitForTimeout(2000);
  await page.fill(locators.amcwithgst.entercustomername, Customer);
  await page.locator('li.e-list-item', { hasText: Customer }).click();
  await page.waitForTimeout(2000);

  //click on searchbutton
  await page.locator(locators.Reports.searchbuttonoutstanding).click();
}

async function customerAccountledger(page, Customer) {
  await page.locator(locators.Reports.Accountledgerreport).click();
  await page.locator(locators.Reports.customeraccountledger).click();
  // await expect(page.locator('li.breadcrumb-item.active', { hasText: 'AMC Report' })).toBeVisible();
  await page.locator(locators.Reports.filtercustomer).click();
  await page.waitForTimeout(2000);

  //select customer
  const dropdown = page.locator('span.e-ddl.e-lib.e-input-group.e-control-container.e-control-wrapper.e-multi-column.CommonCustomerDropdownCustomerId').nth(0); // Adjust the index as needed
  await dropdown.click();
  await page.waitForTimeout(2000);
  await page.fill(locators.amcwithgst.entercustomername, Customer);
  await page.locator('li.e-list-item', { hasText: Customer }).click();
  await page.waitForTimeout(2000);

  //click on searchbutton
  await page.locator(locators.Reports.searchcustomer).click();
}

async function Inventorystock(page) {
  await page.locator(locators.Reports.inventoryStock).click();
  await page.locator(locators.Reports.inventoryfilter).click();
  await page.waitForTimeout(2000);


  //await page.click('#InventoryReportopenSideBarButton');
  console.log("Clicked on the Filter button.");
  await page.click(locators.Reports.selectinventorygroup);
  await page.click("//li[normalize-space()='RawMaterial']");
  console.log("Selected inventory group.");
  await page.locator(locators.Reports.inventoryselect).click();
  await page.fill(locators.Reports.enterInventory, Raw_inventory);
  await page.locator('li.e-list-item', { hasText: Raw_inventory }).click();

  await page.waitForTimeout(1000);
  await page.locator(locators.Reports.inventorysearchbutton).click();

  await page.waitForTimeout(3000);
  const divElement = await page.$('div.e-content.e-yscroll.e-lib.e-droppable'); // Replace with your actual selector
  await page.evaluate((el) => {
    el.scrollLeft += 600; // Adjust this value to scroll further or slower
  }, divElement);
  const viewButton = await page.locator('a#InventoryReportViewDetailedinventoryReportButton'); //Adjust this with the actual selector for the "View"

  // Check if the "View" button is visible
  const isVisible = await viewButton.isVisible();
  if (isVisible) {
    console.log('View button is visible. Proceeding with click.');
    await viewButton.click();
    console.log('Clicked on "View" button.');
  } else {
    console.log('View button is not found or not visible.');
  }

}





module.exports = { addamc, amcreport, outstanding, customerAccountledger, Inventorystock};
