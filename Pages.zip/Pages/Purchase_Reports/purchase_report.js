const { test, expect } = require('@playwright/test');
const locators = require('./purchase_report.json');
const { TIMEOUT } = require('dns');
const fs = require('fs');


async function selectsubmenuofpurchase(page,menu) {
    
        if (menu == "Reports") {
            await page.locator(locators.reports_menu.reports).click();
            await page.locator(locators.reports_menu.purchase_menu).click();
            await page.locator(locators.reports_menu.purchase_item).click();
            await expect(page.locator('li.breadcrumb-item.active', { hasText: 'Purchase' })).toBeVisible();
    
        }
}

async function selectfilterResetpurchaseItemwise(page, vendorname ,date ) {

    const backButton = page.locator('button:has-text("Back")');
    const pdfExportButton = page.locator('button:has-text("PDF Export")');
    const filterButton = page.locator('button:has-text("Filter")');
    
    await expect(backButton).toBeVisible();
    await expect(pdfExportButton).toBeVisible();
    await expect(filterButton).toBeVisible();
  
    const button = await page.locator('span.e-ungroupbutton[title="Ungroup by this column"]');
    await button.click();
  
    console.log('Back, PDF Export, and Filter buttons are visible');


        const vendor = await page.isVisible(locators.purchase_itemwise.vendor);
        console.log(`Vendor Name: ${vendor}`);
        const bill = await page.isVisible(locators.purchase_itemwise.itemwise_bill);
        console.log(`bill: ${bill}`);
        const billdate = await page.isVisible(locators.purchase_itemwise.billdate);
        console.log(`bill date : ${billdate}`);
        const Total_qty = await page.isVisible(locators.purchase_itemwise.total_qty);
        console.log(`Total_qty : ${Total_qty}`);
        const gross_rate = await page.isVisible(locators.purchase_itemwise.gross_rate);
        console.log(`gross_rate : ${gross_rate}`);
        const gross_amt = await page.isVisible(locators.purchase_itemwise.gross_amount);
        console.log(`gross_amt : ${gross_amt}`);
        const dis_per = await page.isVisible(locators.purchase_itemwise.dis_per);
        console.log(`dis_per : ${dis_per}`);
        const dis_amt = await page.isVisible(locators.purchase_itemwise.dis_amt);
        console.log(`dis_amt : ${dis_amt}`);
        const tax = await page.isVisible(locators.purchase_itemwise.total_tax);
        console.log(`Taxable Amount : ${tax}`);
        const cgst_per = await page.isVisible(locators.purchase_itemwise.cgst_per);
        console.log(`CGST Per : ${cgst_per}`);
        const cgst_amt = await page.isVisible(locators.purchase_itemwise.cgst_amt);
        console.log(`CGST Amount : ${cgst_amt}`);
        const sgst_per = await page.isVisible(locators.purchase_itemwise.sgst_per);
        console.log(`SGST Per : ${sgst_per}`);
        const sgst_amt = await page.isVisible(locators.purchase_itemwise.sgst_amt);
        console.log(`SGST Amount : ${sgst_amt}`);
        const total_amt = await page.isVisible(locators.purchase_itemwise.total_amt);
        console.log(`total_amt : ${total_amt}`);
  
      await page.locator(locators.purchase_itemwise.purchase_itemwise_filter).click();
  
      await page.locator(locators.purchase_vendor).click();
      await page.fill(locators.enternamevendor, vendorname);
      await page.waitForTimeout(1000);
      
      const datepicker = '#ItemWisePurchaseReportDatePickerForFilter'; //code to clear the date
      await page.fill(datepicker, ''); //code to clear the date
      await page.fill(datepicker, date); //code to enter current data
      await page.locator(locators.purchase_itemwise.purchase_itewise_reset).click();
      await page.waitForTimeout(3000);
      await page.locator(locators.purchase_itemwise.purchase_itewise_close).click();
  
  
  }


  async function selectfilterPurchaseItemwise(page, vendorname ) {
    await page.locator(locators.purchase_itemwise.purchase_itemwise_filter).click();
  
      await page.locator(locators.purchase_vendor).click();
      await page.fill(locators.enternamevendor, vendorname);
      await page.locator('li.e-list-item', { hasText: vendorname }).click();
      await page.waitForTimeout(1000);
      
      await page.locator(locators.purchase_itemwise.purchase_itewise_search).click();
      await page.waitForTimeout(3000);
  
      await page.locator(locators.purchase_itemwise.purchase_itemwise_back).click();
      await page.waitForTimeout(1000);
  
      await page.locator(locators.purchase_itemwise.purchase_pdf).click();
      await page.waitForTimeout(1000);
  
  
  }

  async function sortingItemwise(page) {
    //await page.waitForTimeout(1000);
    await page.locator(locators.purchase_itemwise.itemwise_bill).click();
    await page.waitForTimeout(1000);
    console.log("The report is sorted by Bill No in assending order");
    await page.waitForTimeout(1000);
    await page.locator(locators.purchase_itemwise.itemwise_bill).click();
    await page.waitForTimeout(1000);
    console.log("The report is sorted by Bill No in descending order");
  
    console.log('All verifications completed successfully!');
  }

  
    async function selectfilterResetsummary(page,vendorname,date) {
       

        const backButton = page.locator('button:has-text("Back")');
        const pdfExportButton = page.locator('button:has-text("PDF Export")');
        const filterButton = page.locator('button:has-text("Filter")');
        
        await expect(backButton).toBeVisible();
        await expect(pdfExportButton).toBeVisible();
        await expect(filterButton).toBeVisible();
    
        const button = await page.locator('span.e-ungroupbutton[title="Ungroup by this column"]');
        await button.click();
    
        console.log('Back, PDF Export, and Filter buttons are visible');

        const Regular_bill = await page.isVisible(locators.purchase_summary.Regular_bill);
        console.log(`Regular_bill: ${Regular_bill}`);
        const bill = await page.isVisible(locators.purchase_summary.bill_no);
        console.log(`bill: ${bill}`);
        const billdate = await page.isVisible(locators.purchase_summary.bill_date);
        console.log(`bill date : ${billdate}`);
        const vendor = await page.isVisible(locators.purchase_summary.vendor);
        console.log(`Vendor Name: ${vendor}`);
        const vendor_bill = await page.isVisible(locators.purchase_summary.vendor_bill);
        console.log(`vendor_bill: ${vendor_bill}`);
        const Total_qty = await page.isVisible(locators.purchase_summary.total_qty);
        console.log(`Total_qty : ${Total_qty}`);
        const gross_amt = await page.isVisible(locators.purchase_summary.gross_amount);
        console.log(`gross_amt : ${gross_amt}`);
        const tax = await page.isVisible(locators.purchase_summary.total_tax);
        console.log(`Taxable Amount : ${tax}`);
        const cgst_amt = await page.isVisible(locators.purchase_summary.cgst_amt);
        console.log(`CGST Amount : ${cgst_amt}`);
        const sgst_amt = await page.isVisible(locators.purchase_summary.sgst_amt);
        console.log(`SGST Amount : ${sgst_amt}`);
        const addless_amt = await page.isVisible(locators.purchase_summary.addless_amt);
        console.log(`addless_amt : ${addless_amt}`);
        const roundoff = await page.isVisible(locators.purchase_summary.roundoff);
        console.log(`roundoff : ${roundoff}`);
        const netamt = await page.isVisible(locators.purchase_summary.netamt);
        console.log(`netamt : ${netamt}`);
  

    
        await page.locator(locators.purchase_summary.purchase_summary_filter).click();
  
        await page.locator(locators.purchase_vendor).click();
        await page.fill(locators.enternamevendor, vendorname);
        await page.waitForTimeout(1000);
        
        const datepicker = '#PurchaseReportDatePickerForFilter'; //code to clear the date
        await page.fill(datepicker, ''); //code to clear the date
        await page.fill(datepicker, date); //code to enter current data
        await page.locator(locators.purchase_summary.purchase_summary_reset).click();
        await page.waitForTimeout(3000);
        await page.locator(locators.purchase_summary.purchase_summary_close).click();
        
    }


  async function selectfilterpurchasesummary(page, vendorname) {

    await page.locator(locators.reports_menu.reports).click();
    await page.locator(locators.reports_menu.purchase_menu).click();
    await page.locator(locators.reports_menu.purchase_summary).click();
    await page.locator(locators.purchase_summary.purchase_summary_filter).click();
  
      await page.locator(locators.purchase_vendor).click();
      await page.fill(locators.enternamevendor, vendorname);
      await page.locator('li.e-list-item', { hasText: vendorname }).click();
      await page.waitForTimeout(1000);
      
      await page.locator(locators.purchase_summary.purchase_summary_search).click();
      await page.waitForTimeout(3000);
      await page.locator(locators.purchase_summary.purchasesummary_back).click();
      await page.waitForTimeout(1000);
  
      await page.locator(locators.purchase_summary.purchasesummary_pdf).click();
      await page.waitForTimeout(1000);

}

async function sortingPurchaseSummary(page) {
    //await page.waitForTimeout(1000);
    await page.locator(locators.purchase_summary.summary_bill).click();
    await page.waitForTimeout(1000);
    console.log("The report is sorted by Bill No in assending order");
    await page.waitForTimeout(1000);
    await page.locator(locators.purchase_summary.summary_bill).click();
    await page.waitForTimeout(1000);
    console.log("The report is sorted by Bill No in descending order");
  
    console.log('All verifications completed successfully!');
  }
  


module.exports = { selectsubmenuofpurchase,selectfilterResetpurchaseItemwise,selectfilterPurchaseItemwise,sortingItemwise,selectfilterpurchasesummary,selectfilterResetsummary,sortingPurchaseSummary}