const { test, expect } = require('@playwright/test');
const locators = require('./debitnote.json');
const fs = require('fs');
const path = require('path');
 
// Define the file path for the variable storage
let filePath = path.join(process.cwd(), 'Dynamic_Variables_Manage/Dynamic_Variable.json');
 
// Ensure the variable file exists
if (!fs.existsSync(filePath)) {
    console.error(`File not found: ${filePath}`);
    process.exit(1);
}

let updatedVariables = JSON.parse(fs.readFileSync(filePath, 'utf-8'));
let General_Inventory = updatedVariables.Inventory.General_Inventory;  

async function verifydebitnotepage(page, Vendor) {
    await page.locator(locators.Debitnote.debitnotemenu).click();
    await expect(page.locator('li.breadcrumb-item.active', { hasText: 'Debit Note' })).toBeVisible();


 
    await page.waitForTimeout(1000);
    await page.locator(locators.Debitnote.vendorname).click();
    await page.waitForTimeout(2000);
    await page.fill(locators.Debitnote.entervendorname, Vendor);
    await page.locator('li.e-list-item', { hasText: Vendor }).click();
    await page.waitForTimeout(2000);
    await page.locator(locators.Debitnote.searchbutton).click();
    await page.waitForTimeout(2000);
    await page.locator(locators.Debitnote.ResetButton).click();


    const columns = [
        locators.Grid.Billno,
        locators.Grid.billdate,
        locators.Grid.customername,
        locators.Grid.paytype,
        locators.Grid.Invoicetype,
        locators.Grid.taxmethod,
        locators.Grid.Statename,
        locators.Grid.qty,
        locators.Grid.totaltaxable,
        locators.Grid.netamount,
        locators.Grid.qty,
        locators.Grid.Action,
        locators.Grid.Viewbutton
    ];

    for (const column of columns) {
        const isVisible = await page.isVisible(column);
        console.log(`${column} visible: ${isVisible}`);
    }

    //pdf button
    await page.waitForTimeout(2000);
    await page.click(locators.Debitnote.pdfbutton);
    console.log('PDF download triggered.');
    await page.waitForTimeout(2000);
    //Add new
    await page.click(locators.Debitnote.Addnewbuttondebit);
    console.log('add new triggered.');
    await page.waitForTimeout(3000);
    await page.evaluate(() => { window.scrollTo(0, document.body.scrollHeight); });
    //close button
    await page.waitForTimeout(3000);
    await page.click(locators.Grid.closebutton);
    console.log('close button triggered.');

    //verify view link
    const rows1 = await page.locator('tr[aria-rowindex]'); // Select all rows with aria-rowindex
    const firstRow1 = await rows1.nth(0);
    await page.waitForTimeout(3000);
    await firstRow1.locator(locators.Grid.customername, Vendor);
    await page.waitForTimeout(3000);
    await page.click(locators.Grid.Viewbutton);
    await page.waitForTimeout(3000);
    await page.evaluate(() => { window.scrollTo(0, document.body.scrollHeight); });
    // await page.waitForTimeout(3000);
    await page.click(locators.Debitnote.viewclose);
    console.log("view link verified")




}

async function adddebitnote(page,Vendor) {
    await page.locator(locators.Debitnote.debitnotemenu).click();
    await expect(page.locator('li.breadcrumb-item.active', { hasText: 'Debit Note' })).toBeVisible();

    //click add debit note button
    await page.click(locators.Debitnote.Addnewbuttondebit);
    await page.waitForTimeout(2000);

    // Verify Entry Page Elements

    const Totalamount = await page.isVisible(locators.EntryPage.totalamt);
    const taxableamount = await page.isVisible(locators.EntryPage.totaltaxablevalue);
    const netamount = await page.isVisible(locators.EntryPage.netamount);
    const closebtn = await page.isVisible(locators.Grid.closebutton);
    const resetbtn = await page.isVisible(locators.EntryPage.reset);
    const submitbtn = await page.isVisible(locators.EntryPage.submit);
    const grid = await page.isVisible(locators.EntryPage.formgrid);
    console.log(`total amt displayed: ${Totalamount}`);
    console.log(`taxable amt displayed: ${taxableamount}`);
    console.log(`netamount displayed: ${netamount}`);
    console.log(`closebtn displayed: ${closebtn}`);
    console.log(`resetbtn displayed: ${resetbtn}`);
    console.log(`submitbtn displayed: ${submitbtn}`);
    console.log(`grid displayed: ${grid}`);

    //debit note section
    const date = await page.inputValue(locators.EntryPage.date);
    const currentDate = new Date();
    const formattedDate = `${currentDate.getDate().toString().padStart(2, '0')}-${(currentDate.getMonth() + 1).toString().padStart(2, '0')}-${currentDate.getFullYear()}`;
    expect(date).toBe(formattedDate);
    console.log(`defaulting to current date: ${formattedDate}`);
    //verify vendor dropdown
    const vendorDropdown = page.locator(locators.Debitnote.vendorname);
    await expect(vendorDropdown).toBeVisible();
    await vendorDropdown.click();
    await page.fill(locators.Debitnote.entervendorname, Vendor);
    await page.locator('li.e-list-item', { hasText: Vendor }).click();
    //verify tax method non-editable 

    const taxMethodField = await page.locator(locators.EntryPage.taxmethod);
    await expect(taxMethodField).toHaveAttribute('disabled', 'disabled');
    await expect(taxMethodField).toHaveValue('Exclusive');
    console.log(`tax method is Non-Editable and Populated: ${taxMethodField}`);

    const vendorAddress = page.isVisible(locators.EntryPage.vaddress);
    const stateField = page.locator(locators.EntryPage.state);
    const posNoField = page.locator(locators.EntryPage.PosNo);
    const gstinField = page.locator(locators.EntryPage.GSTNo);

    ;
    await expect(stateField).toHaveAttribute('class', /e-disabled/);
    await expect(posNoField).toHaveAttribute('class', /e-disabled/);
    await expect(gstinField).toHaveAttribute('class', /e-disabled/);
    console.log(`vendorAddress is visible: ${vendorAddress}`);
    console.log(`stateField is Non-Editable and Populated: ${stateField}`);
    console.log(`posNoField is Non-Editable and Populated: ${posNoField}`);
    console.log(`posNoField is Non-Editable and Populated: ${gstinField}`);

    const paymentTypeField = page.locator(locators.EntryPage.Paymenttype);
    await expect(paymentTypeField).toHaveAttribute('disabled', 'disabled');
    await expect(paymentTypeField).toHaveValue('Credit');
    console.log(`payment type is Non-Editable and Populated: ${paymentTypeField}`);

    const invoiceTypeField = page.locator(locators.EntryPage.Invoicetype);
    await expect(invoiceTypeField).toHaveAttribute('disabled', 'disabled');
    await expect(invoiceTypeField).toHaveValue('GST_Tax_Invoice');
    console.log(`invoice type is Non-Editable and Populated: ${invoiceTypeField}`);

    // Verify Particulars Dropdown Displays Inventory with Special Discount
    const Particular = page.locator(locators.EntryPage.Particulars);
    await expect(Particular).toBeVisible();
    await Particular.click();
    await page.fill(locators.Debitnote.entervendorname, General_Inventory);
    await page.locator('li.e-list-item', { hasText: General_Inventory }).click();


    // Verify HSN Code, GST Rate, and Unit are Non-Editable and Populated
    const hsnCodeField = page.locator(locators.EntryPage.HSNcode);
    const gstRateField = page.locator(locators.EntryPage.GSTrate);
    const unitField = page.locator(locators.EntryPage.unit);
    console.log(`HSN code is Non-Editable and Populated: ${hsnCodeField}`);
    console.log(`GST rate is Non-Editable and Populated: ${gstRateField}`);
    console.log(`unit is Non-Editable and Populated: ${unitField}`);

    await page.waitForTimeout(3000);
    // // Verify Qty, Rate, Amount, Total Amount, Total Taxable, and Net Amount Fields
    await page.fill(locators.EntryPage.qty, "2");
    const rateField = page.locator(locators.EntryPage.rate);
    const amountField = page.locator(locators.EntryPage.amount);
    const totalAmountField = page.locator(locators.EntryPage.totalamt);
    const totalTaxableField = page.locator(locators.EntryPage.totaltaxablevalue);
    await page.waitForTimeout(3000);
    await page.fill(locators.EntryPage.netamount, "1000");


    console.log(`rate is Non-Editable and Populated: ${rateField}`);
    console.log(`amount is Non-Editable and Populated: ${amountField}`);
    console.log(`total amount is Non-Editable and Populated: ${totalAmountField}`);
    console.log(`total taxable amount is Non-Editable and Populated: ${totalTaxableField}`);
    await page.waitForTimeout(3000);
    await page.click(locators.EntryPage.reset);
    console.log('Data reset.');
    await page.waitForTimeout(3000);
    const vendorDropdown1 = page.locator(locators.Debitnote.vendorname);
    await expect(vendorDropdown1).toBeVisible();
    await vendorDropdown1.click();
    await page.fill(locators.Debitnote.entervendorname, Vendor);
    await page.locator('li.e-list-item', { hasText: Vendor }).click();
    await page.waitForTimeout(3000);
    const Particular1 = page.locator(locators.EntryPage.Particulars);
    await expect(Particular1).toBeVisible();
    await Particular1.click();
    await page.fill(locators.Debitnote.entervendorname, General_Inventory);
    await page.locator('li.e-list-item', { hasText: General_Inventory }).click();
    await page.waitForTimeout(3000);
    await page.fill(locators.EntryPage.qty, "4");
    await page.waitForTimeout(5000);
    await page.fill(locators.EntryPage.netamount, "5000");
    await page.waitForTimeout(3000);
    // await page.click(locators.EntryPage.submit);
    // console.log('Debit note created');
    // await page.waitForTimeout(3000);
    await page.click(locators.Grid.closebutton);
    // await page.waitForTimeout(2000);
    const rows1 = await page.locator('tr[aria-rowindex]'); // Select all rows with aria-rowindex
    const firstRow1 = await rows1.nth(0);
    await page.waitForTimeout(3000);
    await firstRow1.locator(locators.Grid.customername, Vendor);
    // await expect(firstRow1).toContainText('ZinalAutomation Vendor');
    console.log("data saved in grid")


}

async function debitnotereport(page,Vendor) {
    await page.locator(locators.Debitnotereports.Debitnotereport).click();
    await expect(page.locator('li.breadcrumb-item.active', { hasText: 'Debit Note' })).toBeVisible();
    await page.click(locators.Debitnotereports.sidebar);
    await page.waitForTimeout(3000);
    const vendorDropdown1 = page.locator(locators.Debitnote.vendorname);
    await expect(vendorDropdown1).toBeVisible();
    await vendorDropdown1.click();
    await page.fill(locators.Debitnote.entervendorname, Vendor);
    await page.locator('li.e-list-item', { hasText: Vendor }).click();
    await page.waitForTimeout(3000);
    await page.click(locators.Debitnotereports.searchbutton);



}

async function VendoraccountLedgerreport(page,Vendor) {
    await page.locator(locators.Debitnotereports.AccountLedger).click();
    await page.locator(locators.Debitnotereports.VendorAccountLedger).click();
    await expect(page.locator('li.breadcrumb-item.active', { hasText: 'Vendor Account Ledger' })).toBeVisible();
    await page.click(locators.Debitnotereports.sidebarvendor);
    await page.waitForTimeout(3000);
    const vendorDropdown1 = page.locator(locators.Debitnote.vendorname);
    await expect(vendorDropdown1).toBeVisible();
    await vendorDropdown1.click();
    await page.fill(locators.Debitnote.entervendorname, Vendor);
    await page.locator('li.e-list-item', { hasText: Vendor }).click();
    await page.waitForTimeout(3000);
    await page.click(locators.Debitnotereports.searchbuttonvendor);



}

async function editdebitnote(page,Vendor) {
    await page.locator(locators.Debitnote.debitnotemenu).click();
    await expect(page.locator('li.breadcrumb-item.active', { hasText: 'Debit Note' })).toBeVisible();

    const rows1 = await page.locator('tr[aria-rowindex]'); // Select all rows with aria-rowindex
    const firstRow1 = await rows1.nth(0);
    await page.waitForTimeout(3000);
    await firstRow1.locator(locators.Grid.customername, Vendor);
    await page.waitForTimeout(3000);
    await page.click(locators.Grid.Viewbutton);
    await page.evaluate(() => { window.scrollTo(0, document.body.scrollHeight); });
    await page.waitForTimeout(3000);
    await page.click(locators.Debitnote.edit);
    await page.waitForTimeout(2000);
    await page.fill(locators.EntryPage.qty, "2");
    await page.waitForTimeout(2000);
    await page.click(locators.EntryPage.netamount);
    await page.fill(locators.EntryPage.netamount, "");
    await page.click(locators.EntryPage.netamount);
    await page.waitForTimeout(1000);
    await page.fill(locators.EntryPage.netamount, "1000");
    await page.waitForTimeout(3000);
    await page.click(locators.EntryPage.submit);
    const rows2 = await page.locator('tr[aria-rowindex]'); // Select all rows with aria-rowindex
    const firstRow2 = await rows2.nth(0);
    await page.waitForTimeout(3000);
    await firstRow2.locator(locators.Grid.customername, Vendor);


}



module.exports = { verifydebitnotepage, adddebitnote, debitnotereport, VendoraccountLedgerreport, editdebitnote };