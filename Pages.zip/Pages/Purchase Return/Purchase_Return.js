const { test, expect } = require('@playwright/test');
const fs = require('fs');
const locators = require('./Purchase_Return.json');
const { Generate_Variable, Delete_Variable, Delete_All_Variables, List_Variables, Get_Current_Date_Time, Generate_Unique_String,
  Generate_Unique_Address, Generate_Random_Mobile_No, Remove_Empty_Strings } = require('../../Dynamic_Variables_Manage/Dynamic_Variable_Manage');


async function selectsubmenu(page, menu) {
  if (menu == "Transaction") {
    await page.locator(locators.purchasereturn.purchase).click();
    await page.locator(locators.purchasereturn.purchasereturn).click();
    await expect(page.locator('li.breadcrumb-item.active', { hasText: 'Purchase Return' })).toBeVisible();
  }
}

async function selectsubmenudelete(page, menu) {
  if (menu == "Delete") {
    await page.locator(locators.delete.purchase_menu).click();
    await page.locator(locators.delete.purchase_delet_page).click();
    await expect(page.locator('li.breadcrumb-item.active', { hasText: 'Purchase Return' })).toBeVisible();
  }
}

async function selectvendor(page, vendor) {
  await page.locator(locators.addnew_page.vendorname).click();
  await page.fill(locators.addnew_page.nameinput, vendor);
  await page.locator('li.e-list-item', { hasText: vendor }).click();
  await page.locator("#PurchaseReturnListSearchButton").click();
  await page.locator("#PurchaseReturnListResetButton").click();

}

async function addnewpurchase(page, customer, billnumber) {
  await page.waitForTimeout(2000);
  await page.locator(locators.addnew_page.vendorname).click();
  await page.waitForTimeout(2000);
  await page.fill(locators.addnew_page.nameinput, customer);
  await page.locator('li.e-list-item', { hasText: customer }).click();
  console.log("Vendor name=", customer);
  await page.waitForTimeout(1000);
  await page.locator(locators.addnew_page.Bill_No_P).click();
  await page.waitForTimeout(1000);
  await page.fill(locators.addnew_page.nameinput, billnumber);
  await page.locator('li.e-list-item', { hasText: billnumber }).click();
  console.log("Purchase bill no=", billnumber);
}


async function addsalesdetails(page, gropname, item, qty) {
  await page.locator(locators.addnew_page.purchase_add).click();
  await page.waitForTimeout(500);
  await page.locator(locators.addnew_page.inventorygroup).click(); //Click on Inventory Group
  if (gropname == "FinishMaterial") {
    await page.click(locators.addnew_page.selectfinishmaterial);
  }
  else if (gropname == "RawMaterial") {
    await page.click(locators.addnew_page.selectrawmaterial);
  }
  //await page.locator('td.e-rowcell.e-lastrowcell.e-updatedtd.e-selectionbackground.e-active[aria-label=" Column Header Item"]').click();      
  await page.locator(locators.addnew_page.inventoryitem).click();
  await page.locator('li.e-list-item', { hasText: item }).click();
  await page.locator(locators.clickquantity).click();
  await page.locator(locators.qty).fill(qty);
}

async function Purchase_Return_Qty_chage(page, Qty) {
  await page.waitForTimeout(2000);
  await page.locator(locators.addnew_page.Qty_Column).dblclick();
  console.log(`Qty column click`);
  await page.waitForTimeout(500);
  await page.fill(locators.addnew_page.Qty_Input, Qty);
  await page.locator(locators.addnew_page.purchase_update).click();
  console.log(`Update btn click`);
  await page.waitForTimeout(500);
  await page.locator(locators.addnew_page.Ok_btn_Popup).click();
  console.log(`ok Update btn click`);
  await page.waitForTimeout(500);
  await page.locator(locators.addnew_page.submit_btn).click();
  console.log(`Submit btn click`);
}

async function updatesalesdetails(page) {
  await page.locator(locators.addnew_page.purchase_update).click();
  await page.locator(locators.addnew_page.update_ok).click();
}

async function Purchase_Return_Bill_From_Grid(page, Vendor) {
  await page.waitForTimeout(1000);
  await page.locator(locators.verify_purchase_returnpage.vendorname).click();
  await page.waitForTimeout(1000);
  await page.fill(locators.addnew_page.nameinput, Vendor);
  await page.locator('li.e-list-item', { hasText: Vendor }).click();
  await page.waitForTimeout(1000);
  await page.locator(locators.verify_purchase_returnpage.search_btn).click();
  console.log(`Search Btn Clicked.`);
  let PR_Bill_No = await page.locator(locators.verify_purchase_returnpage.PR_GSTBill_No_Column).textContent();
  await Generate_Variable('SAC_Company.Purchase_Return.Bill_No', async () => `${PR_Bill_No}`);
}

async function storenetamount(page, selector) {
  await page.locator(selector).click();
  const value = await page.locator(selector);
  const rawNetAmount = await value.inputValue();
  const netAmount = parseFloat(rawNetAmount.replace(/,/g, ''));
  return netAmount;
}

async function verifydetails(page) {
  /*****************Verify Customer Name is Correct ************************/
  const Verifycustomer = JSON.parse(fs.readFileSync('Verifycustomer.json')); //Read the shared Net Amount from the JSON file
  const sharedcustomername = Verifycustomer.customername;
  const rows = await page.locator('tr[aria-rowindex]'); // Select all rows with aria-rowindex
  const firstRow = await rows.nth(0); // Select the first row
  await page.waitForTimeout(1000);
  const valuethree = await firstRow.locator("td#ItemWiseSalesReportCustomerNameColumn");
  const customernamecolumn = await valuethree.innerText();
  expect(sharedcustomername).toBe(customernamecolumn);
  console.log(`Customer Name before Submit is same as Customer Name on the Itemwise Sales Report`)
  /*****************Verify Net Amount is Same as Total Amount ************************/
  const data = JSON.parse(fs.readFileSync('Verifynetamount.json')); //Read the shared Net Amount from the JSON file
  const sharedNetAmount = data.netAmount;
  const value = await firstRow.locator("td#ItemWiseSalesReportTotalAmountColumn"); //Extract the Net Amount from the latest row 
  const rawNetAmountcolumn = await value.innerText();
  const netAmountInGrid = parseFloat(rawNetAmountcolumn.replace(/,/g, ''));
  expect(sharedNetAmount).toBe(netAmountInGrid);
  console.log(`Net Amount is same as Total Amount `);
  /*****************Verify correct GST Bill # is displayed  ************************/
  const datatwo = JSON.parse(fs.readFileSync('Verifylatestgstbill.json'));
  const sharedlatestBillNumber = datatwo.latestGstbillnumber;
  const valuetwo = await firstRow.locator("td#ItemWiseSalesReportBillNumberColumn");
  const gstbillonreport = await valuetwo.innerText();
  const numericPart = gstbillonreport.slice(2);
  const gstBillNumber = parseInt(numericPart, 10);
  expect(sharedlatestBillNumber).toBe(gstBillNumber);
  console.log(`Correct GST Bill # is displayed `);

}

async function deletepurchase(page, vendor, inventoryName) {
  await page.click(locators.purchasereturn.transactionMenu);
  await page.click(locators.purchasereturn.purchase);
  await page.click(locators.purchasereturn.purchasereturn);
  await page.waitForSelector("//td[@id='PurchaseReturnRegularBillNumberColumn']");
  // Fetch the latest ticket number from the ticket no column
  const latestTicketNo = await page.locator("//td[@id='PurchaseReturnRegularBillNumberColumn']").nth(0).textContent();
  if (!latestTicketNo || latestTicketNo.trim() === "") {
    console.log('No latest ticket number found. Exiting...');
  }
  console.log(`Latest Ticket No: ${latestTicketNo.trim()}`);
  await page.locator(locators.delete.menu).click();
  await page.locator(locators.delete.purchase_menu).click();
  await page.locator(locators.delete.purchase_delet_page).click();
  await page.locator(locators.delete.purchase_return_no).click();
  await page.fill(locators.delete.purchase_return_no, latestTicketNo);
  await page.locator(locators.delete.purchase_return_radio).click();
  await page.locator(locators.delete.delete_btn).click();
  //itemwise purchase Report
  await page.locator(locators.reportsmenu.Reportmenu).click();
  await page.locator(locators.reportsmenu.purchase_menu).click();
  await page.locator(locators.reportsmenu.reportitemwise).click();
  await page.locator(locators.Itemwise.Filterbtnpurchaseitemwisereport).click();
  await page.locator(locators.Itemwise.Filtervensitemwise).click();
  await page.fill(locators.addnew_page.nameinput, vendor);
  await page.locator('li.e-list-item', { hasText: vendor }).click();
  await page.waitForTimeout(1000);
  await page.locator(locators.Itemwise.Searchbtnpurchaseitemwise).click();
  await page.evaluate(() => window.scrollTo(0, document.body.scrollHeight));
  await page.waitForTimeout(2000);
  let billFounditem = false;
  // Get all rows in the grid
  await page.waitForSelector('tr[aria-rowindex]', { state: 'visible' });
  const rowitem = await page.locator('tr[aria-rowindex]');
  const rowCountitem = await rowitem.count();
  console.log(` Total rows in grid: ${rowCountitem}`);
  // Iterate through each row to check if the deleted bill number exists
  for (let i = 0; i < rowCountitem; i++) {  // Loop through all available rows
    const currentRow = await rowitem.nth(i);
    const billNumberCell = await currentRow.locator("td#ItemWisePurchaseReportBillNoColumn").innerText();
    // Debug log for current amc number in grid
    console.log(`Row ${i + 1} Bill Number:`, billNumberCell);
    if (billNumberCell === latestTicketNo) {
      billFounditem = true;
      break;
    }
  }
  // Assert that the deleted amc number is not found in the grid
  expect(billFounditem).toBe(false);
  if (!billFounditem) {
    console.log(` Successfully verified that deleted bill number ${latestTicketNo} is not present in the purchase return itemwise report.`);
  } else {
    console.error(`Error - Deleted bill number ${latestTicketNo} was found in the purchase return itemwise report.`);
  }
  //Purchase Summary Report 
  await page.locator(locators.reportsmenu.Reportmenu).click();
  await page.locator(locators.reportsmenu.purchase_menu).click();
  await page.locator(locators.reportsmenu.reportsummary).click();
  await page.locator(locators.Purchasesummary.Filterbtnpurchasesummaryreport).click();
  await page.locator(locators.Purchasesummary.Filtervenpurchasesummary).click();
  await page.fill(locators.addnew_page.nameinput, vendor);
  await page.locator('li.e-list-item', { hasText: vendor }).click();
  await page.waitForTimeout(1000);
  await page.locator(locators.Purchasesummary.Searchbtnpurchasesummary).click();
  await page.evaluate(() => window.scrollTo(0, document.body.scrollHeight));
  await page.waitForTimeout(2000);
  let billFoundsummary = false;
  // Get all rows in the grid
  await page.waitForSelector('tr[aria-rowindex]', { state: 'visible' });
  const rowsummry = await page.locator('tr[aria-rowindex]');
  const rowCountsummary = await rowsummry.count();
  console.log(` Total rows in grid: ${rowCountsummary}`);
  // Iterate through each row to check if the deleted bill number exists
  for (let i = 0; i < rowCountsummary; i++) {  // Loop through all available rows
    const currentRow = await rowsummry.nth(i);
    const billNumberCell = await currentRow.locator("td#PurchaseReportBillNoColumn").innerText();
    // Debug log for current amc number in grid
    console.log(`Row ${i + 1} Bill Number:`, billNumberCell);
    if (billNumberCell === latestTicketNo) {
      billFoundsummary = true;
      break;
    }
  }

  // Assert that the deleted amc number is not found in the grid
  expect(billFoundsummary).toBe(false);
  if (!billFoundsummary) {
    console.log(` Successfully verified that deleted bill number ${latestTicketNo} is not present in the purchase return Summary report.`);
  } else {
    console.error(` Error - Deleted bill number ${latestTicketNo} was found in the purchase return Summary report.`);
  }
  //Payable Report
  await page.locator(locators.reportsmenu.Reportmenu).click();
  await page.locator(locators.reportsmenu.reportpayble).click();
  await page.locator(locators.Payble.FilterbtnpurchasePayblereport).click();
  await page.locator(locators.Payble.FiltervenpurchasePayble).click();
  await page.fill(locators.addnew_page.nameinput, vendor);
  await page.locator('li.e-list-item', { hasText: vendor }).click();
  await page.waitForTimeout(1000);
  await page.locator(locators.Payble.SearchbtnpurchasePayble).click();
  await page.evaluate(() => window.scrollTo(0, document.body.scrollHeight));
  await page.waitForTimeout(2000);
  let billFoundpayable = false;
  // Get all rows in the grid
  await page.waitForSelector('tr[aria-rowindex]', { state: 'visible' });
  const rowpayable = await page.locator('tr[aria-rowindex]');
  const rowCountpayable = await rowpayable.count();
  console.log(` Total rows in grid: ${rowCountpayable}`);
  // Iterate through each row to check if the deleted bill number exists
  for (let i = 0; i < rowCountpayable; i++) {  // Loop through all available rows
    const currentRow = await rowpayable.nth(i);
    const billNumberCell = await currentRow.locator("td#PayableReportBillNoColumn").innerText();
    // Debug log for current amc number in grid
    console.log(`Row ${i + 1} Bill Number:`, billNumberCell);
    if (billNumberCell === latestTicketNo) {
      billFoundpayable = true;
      break;
    }
  }
  // Assert that the deleted amc number is not found in the grid
  expect(billFoundpayable).toBe(false);
  if (!billFoundpayable) {
    console.log(` Successfully verified that deleted bill number ${latestTicketNo} is not present in the payable report.`);
  } else {
    console.error(` Error - Deleted bill number ${latestTicketNo} was found in the payable report.`);
  }
  //Vendor Account Ledger
  await page.locator(locators.reportsmenu.Reportmenu).click();
  await page.locator(locators.reportsmenu.accountledger).click();
  await page.locator(locators.reportsmenu.reportvendoraccountledger).click();
  await page.locator(locators.VendorLedger.Filterbtnpurchasevendorledgerreport).click();
  await page.locator(locators.VendorLedger.Filtervenpurchasevendorledger).click();
  await page.fill(locators.addnew_page.nameinput, vendor);
  await page.locator('li.e-list-item', { hasText: vendor }).click();
  await page.waitForTimeout(1000);
  await page.locator(locators.VendorLedger.Searchbtnpurchasevendorledger).click();
  await page.evaluate(() => window.scrollTo(0, document.body.scrollHeight));
  await page.waitForTimeout(2000);
  let billFoundVAL = false;
  // Get all rows in the grid
  await page.waitForSelector('tr[aria-rowindex]', { state: 'visible' });
  const rowpayVAL = await page.locator('tr[aria-rowindex]');
  const rowCountVAL = await rowpayVAL.count();
  console.log(` Total rows in grid: ${rowCountVAL}`);
  // Iterate through each row to check if the deleted bill number exists
  for (let i = 0; i < rowCountVAL; i++) {  // Loop through all available rows
    const currentRow = await rowpayVAL.nth(i);
    const billNumberCell = await currentRow.locator("td#VendorAccountLedgerReportGridVendorTransactionNoColumn").innerText();
    // Debug log for current amc number in grid
    console.log(`Row ${i + 1} Bill Number:`, billNumberCell);
    if (billNumberCell === latestTicketNo) {
      billFoundVAL = true;
      break;
    }
  }
  // Assert that the deleted amc number is not found in the grid
  expect(billFoundVAL).toBe(false);
  if (!billFoundVAL) {
    console.log(` Successfully verified that deleted bill number ${latestTicketNo} is not present in the vendor acc ledger report.`);
  } else {
    console.error(` Error - Deleted bill number ${latestTicketNo} was found in the vendor acc ledger report.`);
  }
  //Inventory Stock Report 
  await page.locator(locators.reportsmenu.Reportmenu).click();
  await page.locator(locators.reportsmenu.reportinventorystock).click();
  await page.locator(locators.InventoryStock.FilterbtnpurchaseInventorystockreport).click();
  await page.click(locators.InventoryStock.FilterInventorygroup);
  await page.click("//li[normalize-space()='FinishMaterial']");
  console.log(`Selected inventory group.`);
  await page.locator(locators.InventoryStock.FilterInventoryItem).click();
  await page.fill(locators.InventoryStock.enterInventory, inventoryName);
  await page.locator('li.e-list-item', { hasText: inventoryName }).click();
  await page.waitForTimeout(1000);
  await page.locator(locators.InventoryStock.SearchbtnpurchaseInventorystock).click();
  await page.click('a#InventoryReportViewDetailedinventoryReportButton');
  await page.evaluate(() => window.scrollTo(0, document.body.scrollHeight));
  await page.waitForTimeout(2000);
  let billFoundIV = false;
  // Get all rows in the grid
  await page.waitForSelector('tr[aria-rowindex]', { state: 'visible' });
  const rowpayIV = await page.locator('tr[aria-rowindex]');
  const rowCountIV = await rowpayIV.count();
  console.log(` Total rows in grid: ${rowCountIV}`);
  // Iterate through each row to check if the deleted bill number exists
  for (let i = 0; i < rowCountIV; i++) {  // Loop through all available rows
    const currentRow = await rowpayIV.nth(i);
    const billNumberCell = await currentRow.locator("td#DetailedInventoryReportGridBillNoColumn").innerText();
    // Debug log for current amc number in grid
    console.log(`Row ${i + 1} Bill Number:`, billNumberCell);
    if (billNumberCell === latestTicketNo) {
      billFoundIV = true;
      break;
    }
  }
  // Assert that the deleted amc number is not found in the grid
  expect(billFoundIV).toBe(false);
  if (!billFoundIV) {
    console.log(` Successfully verified that deleted bill number ${latestTicketNo} is not present in the inventory stock report.`);
  } else {
    console.error(` Error - Deleted bill number ${latestTicketNo} was found in the inventory stock report.`);
  }
}

module.exports = {
  selectsubmenu, selectvendor, addnewpurchase, addsalesdetails, selectsubmenudelete, verifydetails,
  updatesalesdetails, storenetamount, deletepurchase, Purchase_Return_Bill_From_Grid, Purchase_Return_Qty_chage
};