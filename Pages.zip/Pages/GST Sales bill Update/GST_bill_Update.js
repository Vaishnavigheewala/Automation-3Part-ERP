const { test, expect } = require('@playwright/test');
const locators = require('./GST_bill_Update.json');
const { selectmenu } = require('../02Dashboard/dashboard');


// Function to generate a random 3-digit bill number
function generateRandomBillNo() {
    return Math.floor(1000 + Math.random() * 9000).toString();  // Generates a number between 100 and 999
}

async function Verify_GST_Sales_bill_Update(page, customername) {
    const billno = generateRandomBillNo();  // Generate random bill number

    await page.locator(locators.GST_Sales_Bill_Update.GST_Sales_Bill_Update_menu).click();

    await page.locator(locators.GST_Sales_Bill_Update.GST_Sales_Bill_Update_page).click();
    await page.waitForTimeout(1000);
    console.log('Sucessfully Display GST Sales Update Page');

    const Date_Selector = await page.locator(locators.GST_Sales_Bill_Update.Date_Selector).isVisible();
    const Customer_Dropdown = await page.locator(locators.GST_Sales_Bill_Update.Customer_Dropdown).isVisible();
    const Filter_btn = await page.locator(locators.GST_Sales_Bill_Update.Filter_btn).isVisible();
    const Reset_btn = await page.locator(locators.GST_Sales_Bill_Update.Reset_btn).isVisible();
    const bill_no = await page.locator(locators.GST_Sales_Bill_Update.Bill_no).isVisible();
    const cust_name = await page.locator(locators.GST_Sales_Bill_Update.Customer_Name).isVisible();
    const salse_date = await page.locator(locators.GST_Sales_Bill_Update.Salse_Date).isVisible();
    const net_amt = await page.locator(locators.GST_Sales_Bill_Update.Net_Amt).isVisible();
    const action = await page.locator(locators.GST_Sales_Bill_Update.Action).isVisible();

    console.log("Date Selector Feild Visible :", Date_Selector);
    console.log("Customer Dropdown Feild Visible :", Customer_Dropdown);
    console.log("Filter Button Visible :", Filter_btn);
    console.log("Reset Button Visible :", Reset_btn);
    console.log("Bill Number Feild Visible :", bill_no);
    console.log("Customer Name Feild Visible :", cust_name);
    console.log("Salse Date Feild Visible :", salse_date);
    console.log("Net Amount Feild Visible :", net_amt);
    console.log("Action Feild Visible :", action);

    // await page.locator(locators.GST_Sales_Bill_Update.Date_Selector).click();
    // await page.fill(locators.GST_Sales_Bill_Update.Date_Selector, date);
    await page.waitForTimeout(1000);

    await page.locator(locators.GST_Sales_Bill_Update.Customer_Dropdown).click();
    await page.fill(locators.GST_Sales_Bill_Update.Entercustomername, customername);
    await page.locator('li.e-list-item', { hasText: customername }).click();
    await page.waitForTimeout(1000);

    await page.locator(locators.GST_Sales_Bill_Update.Filter_btn).click();
    //await page.waitForTimeout(1000);

    // await page.locator(locators.GST_Sales_Bill_Update.Reset_btn).click();
    // await page.waitForTimeout(1000);

    await page.locator(locators.GST_Sales_Bill_Update.View_link).first().click();
    await page.waitForTimeout(1000);

    await page.locator(locators.GST_Sales_Bill_Update.Bill_no_input).click();
    await page.fill(locators.GST_Sales_Bill_Update.Bill_no_input, billno);
    await page.waitForTimeout(1000);

    // await page.locator(locators.GST_Sales_Bill_Update.Bill_Date).click();
    // await page.fill(locators.GST_Sales_Bill_Update.Bill_Date, bill_date);
    // await page.waitForTimeout(1000);

    const inventory = await page.locator("//div[@class='card-header']").isVisible();
    console.log("Inventory Section is Visible : ",inventory);

    await page.locator(locators.GST_Sales_Bill_Update.Update_Btn).click();
    await page.waitForTimeout(1000);

    // await page.locator(locators.GST_Sales_Bill_Update.Update_Reset_btn).click();
    // await page.waitForTimeout(1000);
}

async function Verify_Sales_return_reports(page, customername) {
    await page.locator(locators.Sales_Retuen.Salse_menu).click();

    await page.locator(locators.Sales_Retuen.Sales_Retuen_page).click();

    await page.locator(locators.Sales_Retuen.Customer_Name).click();
    await page.fill(locators.Sales_Retuen.Entercustomername, customername);
    await page.locator('li.e-list-item', { hasText: customername }).click();
    await page.locator(locators.Sales_Retuen.Filter_btn).click();
    await page.waitForTimeout(2000);

    await page.locator("a[title='View Sales Return detail']").nth(0).click();

}

async function Verify_Salse_Reports(page, customername) {
    // Item Wise Reports
    await page.locator(locators.item_wise.Salse_menu).click();
    await page.locator(locators.item_wise.item_wise_page).click();

    await page.locator(locators.item_wise.Filter_btn).click();

    await page.locator(locators.item_wise.Customer_Name).click();
    await page.fill(locators.item_wise.Entercustomername, customername);
    await page.locator('li.e-list-item', { hasText: customername }).click();

    await page.locator(locators.item_wise.Search_btn).click();
    await page.waitForTimeout(3000);

    // Sales Summary Reports
    await selectmenu(page, "Reports")
    await page.locator(locators.item_wise.Salse_menu).click();
    await page.locator(locators.item_wise.Salse_Summary_Page).click();
    await page.locator(locators.item_wise.Filter_btn_Summary).click();

    await page.locator(locators.item_wise.Customer_Name_Summary).click();
    await page.fill(locators.item_wise.Entercustomername, customername);
    await page.locator('li.e-list-item', { hasText: customername }).click();

    await page.locator(locators.item_wise.Search_btn_Summary).click();

    // Combined Sales Reports
    await selectmenu(page, "Reports");
    await page.locator(locators.item_wise.Salse_menu).click();
    await page.locator(locators.item_wise.Combine_Sales_Reports).click();
    await page.locator(locators.item_wise.Filter_btn_Combined).click();

    await page.locator(locators.item_wise.Customer_Name_Combined).click();
    await page.fill(locators.item_wise.Entercustomername, customername);
    await page.locator('li.e-list-item', { hasText: customername }).click();

    await page.locator(locators.item_wise.Search_btn_Combined).click();

    // Outstanding Reports

    await selectmenu(page, "Reports");
    await page.locator(locators.item_wise.Outstanding).click();
    await page.waitForTimeout(1000);
    await page.locator(locators.item_wise.Filter_btn_Outstanding).click();

    await page.locator(locators.item_wise.Customer_Name_oustanding).click();
    await page.fill(locators.item_wise.Entercustomername, customername);
    await page.locator('li.e-list-item', { hasText: customername }).click();

    await page.locator(locators.item_wise.Search_btn_Outstanding).click();

    await page.waitForTimeout(2000); 

    // Inventory Stock Reports

    await selectmenu(page, "Reports");
    await page.locator(locators.item_wise.Inventory_Stock).click();
    await page.waitForTimeout(1000);
    await page.locator(locators.item_wise.View_link_Inventory_Stock).nth(0).click();
    await page.waitForTimeout(2000); 
 
    // Customer Account Ledger Reports
    
    await selectmenu(page, "Reports");
    await page.locator(locators.item_wise.Customer_Account_Ledger_Menu).click();
    await page.locator(locators.item_wise.Customer_Account_Ledger_Page).click();
    await page.waitForTimeout(1000);
    await page.locator(locators.item_wise.Filter_btn_Account_Ledger).click();

    await page.locator(locators.item_wise.Customer_Name_Account_Ledger).click();
    await page.fill(locators.item_wise.Entercustomername, customername);
    await page.locator('li.e-list-item', { hasText: customername }).click();

    await page.locator(locators.item_wise.Search_btn_Account_Ledger).click();

    await page.waitForTimeout(2000); 

}

async function Verify_AMC_bill_Update(page,customer) {

    const Amc_search_date = await page.locator(locators.Amc_Bill_Update.Amc_search_date).isVisible();
    const Customer_Dropdown = await page.locator(locators.Amc_Bill_Update.Customer_Dropdown).isVisible();
    const search_btn = await page.locator(locators.Amc_Bill_Update.search_btn).isVisible();
    const reset_btn = await page.locator(locators.Amc_Bill_Update.reset_btn).isVisible();
    const amc_bill_no = await page.locator(locators.Amc_Bill_Update.amc_bill_no).isVisible();
    const amc_customer = await page.locator(locators.Amc_Bill_Update.amc_customer).isVisible();
    const invoice_date = await page.locator(locators.Amc_Bill_Update.invoice_date).isVisible();
    const net_amt = await page.locator(locators.Amc_Bill_Update.net_amt).isVisible();
    const action = await page.locator(locators.Amc_Bill_Update.action).isVisible();

    console.log("Date Selector Feild Visible :", Amc_search_date);
    console.log("Customer Dropdown Feild Visible :", Customer_Dropdown);
    console.log("Filter Button Visible :", search_btn);
    console.log("Reset Button Visible :", reset_btn);
    console.log("Bill Number Feild Visible :", amc_bill_no);
    console.log("Customer Name Feild Visible :", amc_customer);
    console.log("Invoice Date Feild Visible :", invoice_date);
    console.log("Net Amount Feild Visible :", net_amt);
    console.log("Action Feild Visible :", action);

    console.log('All Fields are visible : All Fields are Verify in Search Bill Number Page');
    // await page.locator(locators.Amc_Bill_Update.Amc_search_date).click();
    // await page.fill(locators.Amc_Bill_Update.Amc_search_date,date);
    // await page.waitForTimeout(1000);

    await page.locator(locators.Amc_Bill_Update.Customer_Dropdown).click();
    await page.fill(locators.Amc_Bill_Update.Entercustomername, customer);
    await page.locator('li.e-list-item', { hasText: customer }).click();
    await page.waitForTimeout(1000);

    await page.locator(locators.Amc_Bill_Update.search_btn).click();
    await page.waitForTimeout(1000);

    await page.locator(locators.Amc_Bill_Update.View_link).nth(0).click();
    await page.waitForTimeout(1000);


}

async function Reset_AMC_bill_Update(page,date,customer) {
    await page.locator(locators.Amc_Bill_Update.Amc_Bill_Update_menu).click();

    await page.locator(locators.Amc_Bill_Update.Amc_Bill_Update_page).click();
    await page.waitForTimeout(1000);
    console.log('Sucessfully Display AMC Update Billing Page');

    await page.locator(locators.Amc_Bill_Update.Amc_search_date).click();
    await page.fill(locators.Amc_Bill_Update.Amc_search_date, date);
    await page.waitForTimeout(1000);

    await page.locator(locators.Amc_Bill_Update.Customer_Dropdown).click();
    await page.fill(locators.Amc_Bill_Update.Entercustomername, customer);
    await page.locator('li.e-list-item', { hasText: customer }).click();
    await page.waitForTimeout(1000);

    await page.locator(locators.Amc_Bill_Update.reset_btn).click();
    await page.waitForTimeout(1000);

}

async function view_amc_bill_update(page) {
    const bill_no = await page.locator(locators.view_amc_bill.bill_no).isVisible();
    const customer = await page.locator(locators.view_amc_bill.Customer_Name).isVisible();
    const date = await page.locator(locators.view_amc_bill.date).isVisible();
    const netamt = page.locator(locators.view_amc_bill.net_amt).isVisible();
    const updatebtn = page.locator(locators.view_amc_bill.update_btn).isVisible();
    const resetbtn = page.locator(locators.view_amc_bill.reset_btn).isVisible();

    console.log("Bill No Feild Visible :", bill_no);
    console.log("customer Feild Visible :", customer);
    console.log("date Feild Visible :", date);
    console.log("Net Amount Feild Visible :", netamt);
    console.log("Update button Visible :", updatebtn);
    console.log("Reset button Visible :", resetbtn);

    const Inventory_details_item = await page.locator(locators.view_amc_bill.Inventory_details_item).isVisible();
    const Qty = await page.locator(locators.view_amc_bill.Qty).isVisible();
    const Basic_Rate = await page.locator(locators.view_amc_bill.Basic_Rate).isVisible();
    const CGST_per = await page.locator(locators.view_amc_bill.CGST_per).isVisible();
    const CGST_amt = await page.locator(locators.view_amc_bill.CGST_amt).isVisible();
    const SGST_per = await page.locator(locators.view_amc_bill.SGST_per).isVisible();
    const SGST_amt = await page.locator(locators.view_amc_bill.SGST_amt).isVisible();
    const Total_amt = await page.locator(locators.view_amc_bill.Total_amt).isVisible();

    console.log("Inventory Details Item Feild Visible :", Inventory_details_item);
    console.log("Qty Feild Visible :", Qty);
    console.log("Basic Rate Feild Visible :", Basic_Rate);
    console.log("CGST Per Feild  Visible :", CGST_per);
    console.log("CGST Amt Feild  Visible :", CGST_amt);
    console.log("SGST Per Feild  Visible :", SGST_per);
    console.log("SGST Amt Feild  Visible :", SGST_amt);
    console.log("Total Amt Feild Visible :", Total_amt);
    console.log('All Inventory Details are visible : All Inventory Details are Verify in View Bill Number Page');

    const amc_bill_no = await page.locator(locators.Amc_Bill_Update.amc_bill_no).isVisible();
    const amc_customer = await page.locator(locators.Amc_Bill_Update.amc_customer).isVisible();
    const invoice_date = await page.locator(locators.Amc_Bill_Update.invoice_date).isVisible();
    const net_amt = await page.locator(locators.Amc_Bill_Update.net_amt).isVisible();

    console.log("Bill Number Feild Visible :", amc_bill_no);
    console.log("Customer Name Feild Visible :", amc_customer);
    console.log("Invoice Date Feild Visible :", invoice_date);
    console.log("Net Amount Feild Visible :", net_amt);
    console.log('All Fields are visible : All Fields are Verify in View Bill Number Page');

    await page.locator(locators.view_amc_bill.reset_btn).click();

}

async function update_amc_bill(page) {
    const bill = generateRandomBillNo();  // Generate random 4-digit bill number

    await page.locator(locators.view_amc_bill.bill_no).click();
    await page.fill(locators.view_amc_bill.bill_no, bill);
    await page.waitForTimeout(1000);

    await page.locator(locators.view_amc_bill.update_btn).click();

    // await page.locator(locators.view_amc_bill.bill_no).click();
    // await page.fill(locators.view_amc_bill.bill_no, update_bill);
    // await page.waitForTimeout(1000);

    // await page.locator(locators.view_amc_bill.update_btn).click();
}

async function verify_reports(page,customer) {
    await page.locator(locators.verify_reports.reports).click();
    await page.locator(locators.verify_reports.amc_menu).click();
    await page.locator(locators.verify_reports.amc_filter).click();
    // await page.locator(locators.verify_reports.amc_date).click();
    // await page.fill(locators.verify_reports.amc_date, date);
    await page.waitForTimeout(1000);

    await page.locator(locators.verify_reports.customerdropdown).click();
    await page.fill(locators.verify_reports.entercustomername, customer);
    await page.locator('li.e-list-item', { hasText: customer }).click();
    await page.waitForTimeout(1000);

    await page.locator(locators.verify_reports.amc_search).click();
    await page.waitForTimeout(1000);


    await page.locator(locators.verify_reports.reports).click();
    await page.locator(locators.verify_reports.account_ledger).click();
    await page.locator(locators.verify_reports.customer_ledger).click();
    await page.locator(locators.verify_reports.customer_ledger_filter).click();

    // await page.locator(locators.verify_reports.customer_ledger_date).click();
    // await page.fill(locators.verify_reports.customer_ledger_date, date);
    await page.waitForTimeout(1000);

    await page.locator(locators.verify_reports.customerdropdown).click();
    await page.fill(locators.verify_reports.entercustomername, customer);
    await page.locator('li.e-list-item', { hasText: customer }).click();
    await page.waitForTimeout(1000);

    await page.locator(locators.verify_reports.customer_ledger_search).click();
}

module.exports = { Verify_AMC_bill_Update,Reset_AMC_bill_Update,view_amc_bill_update,update_amc_bill, Verify_GST_Sales_bill_Update, Verify_Sales_return_reports, Verify_Salse_Reports,verify_reports };
