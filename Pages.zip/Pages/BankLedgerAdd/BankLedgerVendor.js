const { test, expect } = require('@playwright/test');
const locators = require('./BankLedger.json');
const fs = require('fs');
const path = require('path');

// Define the file path for the variable storage
let filePath = path.join(process.cwd(), 'Dynamic_Variables_Manage/Dynamic_Variable.json');

// Ensure the variable file exists
if (!fs.existsSync(filePath)) {
  console.error(`File not found: ${filePath}`);
  process.exit(1);
}

let updatedVariables = JSON.parse(fs.readFileSync(filePath, 'utf-8'));
let vendorName = updatedVariables.Vendor.Vendor_Account_Name; 

async function addledgerforpurchase(page) {
    await page.locator(locators.BankLedger.Ledger).click();
    await page.locator(locators.BankLedger.BankLedgerpage).click();
    await expect(page.locator('li.breadcrumb-item.active', { hasText: 'Bank' })).toBeVisible();
    //click on add new button
    await page.locator(locators.BankLedger.AddnewButton).click();
    console.log("Click on Add New Button");
  
    const voucherNo = await page.isDisabled(locators.BankLedger.VoucherNoField);
    console.log(`voucher number Not Editable: ${voucherNo}`);
  
    const date = await page.inputValue(locators.BankLedger.datepickr);
    const currentDate = new Date();
    const formattedDate = `${currentDate.getDate().toString().padStart(2, '0')}-${(currentDate.getMonth() + 1).toString().padStart(2, '0')}-${currentDate.getFullYear()}`;
    expect(date).toBe(formattedDate);
    console.log(`defaulting to current date: ${formattedDate}`);
  
    await page.locator(locators.BankLedger.paymentMethodDropdown).click();
    await page.click("//li[normalize-space()='NEFT']");
  
    await page.locator(locators.BankLedger.TransactionIDTextbox).click();
    await page.fill(locators.BankLedger.TransactionIDTextbox,"10016708239");
    await page.waitForTimeout(1000);
  
    //payment nature 
    await page.locator(locators.BankLedger.Payment_Nature_Class).click();
    await page.click("//li[normalize-space()='Payable']");
  
    const customerDropdown = await page.locator(locators.BankLedger.vendorname);
    await expect(customerDropdown).toBeVisible();
  
    // Warning for missing customer before adding outstanding detail
    await page.click(locators.BankLedger.addgridbtn);
    const warningMessage = await page.locator("text='Please select Vendor'");
    await expect(warningMessage).toBeVisible();
    await page.waitForTimeout(1000);
  
    // Select Customer
    await customerDropdown.click();
    await page.fill(locators.BankLedger.entercustomername, vendorName);
    await page.locator('li.e-list-item', { hasText: vendorName }).click();
    await page.waitForTimeout(1000);
  
    await page.locator(locators.BankLedger.total_receive).click();
    await page.waitForTimeout(1000);
    await page.fill(locators.BankLedger.total_receive,"50000");
    await page.waitForTimeout(1000);
  
    //verify outstanding details
    await page.click(locators.BankLedger.addgridbtn);
    await page.locator(locators.BankLedger.billtype).click();
    await page.click(locators.BankLedger.selectpurchase);
    await page.waitForTimeout(3000);
    //bill no
  
    //await page.waitForTimeout(1000);
    await page.locator(locators.BankLedger.billno).click();
    await page.locator(locators.BankLedger.billnumber).click();
    // Wait for dropdown options to load
    await page.waitForTimeout(1000);
  
    // Get the first bill number from the dropdown
    const firstBill = await page.locator('li.e-list-item').first().textContent();
  
    // Check if a bill number exists before selecting
    if (firstBill) {
        console.log(`Selecting first bill: ${firstBill}`);
        await page.locator('li.e-list-item', { hasText: firstBill }).click();
    } else {
        console.log("No bill number found in the dropdown.");
    }
  
    await page.waitForTimeout(1000);
  
    // Verify Net Outstanding Amount matches the Bill Amount and Outstanding Amount
    await page.waitForSelector(locators.BankLedger.netoutstandingamount, { state: 'visible' });
    await page.waitForSelector('td#BankLedgerEntryBillAmtColumn', { state: 'visible' });
    await page.waitForSelector('td#BankLedgerEntryOutstandingColumn', { state: 'visible' });
    await page.waitForTimeout(1000);
    const netOutstandingAmount = await page.locator(locators.BankLedger.netoutstandingamount).textContent();
    console.log('Net Outstanding Amount:', netOutstandingAmount); // Replace with the correct selector
    await page.waitForTimeout(1000);
    const billAmount = await page.locator('td#BankLedgerEntryBillAmtColumn').textContent();
    console.log('bill  Amount:', netOutstandingAmount); // Replace with the correct selector
    await page.waitForTimeout(1000);
    const outstandingAmount = await page.locator('td#BankLedgerEntryOutstandingColumn').textContent();
    console.log('Outstanding Amount:', netOutstandingAmount); // Replace with the correct selector
    
    const netOutstandingAmt = await page.locator(locators.BankLedger.netoutstandingamount).textContent();
  // Trim and convert the value to a number
    const amount = parseFloat(netOutstandingAmt.trim());
    console.log("amount",amount);
  
    if (!isNaN(amount) && amount > 0) {
  
        console.log(`Filling Received Amount with: ${amount}`);
  
        // Fill the "Received Amount" input field
        const receive = await page.locator(locators.BankLedger.Receivedamt).nth(0);
        receive.click();
        await page.fill(locators.BankLedger.enterReceiveamt, amount.toString());
    } else {
        console.log("Invalid Net Outstanding Amount. Skipping input.");
    }
  
    // Verify Balance and Exchange Amount are both displayed as 0
    await page.locator('td#BankLedgerEntryRemainingBalColumn').click();  
  
    // Click on Update
    const updateButton = await page.locator(locators.BankLedger.updategridbtn);
    await updateButton.click();
  
    // Verify the warning popup
    await page.locator('text=Are you sure you want to save changes?');
    await page.click('//button[normalize-space()="OK"]');
  
      await page.click(locators.BankLedger.Submitbtn);
      console.log("Bank Ledger Add Successfull with full payment of Vendor");
  
    //   const rows = await page.locator('tr[aria-rowindex]'); // Select all rows with aria-rowindex
    //   const firstRow = await rows.nth(0);
    //   await firstRow.locator(locators.Grid.Accountname);
    //   await expect(firstRow).toContainText(vendorName);
    //   await page.waitForTimeout(2000);
    //   console.log("Verify newly aaded ledger is display in Grid");
  
  }

  async function outstandingReport2(page) {
    await page.click(locators.outstandingreport.outstanding);
  
    await page.click(locators.outstandingreport.filterbutton);
  
    await page.locator(locators.vendor_outstanding).click();
    await page.waitForTimeout(2000);
    await page.fill(locators.BankLedger.entercustomername, vendorName);
    await page.locator('li.e-list-item', { hasText: vendorName }).click();
    await page.waitForTimeout(2000);
    await page.click(locators.outstandingreport.SearchButton);
    await page.waitForTimeout(2000);
  
    const zeroPendingRows = await page.$$eval('table tbody tr', rows => {
      return rows.filter(row => {
        const balanceElement = row.querySelector('#OutstandingReportRemainBalanceAmountColumn');
        const balance = balanceElement ? parseFloat(balanceElement.innerText.replace(/[^0-9.-]+/g, "")) : 0;
        return balance === 0;
      });
    });
  
    if (zeroPendingRows.length < 0) {
      console.error('Found sales/AMCs with 0 pending payment displayed in the report.');
    } else {
      console.log('No sales/AMCs with 0 pending payment displayed in the report.');
    }
  
  
    console.log('Verification completed successfully.');
  
  }
  
  async function customeraccledger2(page) {
    await page.click(locators.vendoraccountLedger.accountLedger);
    await page.click(locators.vendoraccountLedger.vendorLedger);
    await page.click(locators.vendoraccountLedger.filterbutton);
  
    await page.locator(locators.BankLedger.vendorname).click();
    await page.waitForTimeout(2000);
    await page.fill(locators.BankLedger.entercustomername, vendorName);
    await page.locator('li.e-list-item', { hasText: vendorName }).click();
    await page.waitForTimeout(2000);
  
    await page.click(locators.vendoraccountLedger.Searchbutton);
    await page.waitForTimeout(2000);
  
    console.log('Customer Account Ledger Report verification completed successfully.');
  
  }
  
  async function VerifyConsistency2(page) {
  
    await page.click(locators.outstandingreport.outstanding);
    await page.click(locators.outstandingreport.filterbutton);
  
    await page.locator(locators.vendor_outstanding).click();
    await page.waitForTimeout(2000);
    await page.fill(locators.BankLedger.entercustomername, vendorName);
    await page.locator('li.e-list-item', { hasText: vendorName }).click();
    await page.waitForTimeout(2000);
    await page.click(locators.outstandingreport.SearchButton);
  
    await page.waitForSelector(`tr:has(td:has-text("${vendorName}"))`);// wait up to 60 seconds
  
    await page.locator(`tr:has(td:has-text("${vendorName}"))`);
    const outstandingBalance = await page.locator('td.e-summarycell[data-cell="Balance"]').textContent();
    console.log(`Outstanding Report Overall Balance: ${outstandingBalance}`);
  
    console.log('Outstanding Report verification completed successfully.');
    await page.click(locators.vendoraccountLedger.reports);
    await page.click(locators.vendoraccountLedger.accountLedger);
    await page.click(locators.vendoraccountLedger.vendorLedger);
    await page.click(locators.vendoraccountLedger.filterbutton);
  
    await page.locator(locators.BankLedger.vendorname).click();
    await page.waitForTimeout(2000);
    await page.fill(locators.BankLedger.entercustomername, vendorName);
    await page.locator('li.e-list-item', { hasText: vendorName }).click();
    await page.waitForTimeout(2000);
  
    await page.click(locators.vendoraccountLedger.Searchbutton);
    await page.waitForSelector(`tr:has(td:has-text("${vendorName}"))`);// wait up to 60 seconds
  
    await page.locator(`tr:has(td:has-text("${vendorName}"))`);
    const recentBalance = await page.locator('td.e-summarycell[data-cell="Balance"]').textContent();
    console.log(`customer Ledger Report Overall Balance: ${recentBalance}`);
    expect(parseFloat(outstandingBalance)).toBe(parseFloat(recentBalance));
    console.log('Consistency between Outstanding Report and Account Ledger verified successfully.');
  }
  
  async function Bankledgerreport2(page) {
    await page.click(locators.customeraccLedger.reports);
    await page.click(locators.LedgerReport.ledgerpage);
    await page.click(locators.LedgerReport.bankledgerpage);
    await page.click(locators.LedgerReport.filterbutton);
  
    await page.locator(locators.LedgerReport.paymentnature).click();
    await page.click("//li[normalize-space()='Payable']");
    await page.locator(locators.vendor_ledger).click();
    await page.fill(locators.BankLedger.entercustomername, vendorName);
    await page.locator('li.e-list-item', { hasText: vendorName }).click();
    await page.click(locators.LedgerReport.submitbutton);
  
  }
  
  
  module.exports = {
    addledgerforpurchase,outstandingReport2, customeraccledger2, VerifyConsistency2, Bankledgerreport2
  };
