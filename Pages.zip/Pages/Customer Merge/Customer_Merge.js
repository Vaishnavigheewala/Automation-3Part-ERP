const { test, expect } = require('@playwright/test');
const locators = require('./Customer_Merge.json');


async function checkinput(page) {
    const cust_name = await page.locator(locators.cust_name).isEditable();
    console.log("Customer Name input is Editable : " , cust_name);
    
    const cust_mobile = await page.locator(locators.cust_mobile).nth(0).isEditable();
    console.log("Customer Mobile Number input is Editable : " , cust_mobile);

    
    const cust_address = await page.locator(locators.cust_address).nth(0).isEditable();
    console.log("Customer Address input is Editable : " , cust_address);

}

module.exports = {checkinput};