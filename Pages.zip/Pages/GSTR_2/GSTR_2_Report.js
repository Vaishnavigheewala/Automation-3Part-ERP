const { test, expect } = require('@playwright/test');
const { format } = require('date-fns');
const locators = require('./GSTR_2_Report.json');
const { selectmenu } = require('../../Pages/02Dashboard/dashboard.js');
const { Generate_Variable, Delete_Variable, Delete_All_Variables, List_Variables, Get_Current_Date_Time, Generate_Unique_String, Generate_Unique_Address, Generate_Random_Mobile_No } = require('../../Dynamic_Variables_Manage/Dynamic_Variable_Manage'); // Adjust the path as needed
const { Console } = require('console');
const PdfParse = require('pdf-parse');

// td[data-label="Invoice Amount"]

async function Apply_Date_Filter_To_Current_Month(page) {
    let today = new Date();
    // Get first and last day of the month
    let firstDay = new Date(today.getFullYear(), today.getMonth(), 1);
    let lastDay = new Date(today.getFullYear(), today.getMonth() + 1, 0);

    // Format dates as DD-MM-YYYY
    let formattedStartDate = format(firstDay, 'dd-MM-yyyy');
    let formattedEndDate = format(lastDay, 'dd-MM-yyyy');

    // Enter the date range in the input field
    let dateRange = `${formattedStartDate} - ${formattedEndDate}`;
    await page.fill(locators.Date, dateRange);
    console.log("Date fills with value", dateRange);
    await page.waitForTimeout(500);
    await page.locator(locators.Search).click();
    console.log("Search after date filter apply.");
}

async function GSTR_2_Menu_Selection(page) {
    console.log("___________________________________")
    await page.locator(locators.GSTR_2).click();
    console.log("GSTR 2 menu click");
    await page.waitForTimeout(500);
}

async function B2B_Invoices_3_4A(page) {
    console.log("=== B2B Invoices ===");
    await page.locator(locators.B2B_Invoices_3_4A.Link).click();
    console.log("link B2B Invoices click");
    await page.waitForTimeout(1000);
}

async function B2BUR_4B(page) {
    console.log("=== B2BUR 4B Invoices ===");
    await page.locator(locators.B2BUR_4B.Link).click();
    console.log("link B2BUR 4B Invoices click");
    await page.waitForTimeout(1000);
}

async function Credit_Debit_Notes_Registered_6C(page) {
    console.log("===Credit_Debit_Notes_Registered_6C ===");
    await page.locator(locators.Credit_Debit_Notes_Registered_6C.Link).click();
    console.log("link Credit_Debit_Notes_Registered_6C click");
    await page.waitForTimeout(1000);
}

async function Credit_Debit_Notes_Unregistered_6C(page) {
    console.log("=== Credit_Debit_Notes_Unregistered_6C Invoices ===");
    await page.locator(locators.Credit_Debit_Notes_Unregistered_6C.Link).click();
    console.log("link Credit_Debit_Notes_Unregistered_6C click");
    await page.waitForTimeout(1000);
}

async function Close_Popup(page) {
    await page.waitForTimeout(500);
    for (let i = 0; i <= 4; i++) {
        if (await page.locator(locators.PopUp_Close).nth(i).isVisible()) {
            await page.locator(locators.PopUp_Close).nth(i).click();
            console.log("Popup close btn clicked.");
            await page.waitForTimeout(1000);
            break;
        }
    }
}

async function Find_ValueIn_Column(page, Page_Grid_ID, ColumnSelector, searchValue, buttonXPath = null) {
    console.log("🔍 Searching for:", searchValue);
    let tableSelector = Page_Grid_ID;
    let previousFirstRowText = "";
    let isFirstPage = true;
    while (true) {
        try {
            await page.waitForSelector(`${tableSelector} tr`, { timeout: 5000 });
        } catch {
            console.log("⚠️ Table took too long to load.");
            return false;
        }
        let columnHandles = await page.locator(ColumnSelector).elementHandles();
        if (columnHandles.length === 0) {
            console.log("❌ Column not found!");
            return false;
        }
        let columnIndex = await page.evaluate(el => [...el.parentElement.children].indexOf(el), columnHandles[0]) + 1;
        console.log(`✅ Column index found: ${columnIndex}`);
        while (true) {
            let rows = await page.locator(`${tableSelector} tr`).all();
            if (rows.length === 0) {
                console.log("⚠️ No rows found on this page.");
                return false;
            }
            let currentFirstRowText = await rows[0].innerText();
            for (let row of rows) {
                let columnValueLocator = row.locator(`td:nth-child(${columnIndex})`);
                if (await columnValueLocator.count() > 0) {
                    let columnValue = await columnValueLocator.innerText();
                    let rowText = await row.innerText();
                    if (columnValue.includes(searchValue)) {
                        console.log(`✅ Found "${searchValue}" in row:`);
                        console.log(rowText);
                        // ✅ Click button if buttonXPath is provided
                        if (buttonXPath) {
                            let buttonLocator = row.locator(`xpath=${buttonXPath}`);
                            if (await buttonLocator.count() > 0) {
                                console.log("🖱️ Clicking the button in the found row...");
                                await buttonLocator.first().click();
                            } else {
                                console.log("❌ Button not found with XPath:", buttonXPath);
                            }
                        } else {
                            console.log("ℹ️ No button XPath provided. Skipping button click.");
                        }
                        return true;
                    }
                }
            }
            // ✅ Check pagination (same logic as before)
            let nextPageElement = await page.locator(".e-next").first();
            if (!(await nextPageElement.isVisible())) {
                console.log("⚠️ No next page button is visible.");
                return false;
            }
            let isNextDisabled = await nextPageElement.getAttribute('class');
            if (isNextDisabled.includes('e-disabled')) {
                console.log(`❌ Value "${searchValue}" not found in any page.`);
                return false;
            }
            if (currentFirstRowText === previousFirstRowText && !isFirstPage) {
                console.log("🚨 No new data loaded. Stopping pagination.");
                return false;
            }
            previousFirstRowText = currentFirstRowText;
            isFirstPage = false;
            console.log("➡️ Moving to next page...");
            await nextPageElement.click();
            await page.waitForTimeout(3000);
        }
    }
}

async function UnRegistered_User_Data_Verification_In_GSTR_2_S_Credit_Debit_Notes_UnRegistered_6C(page, Bill_No, Net_Amount, Total_Tax_Value) {
    console.log("=== Unregistered data matching ===");
    console.log("Bill No ", Bill_No);
    let Bill_No_From_Grid, j, GST_No, IGST, CGST, SGST, Net_Amount_Grid, GST_Rate, Bill_Type;
    let billFound = false;
    do {
        for (let i = 1; i <= 12; i++) {
            await page.locator(locators.Credit_Debit_Notes_Unregistered_6C.Invoice_ID).nth(i).click();
            Bill_No_From_Grid = await page.locator(locators.Credit_Debit_Notes_Unregistered_6C.Invoice_ID).nth(i).textContent();
            console.log("Checking row =", i, "And Invoice No =", Bill_No_From_Grid);
            if (Bill_No_From_Grid == Bill_No) {
                console.log("Bill No Found with ", Bill_No_From_Grid);
                j = i;
                billFound = true;
                break;
            }
        }
        if (billFound) {
            await page.locator(locators.Credit_Debit_Notes_Unregistered_6C.GST_No).nth(j).click();
            Bill_Type = await page.locator(locators.Credit_Debit_Notes_Unregistered_6C.Bill_Type).nth(j).textContent();
            GST_No = await page.locator(locators.Credit_Debit_Notes_Unregistered_6C.GST_No).nth(j).textContent();
            Bill_Type = await page.locator(locators.Credit_Debit_Notes_Unregistered_6C.Bill_Type).nth(j).textContent();
            console.log("Bill Type = ", Bill_Type);
            await page.locator(locators.Credit_Debit_Notes_Unregistered_6C.IGST).nth(j).click();
            IGST = await page.locator(locators.Credit_Debit_Notes_Unregistered_6C.IGST).nth(j).textContent();

            SGST = await page.locator(locators.Credit_Debit_Notes_Unregistered_6C.SGST).nth(j).textContent();
            CGST = await page.locator(locators.Credit_Debit_Notes_Unregistered_6C.CGST).nth(j).textContent();
            Net_Amount_Grid = await page.locator(locators.Credit_Debit_Notes_Unregistered_6C.Invoice_Amount).nth(j).textContent();
            GST_Rate = await page.locator(locators.Credit_Debit_Notes_Unregistered_6C.GST_Rate).nth(j).textContent();
            console.log(" GST No, IGST, CGST, SGST, GST Rate, Net Amount =", GST_No, IGST, CGST, SGST, GST_Rate, Net_Amount_Grid);
            console.log("_________________________________________________________");
            await Calculate_GST_Amount(GST_Rate, Net_Amount);
            console.log("Bill Type = ", Bill_Type);
            if (GST_No == "-") {
                console.log("GST No isn't available. User is unregistered.");
            }
            if (IGST != 0.0) {
                console.log("User is from out of Gujarat. IGST =", IGST);
                console.log("Net Aount Grid =", Net_Amount_Grid);
                console.log("Net Aount =", Net_Amount_Grid);
                Is_Nearly_Equal_Ignoring_Sign(Net_Amount, Net_Amount_Grid, 1)
            }
            else {
                if (CGST == SGST) {
                    expect(IGST).toBe('0.0');
                    expect(CGST).toBe(SGST);
                    console.log("User is from Gujarat.  CGST & SGST=", CGST, SGST);
                    console.log("Net Aount Grid =", Net_Amount_Grid);
                    console.log("Net Aount =", Net_Amount_Grid);
                    Is_Nearly_Equal_Ignoring_Sign(Net_Amount, Net_Amount_Grid, 1)
                }
            }
        } else {
            let nextButton = page.locator(locators.Next_Button);
            let isNextEnabled = await nextButton.isEnabled();
            if (isNextEnabled) {
                console.log("Moving to next page...");
                await nextButton.click();
                await page.waitForTimeout(1000); // Wait for new page data to load
            } else {
                console.log("No more pages left, Bill No not found.");
                break;
            }
        }
    } while (!billFound);
}

async function Registered_User_Data_Verification_In_GSTR_2_S_Credit_Debit_Notes_Registered_6C(page, Bill_No, Net_Amount, Total_Tax_Value) {
    console.log("=== Registered user data matching ===");
    console.log("Bill No ", Bill_No);
    let Bill_No_From_Grid, j, GST_No, IGST, CGST, SGST, Net_Amount_Grid, GST_Rate, Bill_Type;
    let billFound = false;
    do {
        for (let i = 1; i <= 12; i++) {
            await page.locator(locators.Credit_Debit_Notes_Registered_6C.Invoice_ID).nth(i).click();
            Bill_No_From_Grid = await page.locator(locators.Credit_Debit_Notes_Registered_6C.Invoice_ID).nth(i).textContent();
            console.log("Checking row =", i, "And Invoice No =", Bill_No_From_Grid);
            if (Bill_No_From_Grid == Bill_No) {
                console.log("Bill No Found with ", Bill_No_From_Grid);
                j = i;
                billFound = true;
                break;
            }
        }
        if (billFound) {
            await page.locator(locators.Credit_Debit_Notes_Registered_6C.GST_No).nth(j).click();
            GST_No = await page.locator(locators.Credit_Debit_Notes_Registered_6C.GST_No).nth(j).textContent();
            await page.waitForTimeout(1000);
            Bill_Type = await page.locator(locators.Credit_Debit_Notes_Registered_6C.Bill_Type).nth(j).textContent();
            await page.locator(locators.Credit_Debit_Notes_Registered_6C.IGST).nth(j).click();
            IGST = await page.locator(locators.Credit_Debit_Notes_Registered_6C.IGST).nth(j).textContent();

            SGST = await page.locator(locators.Credit_Debit_Notes_Registered_6C.SGST).nth(j).textContent();
            CGST = await page.locator(locators.Credit_Debit_Notes_Registered_6C.CGST).nth(j).textContent();
            Net_Amount_Grid = await page.locator(locators.Credit_Debit_Notes_Registered_6C.Invoice_Amount).nth(j).textContent();
            GST_Rate = await page.locator(locators.Credit_Debit_Notes_Registered_6C.GST_Rate).nth(j).textContent();
            console.log(" GST No, IGST, CGST, SGST, GST Rate, Net Amount =", GST_No, IGST, CGST, SGST, GST_Rate, Net_Amount_Grid);
            console.log("_________________________________________________________");
            await Calculate_GST_Amount(GST_Rate, Net_Amount);
            console.log("Bill Type = ", Bill_Type);
            if (GST_No == "-") {
                console.log("GST No isn't available. User is unregistered.");
            }
            if (IGST != 0.0) {
                console.log("User is from out of Gujarat. IGST =", IGST);
            }
            else {
                if (CGST == SGST) {
                    expect(IGST).toBe('0.0');
                    expect(CGST).toBe(SGST);
                    console.log("User is from Gujarat.  CGST & SGST=", CGST, SGST);
                    console.log("Net Aount Grid =", Net_Amount_Grid);
                    console.log("Net Aount =", Net_Amount_Grid);
                    Is_Nearly_Equal_Ignoring_Sign(Net_Amount, Net_Amount_Grid, 1)
                }
            }
        } else {
            let nextButton = page.locator(locators.Next_Button);
            let isNextEnabled = await nextButton.isEnabled();
            if (isNextEnabled) {
                console.log("Moving to next page...");
                await nextButton.click();
                await page.waitForTimeout(1000); // Wait for new page data to load
            } else {
                console.log("No more pages left, Bill No not found.");
                break;
            }
        }
    } while (!billFound);

}

async function User_Data_Verification_In_GSTR_2_S_B2B_Invoice_4A(page, Bill_No, Net_Amount, Total_Tax_Value) {
    console.log("=== Registered user data matching in B2B Invoice 4A ===");
    console.log("Bill No ", Bill_No);
    let Bill_No_From_Grid, j, GST_No, IGST, CGST, SGST, Net_Amount_Grid, GST_Rate, Bill_Type;
    let billFound = false;
    do {
        for (let i = 1; i <= 12; i++) {
            await page.locator(locators.B2B_Invoices_3_4A.Invoice_ID).nth(i).click();
            Bill_No_From_Grid = await page.locator(locators.B2B_Invoices_3_4A.Invoice_ID).nth(i).textContent();
            console.log("Checking row =", i, "And Invoice No =", Bill_No_From_Grid);
            if (Bill_No_From_Grid == Bill_No) {
                console.log("Bill No Found with ", Bill_No_From_Grid);
                j = i;
                billFound = true;
                break;
            }
        }
        if (billFound) {
            await page.locator(locators.B2B_Invoices_3_4A.GST_No).nth(j).click();
            GST_No = await page.locator(locators.B2B_Invoices_3_4A.GST_No).nth(j).textContent();
            Bill_Type = await page.locator(locators.B2B_Invoices_3_4A.Bill_Type).nth(j).textContent();
            await page.locator(locators.B2B_Invoices_3_4A.IGST).nth(j).click();
            IGST = await page.locator(locators.B2B_Invoices_3_4A.IGST).nth(j).textContent();

            SGST = await page.locator(locators.B2B_Invoices_3_4A.SGST).nth(j).textContent();
            CGST = await page.locator(locators.B2B_Invoices_3_4A.CGST).nth(j).textContent();
            Net_Amount_Grid = await page.locator(locators.B2B_Invoices_3_4A.Invoice_Amount).nth(j).textContent();
            GST_Rate = await page.locator(locators.B2B_Invoices_3_4A.GST_Rate).nth(j).textContent();
            console.log(" GST No, IGST, CGST, SGST, GST Rate, Net Amount =", GST_No, IGST, CGST, SGST, GST_Rate, Net_Amount_Grid);
            console.log("_________________________________________________________");
            let GST_Amt = await Calculate_GST_Amount(GST_Rate, Net_Amount);
            console.log("GST Amount =", GST_Amt[0]);
            console.log("Bill Type = ", Bill_Type);
            if (GST_No == "-") {
                console.log("GST No isn't available. User is unregistered.");
            }
            if (IGST != 0.0) {
                console.log("User is from out of Gujarat. IGST =", IGST);
            }
            else {
                if (CGST == SGST) {
                    expect(IGST).toBe('0.0');
                    expect(CGST).toBe(SGST);
                    console.log("User is from Gujarat.  CGST & SGST=", CGST, SGST);
                    console.log("Net Aount Grid =", Net_Amount_Grid);
                    console.log("Net Aount =", Net_Amount_Grid);
                    Is_Nearly_Equal_Ignoring_Sign(Net_Amount, Net_Amount_Grid, 1)
                }
            }
        } else {
            let nextButton = page.locator(locators.Next_Button);
            let isNextEnabled = await nextButton.isEnabled();
            if (isNextEnabled) {
                console.log("Moving to next page...");
                await nextButton.click();
                await page.waitForTimeout(1000); // Wait for new page data to load
            } else {
                console.log("No more pages left, Bill No not found.");
                break;
            }
        }
    } while (!billFound);

}

async function B2B_Invoices_3_4A_Column_Total(page) {
    let IGST_Sum = 0, CGST_Sum = 0, SGST_Sum = 0, Taxable_Value_Sum = 0, Total_Tax_Amt_Sum = 0, Invoice_Amt_Sum = 0;

    while (true) {
        let rows = await page.locator(locators.B2B_Invoices_3_4A.IGST).count();
        console.log(`Rows found on this page: ${rows}`);

        if (rows > 0) {
            for (let i = 0; i < rows; i++) {
                try {
                    let IGST = 0, SGST = 0, CGST = 0, Taxable_Value = 0, Total_Tax_Amt = 0, Invoice_Amt = 0;

                    if (await page.locator(locators.B2B_Invoices_3_4A.IGST).nth(i).isVisible()) {
                        IGST = parseFloat(await page.locator(locators.B2B_Invoices_3_4A.IGST).nth(i).textContent()) || 0;
                    }
                    IGST_Sum += IGST;

                    if (await page.locator(locators.B2B_Invoices_3_4A.SGST).nth(i).isVisible()) {
                        SGST = parseFloat(await page.locator(locators.B2B_Invoices_3_4A.SGST).nth(i).textContent()) || 0;
                    }
                    SGST_Sum += SGST;

                    if (await page.locator(locators.B2B_Invoices_3_4A.CGST).nth(i).isVisible()) {
                        CGST = parseFloat(await page.locator(locators.B2B_Invoices_3_4A.CGST).nth(i).textContent()) || 0;
                    }
                    CGST_Sum += CGST;

                    if (await page.locator(locators.B2B_Invoices_3_4A.Taxable_Value).nth(i).isVisible()) {
                        Taxable_Value = parseFloat(await page.locator(locators.B2B_Invoices_3_4A.Taxable_Value).nth(i).textContent()) || 0;
                    }
                    Taxable_Value_Sum += Taxable_Value;

                    if (await page.locator(locators.B2B_Invoices_3_4A.Total_Tax_Amount).nth(i).isVisible()) {
                        Total_Tax_Amt = parseFloat(await page.locator(locators.B2B_Invoices_3_4A.Total_Tax_Amount).nth(i).textContent()) || 0;
                    }
                    Total_Tax_Amt_Sum += Total_Tax_Amt;

                    if (await page.locator(locators.B2B_Invoices_3_4A.Invoice_Amount).nth(i).isVisible()) {
                        Invoice_Amt = parseFloat(await page.locator(locators.B2B_Invoices_3_4A.Invoice_Amount).nth(i).textContent()) || 0;
                    }
                    Invoice_Amt_Sum += Invoice_Amt;

                    console.log(`Row ${i + 1} -> IGST: ${IGST}, SGST: ${SGST}, CGST: ${CGST}, Taxable: ${Taxable_Value}, Total Tax: ${Total_Tax_Amt}, Invoice: ${Invoice_Amt}`);
                } catch (error) {
                    console.log(`Error processing row ${i + 1}: ${error.message}`);
                }
            }
        } else {
            console.log("No rows found on this page.");
        }

        let nextButton = page.locator(locators.Next_Button);

        // 🔹 Check if the Next button exists
        if (await nextButton.count() === 0) {
            console.log("Next button does not exist. Stopping pagination.");
            break;
        }

        // 🔹 Get the class attribute of the next button
        let nextButtonClass = await nextButton.getAttribute("class");

        // 🔹 Check if the class contains "e-disable"
        if (nextButtonClass.includes("e-disable")) {
            console.log("Next button is disabled. Stopping pagination.");
            break;
        } else {
            console.log("Moving to the next page...");
            await nextButton.click();
            await page.waitForTimeout(1500); // Wait for new page data to load
        }
    }

    console.log("Final Sums:");
    console.log(`IGST Sum: ${IGST_Sum}`);
    console.log(`SGST Sum: ${SGST_Sum}`);
    console.log(`CGST Sum: ${CGST_Sum}`);
    console.log(`Taxable Value Sum: ${Taxable_Value_Sum}`);
    console.log(`Total Tax Amount Sum: ${Total_Tax_Amt_Sum}`);
    console.log(`Invoice Amount Sum: ${Invoice_Amt_Sum}`);

    let Grand_total_Taxable_Value = (await page.locator('td.e-summarycell.e-templatecell[data-cell="Taxable Value"]').textContent()).replace(/[^0-9.]/g, '');
    console.log("Grand total Total Taxable Amount = ", Grand_total_Taxable_Value);
    expect(parseInt(Taxable_Value_Sum)).toBe(parseInt(Grand_total_Taxable_Value));

    let Grand_total_IGST = (await page.locator('td.e-summarycell.e-templatecell[data-cell="Integrated Tax Amount"]').textContent()).replace(/[^0-9.]/g, '');
    console.log("Grand total IGST = ", Grand_total_IGST);
    expect(parseInt(IGST_Sum)).toBe(parseInt(Grand_total_IGST));

    let Grand_total_CGST = (await page.locator('td.e-summarycell.e-templatecell[data-cell="Central Tax Amount"]').textContent()).replace(/[^0-9.]/g, '');
    console.log("Grand total CGST = ", Grand_total_CGST);
    expect(parseInt(CGST_Sum)).toBe(parseInt(Grand_total_CGST));

    let Grand_total_SGST = (await page.locator('td.e-summarycell.e-templatecell[data-cell="State Tax Amount"]').textContent()).replace(/[^0-9.]/g, '');
    console.log("Grand total SGIT = ", Grand_total_SGST);
    expect(parseInt(SGST_Sum)).toBe(parseInt(Grand_total_SGST));

    let Grand_total_Tax_Value = (await page.locator('td.e-summarycell.e-templatecell[data-cell="Total Tax Amount"]').textContent()).replace(/[^0-9.]/g, '');
    console.log("Grand total Tax Value = ", Grand_total_Tax_Value);
    expect(parseInt(Total_Tax_Amt_Sum)).toBe(parseInt(Grand_total_Tax_Value));

    let Grand_total_Invoice_Value = (await page.locator('td.e-summarycell.e-templatecell[data-cell="Invoice Amount"]').textContent()).replace(/[^0-9.]/g, '');
    console.log("Grand total Invoice Amt = ", Grand_total_Invoice_Value);
    expect(parseInt(Invoice_Amt_Sum)).toBe(parseInt(Grand_total_Invoice_Value));
}

async function B2BUR_4B_Column_Total(page) {
    let sums = { IGST: 0, CGST: 0, SGST: 0, Taxable_Value: 0, Total_Tax_Amt: 0, Invoice_Amt: 0 };

    while (true) {
        let rows = await page.locator(locators.B2BUR_4B.IGST).count();
        console.log(`Rows found on this page: ${rows}`);

        if (rows > 0) {
            for (let i = 0; i < rows; i++) {
                try {
                    let values = await Promise.all([
                        page.locator(locators.B2BUR_4B.IGST).nth(i).isVisible() ? page.locator(locators.B2BUR_4B.IGST).nth(i).textContent() : "0",
                        page.locator(locators.B2BUR_4B.SGST).nth(i).isVisible() ? page.locator(locators.B2BUR_4B.SGST).nth(i).textContent() : "0",
                        page.locator(locators.B2BUR_4B.CGST).nth(i).isVisible() ? page.locator(locators.B2BUR_4B.CGST).nth(i).textContent() : "0",
                        page.locator(locators.B2BUR_4B.Taxable_Value).nth(i).isVisible() ? page.locator(locators.B2BUR_4B.Taxable_Value).nth(i).textContent() : "0",
                        page.locator(locators.B2BUR_4B.Total_Tax_Amount).nth(i).isVisible() ? page.locator(locators.B2BUR_4B.Total_Tax_Amount).nth(i).textContent() : "0",
                        page.locator(locators.B2BUR_4B.Invoice_Amount).nth(i).isVisible() ? page.locator(locators.B2BUR_4B.Invoice_Amount).nth(i).textContent() : "0"
                    ]);

                    let [IGST, SGST, CGST, Taxable_Value, Total_Tax_Amt, Invoice_Amt] = values.map(val => parseFloat(val.replace(/[^0-9.-]/g, '')) || 0);

                    sums.IGST += IGST;
                    sums.SGST += SGST;
                    sums.CGST += CGST;
                    sums.Taxable_Value += Taxable_Value;
                    sums.Total_Tax_Amt += Total_Tax_Amt;
                    sums.Invoice_Amt += Invoice_Amt;

                    console.log(`Row ${i + 1} -> IGST: ${IGST}, SGST: ${SGST}, CGST: ${CGST}, Taxable: ${Taxable_Value}, Total Tax: ${Total_Tax_Amt}, Invoice: ${Invoice_Amt}`);
                } catch (error) {
                    console.log(`Error processing row ${i + 1}: ${error.message}`);
                }
            }
        } else {
            console.log("No rows found on this page.");
        }

        let nextButton = page.locator(locators.Next_Button);
        if (await nextButton.count() === 0 || (await nextButton.getAttribute("class")).includes("e-disable")) {
            console.log("Pagination stopped.");
            break;
        }
        console.log("Moving to the next page...");
        await nextButton.click();
        await page.waitForTimeout(1500);
    }

    console.log("Final Sums:", sums);

    let grandTotals = await Promise.all([
        page.locator('td.e-summarycell.e-templatecell[data-cell="Taxable Value"]').nth(1).textContent(),
        page.locator('td.e-summarycell.e-templatecell[data-cell="Integrated Tax Amount"]').nth(1).textContent(),
        page.locator('td.e-summarycell.e-templatecell[data-cell="Central Tax Amount"]').nth(1).textContent(),
        page.locator('td.e-summarycell.e-templatecell[data-cell="State Tax Amount"]').nth(1).textContent(),
        page.locator('td.e-summarycell.e-templatecell[data-cell="Total Tax Amount"]').nth(1).textContent(),
        page.locator('td.e-summarycell.e-templatecell[data-cell="Invoice Amount"]').nth(1).textContent()
    ]);

    let GrandTotals = grandTotals.map(val => parseFloat(val.replace(/[^0-9.-]/g, '')) || 0);

    console.log("Grand Totals:", {
        Taxable_Value: GrandTotals[0],
        IGST: GrandTotals[1],
        CGST: GrandTotals[2],
        SGST: GrandTotals[3],
        Total_Tax_Amt: GrandTotals[4],
        Invoice_Amt: GrandTotals[5]
    });

    expect(parseFloat(sums.Taxable_Value.toFixed(2))).toBe(parseFloat(GrandTotals[0].toFixed(2)));
    expect(parseFloat(sums.IGST.toFixed(2))).toBe(parseFloat(GrandTotals[1].toFixed(2)));
    expect(parseFloat(sums.CGST.toFixed(2))).toBe(parseFloat(GrandTotals[2].toFixed(2)));
    expect(parseFloat(sums.SGST.toFixed(2))).toBe(parseFloat(GrandTotals[3].toFixed(2)));
    expect(parseFloat(sums.Total_Tax_Amt.toFixed(2))).toBe(parseFloat(GrandTotals[4].toFixed(2)));
    expect(parseFloat(sums.Invoice_Amt.toFixed(2))).toBe(parseFloat(GrandTotals[5].toFixed(2)));
}

async function Credit_Debit_Notes_UnRegistered_6C_Column_Total(page) {
    let IGST_Sum = 0, CGST_Sum = 0, SGST_Sum = 0, Taxable_Value_Sum = 0, Total_Tax_Amt_Sum = 0, Invoice_Amt_Sum = 0;
    let currentPage = 1;

    while (true) {
        let rows = await page.locator(locators.Credit_Debit_Notes_Unregistered_6C.IGST).count();
        console.log(`Page ${currentPage}: Rows found -> ${rows}`);

        if (rows > 0) {
            for (let i = 0; i < rows; i++) {
                try {
                    let IGST = 0, SGST = 0, CGST = 0, Taxable_Value = 0, Total_Tax_Amt = 0, Invoice_Amt = 0;

                    if (await page.locator(locators.Credit_Debit_Notes_Unregistered_6C.IGST).nth(i).isVisible()) {
                        IGST = parseFloat(await page.locator(locators.Credit_Debit_Notes_Unregistered_6C.IGST).nth(i).textContent()) || 0;
                    }
                    IGST_Sum += IGST;

                    if (await page.locator(locators.Credit_Debit_Notes_Unregistered_6C.SGST).nth(i).isVisible()) {
                        SGST = parseFloat(await page.locator(locators.Credit_Debit_Notes_Unregistered_6C.SGST).nth(i).textContent()) || 0;
                    }
                    SGST_Sum += SGST;

                    if (await page.locator(locators.Credit_Debit_Notes_Unregistered_6C.CGST).nth(i).isVisible()) {
                        CGST = parseFloat(await page.locator(locators.Credit_Debit_Notes_Unregistered_6C.CGST).nth(i).textContent()) || 0;
                    }
                    CGST_Sum += CGST;

                    if (await page.locator(locators.Credit_Debit_Notes_Unregistered_6C.Taxable_Value).nth(i).isVisible()) {
                        Taxable_Value = parseFloat(await page.locator(locators.Credit_Debit_Notes_Unregistered_6C.Taxable_Value).nth(i).textContent()) || 0;
                    }
                    Taxable_Value_Sum += Taxable_Value;

                    if (await page.locator(locators.Credit_Debit_Notes_Unregistered_6C.Total_Tax_Amount).nth(i).isVisible()) {
                        Total_Tax_Amt = parseFloat(await page.locator(locators.Credit_Debit_Notes_Unregistered_6C.Total_Tax_Amount).nth(i).textContent()) || 0;
                    }
                    Total_Tax_Amt_Sum += Total_Tax_Amt;

                    if (await page.locator(locators.Credit_Debit_Notes_Unregistered_6C.Invoice_Amount).nth(i).isVisible()) {
                        Invoice_Amt = parseFloat(await page.locator(locators.Credit_Debit_Notes_Unregistered_6C.Invoice_Amount).nth(i).textContent()) || 0;
                    }
                    Invoice_Amt_Sum += Invoice_Amt;

                } catch (error) {
                    console.log(`Error processing row ${i + 1}: ${error.message}`);
                }
            }
        } else {
            console.log(`Page ${currentPage}: No rows found.`);
        }

        // **Pagination Handling**
        let nextButton = page.locator(locators.Next_Button);

        if (await nextButton.count() === 0) {
            console.log("Next button is missing. Stopping pagination.");
            break;
        }

        let nextButtonClass = await nextButton.getAttribute("class");
        let nextButtonDisabled = await nextButton.getAttribute("aria-disabled") === "true";

        if (nextButtonDisabled || nextButtonClass.includes("e-disable")) {
            console.log("Next button is disabled. Stopping pagination.");
            break;
        }

        // **Get current page number before clicking Next**
        let oldPageNumberElement = page.locator('.e-pager .e-current');
        let oldPageNumber = oldPageNumberElement ? await oldPageNumberElement.textContent() : null;
        console.log(`Before Clicking -> Current Page: ${oldPageNumber}`);

        // **Click Next**
        console.log("Clicking Next...");
        await nextButton.click();

        // **Wait for the page number to change**
        await page.waitForFunction(async () => {
            let newPageNumberElement = await page.locator('.e-pager .e-current').textContent();
            return newPageNumberElement !== oldPageNumber;
        }, { timeout: 5000 });

        // **Verify page change**
        let newPageNumber = await page.locator('.e-pager .e-current').textContent();
        console.log(`After Clicking -> New Page: ${newPageNumber}`);

        if (oldPageNumber === newPageNumber) {
            console.log("Page did not change. Stopping pagination.");
            break;
        }

        // **Wait for new data to load properly**
        await page.waitForSelector(locators.Credit_Debit_Notes_Unregistered_6C.IGST, { timeout: 5000 });
        await page.waitForTimeout(1000); // Small extra wait to ensure table loads completely

        // **Update current page tracker**
        currentPage++;
    }

    console.log("Final Sums:");
    console.log(`IGST Sum: ${IGST_Sum}`);
    console.log(`SGST Sum: ${SGST_Sum}`);
    console.log(`CGST Sum: ${CGST_Sum}`);
    console.log(`Taxable Value Sum: ${Taxable_Value_Sum}`);
    console.log(`Total Tax Amount Sum: ${Total_Tax_Amt_Sum}`);
    console.log(`Invoice Amount Sum: ${Invoice_Amt_Sum}`);

    // // **Validation Checks**
    // let Grand_total_Taxable_Value = (await page.locator('td.e-summarycell.e-templatecell[data-cell="Taxable Value"]').nth(2).textContent()).replace(/[^0-9.-]/g, '');
    // expect(parseInt(Taxable_Value_Sum)).toBe(parseInt(Grand_total_Taxable_Value));
}

async function Credit_Debit_Notes_Registered_6C_Column_Total(page) {
    let IGST_Sum = 0, CGST_Sum = 0, SGST_Sum = 0, Taxable_Value_Sum = 0, Total_Tax_Amt_Sum = 0, Invoice_Amt_Sum = 0;

    while (true) {
        let rows = await page.locator(locators.Credit_Debit_Notes_Registered_6C.IGST).count();
        console.log(`Rows found on this page: ${rows}`);

        if (rows > 0) {
            for (let i = 0; i < rows; i++) {
                try {
                    let IGST = 0, SGST = 0, CGST = 0, Taxable_Value = 0, Total_Tax_Amt = 0, Invoice_Amt = 0;

                    if (await page.locator(locators.Credit_Debit_Notes_Registered_6C.IGST).nth(i).isVisible()) {
                        IGST = parseFloat(await page.locator(locators.Credit_Debit_Notes_Registered_6C.IGST).nth(i).textContent()) || 0;
                    }
                    IGST_Sum += IGST;

                    if (await page.locator(locators.Credit_Debit_Notes_Registered_6C.SGST).nth(i).isVisible()) {
                        SGST = parseFloat(await page.locator(locators.Credit_Debit_Notes_Registered_6C.SGST).nth(i).textContent()) || 0;
                    }
                    SGST_Sum += SGST;

                    if (await page.locator(locators.Credit_Debit_Notes_Registered_6C.CGST).nth(i).isVisible()) {
                        CGST = parseFloat(await page.locator(locators.Credit_Debit_Notes_Registered_6C.CGST).nth(i).textContent()) || 0;
                    }
                    CGST_Sum += CGST;

                    if (await page.locator(locators.Credit_Debit_Notes_Registered_6C.Taxable_Value).nth(i).isVisible()) {
                        Taxable_Value = parseFloat(await page.locator(locators.Credit_Debit_Notes_Registered_6C.Taxable_Value).nth(i).textContent()) || 0;
                    }
                    Taxable_Value_Sum += Taxable_Value;

                    if (await page.locator(locators.Credit_Debit_Notes_Registered_6C.Total_Tax_Amount).nth(i).isVisible()) {
                        Total_Tax_Amt = parseFloat(await page.locator(locators.Credit_Debit_Notes_Registered_6C.Total_Tax_Amount).nth(i).textContent()) || 0;
                    }
                    Total_Tax_Amt_Sum += Total_Tax_Amt;

                    if (await page.locator(locators.Credit_Debit_Notes_Registered_6C.Invoice_Amount).nth(i).isVisible()) {
                        Invoice_Amt = parseFloat(await page.locator(locators.Credit_Debit_Notes_Registered_6C.Invoice_Amount).nth(i).textContent()) || 0;
                    }
                    Invoice_Amt_Sum += Invoice_Amt;

                    console.log(`Row ${i + 1} -> IGST: ${IGST}, SGST: ${SGST}, CGST: ${CGST}, Taxable: ${Taxable_Value}, Total Tax: ${Total_Tax_Amt}, Invoice: ${Invoice_Amt}`);
                } catch (error) {
                    console.log(`Error processing row ${i + 1}: ${error.message}`);
                }
            }
        } else {
            console.log("No rows found on this page.");
        }

        let nextButton = page.locator(locators.Next_Button);

        // 🔹 Check if the Next button exists
        if (await nextButton.count() === 0) {
            console.log("Next button does not exist. Stopping pagination.");
            break;
        }

        // 🔹 Get the class attribute of the next button
        let nextButtonClass = await nextButton.getAttribute("class");

        // 🔹 Check if the class contains "e-disable"
        if (nextButtonClass.includes("e-disable")) {
            console.log("Next button is disabled. Stopping pagination.");
            break;
        } else {
            console.log("Moving to the next page...");
            await nextButton.click();
            await page.waitForTimeout(1500); // Wait for new page data to load
        }
    }

    console.log("Final Sums:");
    console.log(`IGST Sum: ${IGST_Sum}`);
    console.log(`SGST Sum: ${SGST_Sum}`);
    console.log(`CGST Sum: ${CGST_Sum}`);
    console.log(`Taxable Value Sum: ${Taxable_Value_Sum}`);
    console.log(`Total Tax Amount Sum: ${Total_Tax_Amt_Sum}`);
    console.log(`Invoice Amount Sum: ${Invoice_Amt_Sum}`);

    let Grand_total_Taxable_Value = (await page.locator('td.e-summarycell.e-templatecell[data-cell="Taxable Value"]').nth(2).textContent()).replace(/[^0-9.-]/g, '');
    console.log("Grand total Total Taxable Amount = ", Grand_total_Taxable_Value);
    expect(parseInt(Taxable_Value_Sum)).toBe(parseInt(Grand_total_Taxable_Value));

    let Grand_total_IGST = (await page.locator('td.e-summarycell.e-templatecell[data-cell="Integrated Tax Amount"]').nth(2).textContent()).replace(/[^0-9.-]/g, '');
    console.log("Grand total IGST = ", Grand_total_IGST);
    expect(parseInt(IGST_Sum)).toBe(parseInt(Grand_total_IGST));

    let Grand_total_CGST = (await page.locator('td.e-summarycell.e-templatecell[data-cell="Central Tax Amount"]').nth(2).textContent()).replace(/[^0-9.-]/g, '');
    console.log("Grand total CGST = ", Grand_total_CGST);
    expect(parseInt(CGST_Sum)).toBe(parseInt(Grand_total_CGST));

    let Grand_total_SGST = (await page.locator('td.e-summarycell.e-templatecell[data-cell="State Tax Amount"]').nth(2).textContent()).replace(/[^0-9.-]/g, '');
    console.log("Grand total SGIT = ", Grand_total_SGST);
    expect(parseInt(SGST_Sum)).toBe(parseInt(Grand_total_SGST));

    let Grand_total_Tax_Value = (await page.locator('td.e-summarycell.e-templatecell[data-cell="Total Tax Amount"]').nth(2).textContent()).replace(/[^0-9.-]/g, '');
    console.log("Grand total Tax Value = ", Grand_total_Tax_Value);
    expect(parseInt(Total_Tax_Amt_Sum)).toBe(parseInt(Grand_total_Tax_Value));

    let Grand_total_Invoice_Value = (await page.locator('td.e-summarycell.e-templatecell[data-cell="Invoice Amount"]').nth(2).textContent()).replace(/[^0-9.-]/g, '');
    console.log("Grand total Invoice Amt = ", Grand_total_Invoice_Value);
    expect(parseInt(Invoice_Amt_Sum)).toBe(parseInt(Grand_total_Invoice_Value));
}

async function User_Data_Verification_In_GSTR_2_S_B2BUR__4B(page, Bill_No, Net_Amount, Total_Tax_Value) {
    console.log("=== Registered user data matching in B2B Invoice 4B ===");
    console.log("Bill No ", Bill_No);
    let Bill_No_From_Grid, j, GST_No, IGST, CGST, SGST, Net_Amount_Grid, GST_Rate, Bill_Type;
    let billFound = false;
    do {
        for (let i = 1; i <= 12; i++) {
            await page.locator(locators.B2BUR_4B.Invoice_ID).nth(i).click();
            Bill_No_From_Grid = await page.locator(locators.B2BUR_4B.Invoice_ID).nth(i).textContent();
            console.log("Checking row =", i, "And Invoice No =", Bill_No_From_Grid);
            if (Bill_No_From_Grid == Bill_No) {
                console.log("Bill No Found with ", Bill_No_From_Grid);
                j = i;
                billFound = true;
                break;
            }
        }
        if (billFound) {
            await page.locator(locators.B2BUR_4B.GST_No).nth(j).click();
            GST_No = await page.locator(locators.B2BUR_4B.GST_No).nth(j).textContent();
            Bill_Type = await page.locator(locators.B2BUR_4B.Bill_Type).nth(j).textContent();
            await page.locator(locators.B2BUR_4B.IGST).nth(j).click();
            IGST = await page.locator(locators.B2BUR_4B.IGST).nth(j).textContent();

            SGST = await page.locator(locators.B2BUR_4B.SGST).nth(j).textContent();
            CGST = await page.locator(locators.B2BUR_4B.CGST).nth(j).textContent();
            Net_Amount_Grid = await page.locator(locators.B2BUR_4B.Invoice_Amount).nth(j).textContent();
            GST_Rate = await page.locator(locators.B2BUR_4B.GST_Rate).nth(j).textContent();
            console.log(" GST No, IGST, CGST, SGST, GST Rate, Net Amount =", GST_No, IGST, CGST, SGST, GST_Rate, Net_Amount_Grid);
            console.log("_________________________________________________________");
            console.log("Bill Type = ", Bill_Type);
            let GST_Amt = await Calculate_GST_Amount(GST_Rate, Net_Amount);
            console.log("GST Amount =", GST_Amt[0]);
            if (GST_No == "-") {
                console.log("GST No isn't available. User is unregistered.");
            }
            if (IGST != 0.0) {
                console.log("User is from out of Gujarat. IGST =", IGST);
            }
            else {
                if (CGST == SGST) {
                    expect(IGST).toBe('0.0');
                    expect(CGST).toBe(SGST);
                    console.log("User is from Gujarat.  CGST & SGST=", CGST, SGST);
                    console.log("Net Aount Grid =", Net_Amount_Grid);
                    console.log("Net Aount =", Net_Amount_Grid);
                    Is_Nearly_Equal_Ignoring_Sign(Net_Amount, Net_Amount_Grid, 1)
                }
            }
        } else {
            let nextButton = page.locator(locators.Next_Button);
            let isNextEnabled = await nextButton.isEnabled();
            if (isNextEnabled) {
                console.log("Moving to next page...");
                await nextButton.click();
                await page.waitForTimeout(1000); // Wait for new page data to load
            } else {
                console.log("No more pages left, Bill No not found.");
                break;
            }
        }
    } while (!billFound);

}

function Is_Nearly_Equal_Ignoring_Sign(value1, value2, tolerance = 1) {
    const absValue1 = Math.abs(value1);
    const absValue2 = Math.abs(value2);

    if (Math.abs(absValue1 - absValue2) <= tolerance) {
        console.log(`✅ Values are nearly equal: ${value1} ≈ ${value2} (Tolerance: ${tolerance})`);
        return true;
    } else {
        console.log(`❌ Values are NOT nearly equal: ${value1} ≠ ${value2} (Tolerance: ${tolerance})`);
        return false;
    }
}

function Calculate_GST_Amount(GST_Rate, Net_Amount) {
    let GST = 100 + parseFloat(GST_Rate);
    let Taxable_Value = (parseFloat(Net_Amount) * 100) / GST;
    let GST_Amount = Net_Amount - Taxable_Value;
    // Ensure values have 2 decimal places
    GST_Amount = parseFloat(GST_Amount.toFixed(2));
    Taxable_Value = parseFloat(Taxable_Value.toFixed(2));
    console.log("GST+100 =", GST, "Taxable Value =", Taxable_Value, "GST Amount =", GST_Amount);
    return [GST_Amount, Taxable_Value];
}

async function PDF_Export(page) {
    await page.locator(locators.PDF_Export).nth(0).click();
    console.log("PDF Export click");
}

async function Reset(page) {
    await page.locator(locators.Reset).click();
    console.log("Reset click");
}

module.exports = {
    Apply_Date_Filter_To_Current_Month, GSTR_2_Menu_Selection, B2B_Invoices_3_4A, Close_Popup, B2BUR_4B,
    Credit_Debit_Notes_Registered_6C, Credit_Debit_Notes_Unregistered_6C,
    UnRegistered_User_Data_Verification_In_GSTR_2_S_Credit_Debit_Notes_UnRegistered_6C,
    Registered_User_Data_Verification_In_GSTR_2_S_Credit_Debit_Notes_Registered_6C,
    User_Data_Verification_In_GSTR_2_S_B2B_Invoice_4A,
    User_Data_Verification_In_GSTR_2_S_B2BUR__4B, B2B_Invoices_3_4A_Column_Total, B2BUR_4B_Column_Total,
    Credit_Debit_Notes_UnRegistered_6C_Column_Total, Credit_Debit_Notes_Registered_6C_Column_Total, PDF_Export, Reset
}
