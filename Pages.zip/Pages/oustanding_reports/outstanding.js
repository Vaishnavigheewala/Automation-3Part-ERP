const { test, expect } = require('@playwright/test');
const locators = require('./outstanding.json');
const { TIMEOUT } = require('dns');
const fs = require('fs');


async function selectsubmenuofoutstanding(page,menu) {
    
        if (menu == "Reports") {
            await page.locator(locators.reports_menu.reports).click();
            await page.locator(locators.reports_menu.outstanding_menu).click();
            await expect(page.locator('li.breadcrumb-item.active', { hasText: 'Outstanding Report' })).toBeVisible();
    
        }
}

async function selectfilterResetOutstanding(page, customername ,date,companyname ) {

    const backButton = page.locator('button:has-text("Back")');
    const pdfExportButton = page.locator('button:has-text("PDF Export")');
    const filterButton = page.locator('button:has-text("Filter")');
    
    await expect(backButton).toBeVisible();
    await expect(pdfExportButton).toBeVisible();
    await expect(filterButton).toBeVisible();
  
    const button = await page.locator('span.e-ungroupbutton[title="Ungroup by this column"]').nth(0);
    await button.click();
  
    console.log('Back, PDF Export, and Filter buttons are visible');
  
      await page.locator(locators.outstanding.outstanding_filter).click();
  
      await page.locator(locators.customerdropdown).click();
      await page.fill(locators.entercustomername, customername);
      await page.waitForTimeout(1000);
      
      const datepicker = '#OutstandingReportDateRangePickerForFilter'; //code to clear the date
      await page.fill(datepicker, ''); //code to clear the date
      await page.fill(datepicker, date); //code to enter current data

      await page.locator(locators.companydropdown).click();
      await page.fill(locators.entercustomername, companyname);
      await page.waitForTimeout(1000);

      await page.locator(locators.outstanding.outstanding_reset).click();
      await page.waitForTimeout(1000);
      await page.locator(locators.outstanding.outstanding_close).click();
  }


  async function selectfilterSearchOutstandingcust(page, customername ,companyname ) {
      await page.locator(locators.outstanding.outstanding_filter).click();
  
      await page.locator(locators.customerdropdown).click();
      await page.fill(locators.entercustomername, customername);
      await page.locator('li.e-list-item', { hasText: customername }).click();
      await page.waitForTimeout(1000);

      await page.locator(locators.companydropdown).click();
      await page.fill(locators.entercustomername, companyname);
      await page.locator('li.e-list-item', { hasText: companyname }).click();
      await page.waitForTimeout(1000);

      await page.locator(locators.outstanding.outstanding_search).click();
      await page.waitForTimeout(1000);

      await page.locator(locators.outstanding.outstanding_pdf).click();
      await page.waitForTimeout(1000);
  }

  async function selectfilterSearchOutstandingvendor(page, vendorname ,companyname ) {
    await page.locator(locators.outstanding.outstanding_filter).click();

    await page.locator(locators.vendordropdown).click();
    await page.fill(locators.entercustomername, vendorname);
    await page.locator('li.e-list-item', { hasText: vendorname }).click();
    await page.waitForTimeout(1000);

    await page.locator(locators.companydropdown).click();
    await page.fill(locators.entercustomername, companyname);
    await page.locator('li.e-list-item', { hasText: companyname }).click();
    await page.waitForTimeout(1000);

    await page.locator(locators.outstanding.outstanding_search).click();
    await page.waitForTimeout(1000);

    await page.locator(locators.outstanding.outstanding_back).click();
    await page.waitForTimeout(1000);
}

async function sorting(page) {
    await page.locator(locators.bill_no).dblclick();
    await page.locator(locators.bill_no).click();
    console.log("Records are sorted by bill no");

}

module.exports = { selectsubmenuofoutstanding,selectfilterResetOutstanding,selectfilterSearchOutstandingcust,selectfilterSearchOutstandingvendor,sorting}