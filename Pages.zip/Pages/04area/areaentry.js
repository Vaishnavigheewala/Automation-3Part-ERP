const { test, expect } = require('@playwright/test');
const locators = require('./areaentry.json');

async function add_area_data(page, state, city, area) {
    await page.locator(locators.brokermenu.broker_page).click();
    console.log('Step 4: Broker Page Displayed Sucessfully');

    await page.locator(locators.state_name).click();
    await page.fill(locators.entercity, state);
    await page.locator('li.e-list-item', { hasText: state }).click();

    await page.locator(locators.city_name).click();
    await page.fill(locators.entercity, city);
    await page.locator('li.e-list-item', { hasText: city }).nth(0).click();

    await page.locator(locators.area_name).click();
    await page.fill(locators.area_name, area);

    console.log('Step 5: Entered area Data Sucessfully');
    await page.waitForTimeout(1000);
    await page.locator(locators.submit_btn).click();
    console.log('Step 6: area Added Sucessfully');

    await page.locator(locators.pdf_btn).click();
    console.log('Step 7: Pdf Downloaded Sucessfully')

    await page.locator(locators.reset_btn).click();

    let Pagination = await page.locator("//div[@class='e-pagercontainer']").isVisible();
    console.log("Pagination Available = ", Pagination);
}

async function verifyareadata(page, area) {
    await page.locator(locators.accountentry).click();
    await page.waitForTimeout(2000);

    await page.locator(locators.account_area).click();
    await page.fill(locators.account_area_input, area);
    //await page.locator('li.e-list-item', { hasText: area }).click(); 
    await page.waitForTimeout(5000);
}

async function update_area_data(page, state, city, area) {
    await page.locator(locators.state_name).click();
    await page.fill(locators.entercity, state);
    await page.locator('li.e-list-item', { hasText: state }).click();

    await page.locator(locators.city_name).click();
    await page.fill(locators.entercity, city);
    await page.locator('li.e-list-item', { hasText: city }).nth(0).click();

    await page.locator(locators.area_name).click();
    const areadata = area;
    await page.fill(locators.area_name, area);

    // const isChecked = await page.getByRole('checkbox');
    // if (!isChecked) {
    //     await page.getByRole('checkbox').click();  // This will check the checkbox if it's unchecked
    // }else if (isChecked) {
    //     await page.getByRole('checkbox').click();
    // }

    await page.locator(locators.add_area_data).click();

    console.log('Step 9: Entered Updated area Data Sucessfully');
    await page.locator(locators.update_btn).click();
    await page.waitForTimeout(1000);
    console.log('Step 10: area Data Updated Sucessfully');

}

async function editlink(page) {
    const rows = await page.locator('tr[aria-rowindex]'); // Select all rows with aria-rowindex
    const firstRow = await rows.nth(0); // Select the first row
    const edit = await firstRow.locator('a[title="View area detail"]');
    edit.click();
    console.log("step 8: Update Link Clicked")
    await page.waitForTimeout(5000);

}


module.exports = { add_area_data, update_area_data, editlink, verifyareadata }