const { test, expect } = require('@playwright/test');
const locators = require('./payable.json');
const { TIMEOUT } = require('dns');
const fs = require('fs');


async function selectsubmenuofpayable(page,menu) {
    
        if (menu == "Reports") {
            await page.locator(locators.reports_menu.reports).click();
            await page.locator(locators.reports_menu.payable_menu).click();
            await expect(page.locator('li.breadcrumb-item.active', { hasText: 'Payable' })).toBeVisible();
    
        }
}

async function selectfilterResetPayable(page, vendorname ,date ) {

  const backButton = page.locator('button:has-text("Back")');
  const pdfExportButton = page.locator('button:has-text("PDF Export")');
  const filterButton = page.locator('button:has-text("Filter")');
  
  await expect(backButton).toBeVisible();
  await expect(pdfExportButton).toBeVisible();
  await expect(filterButton).toBeVisible();

  const button = await page.locator('span.e-ungroupbutton[title="Ungroup by this column"]');
    await button.click();

  console.log('Back, PDF Export, and Filter buttons are visible');

    await page.locator(locators.payable.payable_filter).click();

    await page.locator(locators.vendordropdown).click();
    await page.fill(locators.entercustomername, vendorname);
    await page.waitForTimeout(1000);
    
    const datepicker = '#PayableReportDatePickerForFilter'; //code to clear the date
    await page.fill(datepicker, ''); //code to clear the date
    await page.fill(datepicker, date); //code to enter current data
    await page.locator(locators.payable.payable_reset).click();
    await page.waitForTimeout(1000);
    await page.locator(locators.payable.payable_close).click();


}


async function selectfilterPayable(page, vendorname ) {
  await page.locator(locators.payable.payable_filter).click();

    //await page.locator(locators.Itemwise_report.Itemwise_Filter).click();
    
    await page.locator(locators.vendordropdown).click();
    await page.fill(locators.entercustomername, vendorname);
    await page.locator('li.e-list-item', { hasText: vendorname }).click();
    await page.waitForTimeout(3000);
  
    await page.locator(locators.payable.payable_search).click();
    await page.waitForTimeout(1000);

    await page.locator(locators.payable.payable_back).click();
    await page.waitForTimeout(1000);

    await page.locator(locators.payable.payable_pdf).click();
    await page.waitForTimeout(1000);


}

async function sortingPayable(page) {
  await page.locator(locators.bill).click();
  console.log("The report is sorted by Bill No in assending order");
  await page.locator(locators.bill).click();
  console.log("The report is sorted by Bill No in descending order");

  const bill_no = await page.isVisible(locators.bill_no);
  console.log(`bill_no: ${bill_no}`);
  console.log('All verifications completed successfully!');
}

module.exports = { selectsubmenuofpayable , selectfilterResetPayable , selectfilterPayable,sortingPayable}