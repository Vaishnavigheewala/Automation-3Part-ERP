const { test, expect } = require('@playwright/test');
const locators = require('./editsale.json');
const fs = require('fs');

async function viewlink(page) {

    await page.evaluate(() => { window.scrollTo(0, document.body.scrollHeight); });
    /*****************Verify Customer Name is Correct ************************/
    const Verifycustomer = JSON.parse(fs.readFileSync('Verifycustomer.json')); //Read the shared Net Amount from the JSON file
    const sharedcustomername = Verifycustomer.customername;
    const rows = await page.locator('tr[aria-rowindex]'); // Select all rows with aria-rowindex
    const firstRow = await rows.nth(0); // Select the first row
    const valueone = await firstRow.locator("td#SalesCustomerNameColumn"); //Extract the Net Amount from the latest row
    //const customernamecolumn = await valueone.innerText();
    //expect(sharedcustomername).toBe(customernamecolumn);
    console.log(" Customer Name before Submit is same as Customer Name on the grid")
    /*********Scroll Right******************/
    await page.waitForTimeout(3000);
    const divElement = await page.$('div.e-content.e-yscroll.e-lib.e-droppable'); // Replace with your actual selector
    await page.evaluate((el) => {
        el.scrollLeft += 600; // Adjust this value to scroll further or slower
    }, divElement);

    //Locate and click the "view" Button
    const viewButton = await firstRow.locator('a#SalesViewButton'); //Adjust this with the actual selector for the "View" 

    // Check if the "View" button is visible
    const isVisible = await viewButton.isVisible();
    if (isVisible) {
        console.log('View button is visible. Proceeding with click.');
        await viewButton.click();
        console.log(' Clicked on "View" button.');
    } else {
        console.log('View button is not found or not visible.');
    }
    await page.waitForTimeout(3000);
}

async function Editbutton(page) {

    //  Wait for the Edit button to be visible
    await page.evaluate(() => { window.scrollTo(0, document.body.scrollHeight); });
    await page.locator(locators.editButton).click();
    console.log('Edit button is visible. Clicking on it.');
    await page.waitForTimeout(2000);
}


async function editsalesdetails(page, broker) {

    await page.locator(locators.brokerdropdown).click();
    await page.fill(locators.entercustomername, broker);
    await page.waitForTimeout(1000);
    //  Select the desired Broker by its text
    await page.locator('li.e-list-item', { hasText: broker }).click();


}

async function submitbutton(page) {

    await page.evaluate(() => { window.scrollTo(0, document.body.scrollHeight); });
    await page.locator(locators.submitsales).click();

}


async function selectsubmenuitemwise(page, menu) {
    if (menu == "Transaction") {
        await page.locator(locators.salesmenu.sales_menu).click();
        await page.locator(locators.salesmenu.sales_gstsales).click();
        await expect(page.locator('li.breadcrumb-item.active', { hasText: 'Sales' })).toBeVisible();


    }
    else if (menu == "Reports") {
        await page.locator(locators.reportsmenu.sales_menu).click();
        await page.locator(locators.reportsmenu.reportitemwise).click();
        await expect(page.locator('li.breadcrumb-item.active', { hasText: 'Item Wise Sales Report' })).toBeVisible();

    }

}


async function selectfilteritemwise(page, customername) {

    await page.locator(locators.filterbutton).click();
    await page.locator(locators.customerfilter).click();
    await page.fill(locators.entercustomername, customername);
    await page.waitForTimeout(1000);
    // Select the desired customer by its text
    const itemLocator = page.locator(`//td[@title='${customername}']`);
    //await expect(itemLocator).toBeVisible();
    await itemLocator.click();
    
    await page.locator(locators.searchbutton).click();

}



async function verifydetailsitemwise(page) {
    /*****************Verify Customer Name is Correct ************************/
    const Verifycustomer = JSON.parse(fs.readFileSync('Verifycustomer.json')); //Read the shared Net Amount from the JSON file
    const sharedcustomername = Verifycustomer.customername;
    const rows = await page.locator('tr[aria-rowindex]'); // Select all rows with aria-rowindex
    const firstRow = await rows.nth(0); // Select the first row
    await page.waitForTimeout(1000);
    const valuethree = await firstRow.locator("td#ItemWiseSalesReportCustomerNameColumn");
    //const customernamecolumn = await valuethree.innerText();
    //expect(sharedcustomername).toBe(customernamecolumn);
    console.log(" Customer Name before Submit is same as Customer Name on the Itemwise Sales Report")
    const datatwo = JSON.parse(fs.readFileSync('Verifylatestgstbill.json'));
    const sharedlatestBillNumber = datatwo.latestGstbillnumber;
    const valuetwo = await firstRow.locator("td#ItemWiseSalesReportBillNumberColumn");
    const gstbillonreport = await valuetwo.innerText();
    const numericPart = gstbillonreport.slice(2);
    const gstBillNumber = parseInt(numericPart, 10);
    expect(sharedlatestBillNumber).toBe(gstBillNumber);
    console.log(" Correct GST Bill # is displayed ");

}

async function selectsubmenusalesummary(page, menu) {
    if (menu == "Transaction") {
        await page.locator(locators.salesmenu.sales_menu).click();
        await page.locator(locators.salesmenu.sales_gstsales).click();
        await expect(page.locator('li.breadcrumb-item.active', { hasText: 'Sales' })).toBeVisible();


    }
    else if (menu == "Reports") {
        await page.locator(locators.reportsmenu.sales_menu).click();
        await page.locator(locators.reportsmenu.reportsalesummary).click();
        await expect(page.locator('li.breadcrumb-item.active', { hasText: 'Sales Summary Report' })).toBeVisible();

    }

}

async function selectfiltersalesummary(page, customername) {

    await page.locator(locators.Filterbtnsalesummaryreport).click();
    await page.locator(locators.FilterCustsalesummary).click();
    await page.fill(locators.entercustomername, customername);
    await page.waitForTimeout(1000);
    //  Select the desired customer by its text
    const itemLocator = page.locator(`//td[@title='${customername}']`);
    //await expect(itemLocator).toBeVisible();
    await itemLocator.click();
    
    await page.locator(locators.Searchbtnsalesummary).click();

}

async function verifydetailssalesummary(page) {
    /*****************Verify Customer Name is Correct ************************/
    const button = await page.locator('span.e-ungroupbutton[title="Ungroup by this column"]');
    await button.click();  // To perform a click action on the element

    const rows = await page.locator('tr[aria-rowindex]'); // Select all rows with aria-rowindex
    const firstRow = await rows.nth(0); // Select the first row

    //Locate and click the "view" Button
    const viewButton = await firstRow.locator('a#SalesSummaryReportViewRegularBillNumberDetails'); //Adjust this with the actual selector for the "View" 

    // Check if the "View" button is visible
    const isVisible = await viewButton.isVisible();
    if (isVisible) {
        console.log('View button is visible. Proceeding with click.');
        await viewButton.click();
        console.log(' Clicked on "View" button.');
    } else {
        console.log('View button is not found or not visible.');
    }
    await page.waitForTimeout(3000);
    console.log("successfully click on view link")
    const brokerInputField = await page.locator('#SalesViewBrokerName');
    //    const brokerNameValue = await brokerInputField.inputValue();  // Get the current value of the input

    //    expect(brokerNameValue).toBe('PRAVINBHAI');  // Replace with the expected broker name
}

async function Combinedsalereports(page,customer_name) {
    await page.click(locators.combinedsale.sales);
    await page.click(locators.combinedsale.combinedsalepage);
    await page.click(locators.combinedsale.filterbutton);
    await page.waitForTimeout(1000);
    await page.click(locators.customerdropdown);
    await page.waitForTimeout(1000);
    await page.fill(locators.entercustomername, customer_name);
    await page.waitForTimeout(1000);
    await page.locator('li.e-list-item', { hasText: customer_name }).click();

    await page.waitForTimeout(1000);
    await page.click(locators.combinedsale.searchbutton);
    console.log('Sales Summary Report verification completed successfully.');


}

async function selectsubmenuOutstanding(page, menu) {
    if (menu == "Transaction") {
        await page.locator(locators.salesmenu.sales_menu).click();
        await page.locator(locators.salesmenu.sales_gstsales).click();
        await expect(page.locator('li.breadcrumb-item.active', { hasText: 'Sales' })).toBeVisible();



    }
    else if (menu == "Reports") {
        await page.locator(locators.reportsmenu.reportoutstanding).click();
        await expect(page.locator('li.breadcrumb-item.active', { hasText: 'OutStanding Report' })).toBeVisible();

    }
}
async function selectfilterOutstanding(page, customername) {

    await page.locator(locators.Filterbtnoutstanding).click();
    await page.locator(locators.FilterCustsalesummary).click();
    await page.fill(locators.entercustomername, customername);
    await page.waitForTimeout(1000);
    //  Select the desired customer by its text
    const itemLocator = page.locator(`//td[@title='${customername}']`);
    //await expect(itemLocator).toBeVisible();
    await itemLocator.click();
    
    await page.locator(locators.Searchbtnoutstanding).click();

}


async function inventorystockreports(page, inventoryname) {
    await page.locator(locators.inventorystockreport.inventoryStock).click();
    await page.click('#InventoryReportopenSideBarButton');
    await page.click(locators.inventorystockreport.FilterInventorygroup);
    await page.click("//li[normalize-space()='FinishMaterial']");
    await page.waitForTimeout(2000);
    await page.locator(locators.inventorystockreport.inventoryselect).click();

    await page.fill(locators.inventorystockreport.enterInventory, inventoryname);
    await page.locator('li.e-list-item', { hasText: inventoryname }).click();

    await page.locator(locators.inventorystockreport.inventorysearchbutton).click();


}

async function selectsubmenucustaccountledger(page, menu) {
    if (menu == "Transaction") {
        await page.locator(locators.salesmenu.sales_menu).click();
        await page.locator(locators.salesmenu.sales_gstsales).click();
        await expect(page.locator('li.breadcrumb-item.active', { hasText: 'Sales' })).toBeVisible();


    }
    else if (menu == "Reports") {
        await page.locator(locators.reportsmenu.accountledger).click();
        await page.locator(locators.reportsmenu.reportcustaccountledger).click();
        await expect(page.locator('li.breadcrumb-item.active', { hasText: 'Customer Account Ledger Report' })).toBeVisible();

    }

}

async function selectfiltercustaccountledger(page, customername) {

    await page.locator(locators.Filterbtncustledger).click();
    await page.locator(locators.FilterCustsalesummary).click();
    await page.fill(locators.entercustomername, customername);
    await page.waitForTimeout(1000);
    //  Select the desired customer by its text
    const itemLocator = page.locator(`//td[@title='${customername}']`);
    //await expect(itemLocator).toBeVisible();
    await itemLocator.click();
    
    await page.locator(locators.Searchbtncustledger).click();

}



module.exports = {
    viewlink, Editbutton, editsalesdetails, submitbutton, selectsubmenuitemwise,
    selectfilteritemwise, verifydetailsitemwise, selectsubmenusalesummary, selectfiltersalesummary,
    verifydetailssalesummary, Combinedsalereports, selectsubmenuOutstanding, selectfilterOutstanding,
    inventorystockreports, selectsubmenucustaccountledger, selectfiltercustaccountledger
};