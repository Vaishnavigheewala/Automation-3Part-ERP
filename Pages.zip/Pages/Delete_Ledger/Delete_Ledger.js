const { test, expect } = require('@playwright/test');
const locators = require('./Delete_Ledger.json');

async function deleteledger(page,customerName,vendorName){
    await page.locator(locators.CashLedger.TransactionMenu).click();
    await page.locator(locators.CashLedger.Ledger).click();
    await page.locator(locators.CashLedger.CashLedgerpage).click();

    //select customer
  await page.locator(locators.CashLedger.AccountGroup).click();
  await page.locator("//li[normalize-space()='Customer']").click();

  await page.locator(locators.CashLedger.customername).click();
  await page.waitForTimeout(2000);
  await page.fill(locators.CashLedger.entercustomername, customerName);
  await page.locator('li.e-list-item', { hasText: customerName }).click();
  await page.waitForTimeout(2000);
  await page.click(locators.CashLedger.Searchbutton);
  await page.waitForSelector("//td[@id='CashLedgerListVoucherNoColumn']");

  // Fetch the latest Amc  number from the regular amc no column
  const DeletedBillNo = await page.locator("//td[@id='CashLedgerListVoucherNoColumn']").nth(0).textContent();


  if (!DeletedBillNo || DeletedBillNo.trim() === "") {
    console.log('No latest bill number found. Exiting...');
  }
 
  console.log(`Latest bill No: ${DeletedBillNo.trim()}`);

//delete ledger
 await page.locator(locators.delete_menu).click();
    await page.locator(locators.Delete_Ledger).click();
    await page.fill(locators.Ledger_No, DeletedBillNo);


  // Select the "Amc Invoice without Ledger (Payment)" radio button
  await page.locator(locators.Ledger_Radio).scrollIntoViewIfNeeded();
  await page.locator(locators.Ledger_Radio).check({ force: true });
  await page.waitForTimeout(2000);
  // Click the Delete button
  await page.locator(locators.Delete_Btn).click();
  await page.waitForTimeout(2000);
  const successMessage = await page.locator('.e-toast-content');
  await expect(successMessage).toBeVisible();
  await expect(successMessage).toHaveText('Entered data of Ledger does not match with actual data.');

  await page.locator(locators.CashLedger.TransactionMenu).click();
  await page.locator(locators.CashLedger.Ledger).click();
  await page.locator(locators.CashLedger.CashLedgerpage).click();

  //select customer
await page.locator(locators.CashLedger.AccountGroup).click();
await page.locator("//li[normalize-space()='Vendor']").click();

await page.locator(locators.CashLedger.vendorname).click();
  await page.waitForTimeout(1000);
  await page.fill(locators.CashLedger.entercustomername, vendorName);
  await page.locator('li.e-list-item', { hasText: vendorName }).click();

  await page.click(locators.CashLedger.Searchbutton);
  await page.waitForTimeout(2000);
  await page.waitForSelector("//td[@id='CashLedgerListVoucherNoColumn']");

  // Fetch the latest Amc  number from the regular amc no column
  const DeletedVendorNo = await page.locator("//td[@id='CashLedgerListVoucherNoColumn']").nth(0).textContent();
  const DeletedVendorGSTNo = await page.locator("//td[@id='CashLedgerListBillNoColumn']").nth(0).textContent();


  if (!DeletedVendorNo || DeletedVendorNo.trim() === "") {
    console.log('No latest bill number found. Exiting...');
  }

  if (!DeletedVendorGSTNo || DeletedVendorGSTNo.trim() === "") {
    console.log('No latest bill number found. Exiting...');
  }
 
  console.log(`Latest bill No: ${DeletedVendorNo.trim()}`);


  //delete ledger
 await page.locator(locators.delete_menu).click();
 await page.locator(locators.Delete_Ledger).click();
 await page.fill(locators.Ledger_No, DeletedVendorNo);


// Select the "Amc Invoice without Ledger (Payment)" radio button
await page.locator(locators.Ledger_Radio).scrollIntoViewIfNeeded();
await page.locator(locators.Ledger_Radio).check({ force: true });
await page.waitForTimeout(2000);
// Click the Delete button
await page.locator(locators.Delete_Btn).click();
await page.waitForTimeout(2000);
const successMessage1 = await page.locator('.e-toast-content');
await expect(successMessage1).toBeVisible();
await expect(successMessage1).toHaveText('Ledger Deleted Successfully.');


//outstanding Report
await page.locator(locators.reports_menu.reports).click();
await page.locator(locators.reports_menu.outstanding_menu).click();

await page.locator(locators.outstanding.outstanding_filter).click();

await page.locator(locators.CashLedger.customername).click();
await page.waitForTimeout(2000);
await page.fill(locators.CashLedger.entercustomername, customerName);
await page.locator('li.e-list-item', { hasText: customerName }).click();

await page.locator(locators.outstanding.outstanding_search).click();

await page.waitForSelector(`tr:has(td:has-text("${customerName}"))`, { timeout: 60000 });
await page.locator(`tr:has(td:has-text("${customerName}"))`);

const billAmount = await page.locator('td.e-summarycell[data-cell="Bill Amt"]').textContent();
const totalReceived = await page.locator('td.e-summarycell[data-cell="Total Received"]').textContent();
const exchangeAmount = await page.locator('td.e-summarycell[data-cell="ExchangeAmt"]').textContent();
const balance = await page.locator('td.e-summarycell[data-cell="Balance"]').textContent();

console.log(`Bill Amount: ${billAmount}`);
console.log(`Total Received: ${totalReceived}`);
console.log(`Exchange Amount: ${exchangeAmount}`);
console.log(`Balance: ${balance}`);

expect(billAmount).not.toBeNull();
expect(totalReceived).not.toBeNull();
expect(exchangeAmount).not.toBeNull();
expect(balance).not.toBeNull();


//Customer Account Ledger Report
await page.locator(locators.reports_menu.reports).click();
await page.locator(locators.reports_menu.account_ledger).click();
await page.locator(locators.reports_menu.customer_ledger).click();




await page.locator(locators.customer_ledger.customer_ledger_filter).click();
await page.locator(locators.CashLedger.customername).click();
await page.waitForTimeout(2000);
await page.fill(locators.CashLedger.entercustomername, customerName);
await page.locator('li.e-list-item', { hasText: customerName }).click();
await page.waitForTimeout(1000);
await page.locator(locators.customer_ledger.customer_ledger_search).click();


await page.waitForSelector(`tr:has(td:has-text("${customerName}"))`, { timeout: 60000 });
await page.locator(`tr:has(td:has-text("${customerName}"))`);

const balance2 = await page.locator('td.e-summarycell[data-cell="Balance"]').textContent();
 console.log(`customer Ledger Report Overall Balance: ${balance2}`);
    expect(parseFloat(balance)).toBe(parseFloat(balance2));
    console.log('Consistency between Outstanding Report and Account Ledger verified successfully.');

    await page.evaluate(() => window.scrollTo(0, document.body.scrollHeight));

    let billFoundout = false;
  
    // Get all rows in the grid
    await page.waitForSelector('tr[aria-rowindex]', { state: 'visible' });
    const rowsout = await page.locator('tr[aria-rowindex]');
    const rowCountout = await rowsout.count();
    console.log(` Total rows in grid: ${rowCountout}`);
  
    // Iterate through each row to check if the deleted bill number exists
    for (let i = 0; i < rowCountout; i++) {  // Loop through all available rows
      const currentRow = await rowsout.nth(i);
      const billNumberCell = await currentRow.locator("td#AccountLedgerReportGridTransactionNumberColumn").innerText();
  
      // Debug log for current amc number in grid
      console.log(`Row ${i + 1} Bill Number:`, billNumberCell);
  
  
      if (billNumberCell === DeletedVendorNo) {
        billFoundout = true;
        break;
      }
    }
  
    // Assert that the deleted amc number is not found in the grid
    expect(billFoundout).toBe(false);
    if (!billFoundout) {
      console.log(` Successfully verified that deleted bill number ${DeletedVendorNo} is not present in grid.`);
    } else {
      console.error(` Error - Deleted bill number ${DeletedVendorNo} was found in  grid.`);
    }

    //payable Reports
    await page.locator(locators.reports_menu.reports).click();
    await page.locator(locators.reports_menu.payable_menu).click();

    await page.locator(locators.payable.payable_filter).click();
    await page.locator(locators.payable.vendordropdown).click();
    await page.fill(locators.entercustomername, vendorName);
    await page.locator('li.e-list-item', { hasText: vendorName }).click();


    await page.locator(locators.payable.payable_search).click();
    await page.waitForTimeout(1000);

    await page.waitForSelector(`tr:has(td:has-text("${vendorName}"))`, { timeout: 60000 });
await page.locator(`tr:has(td:has-text("${vendorName}"))`);

const BillAmt = await page.locator('td.e-summarycell[data-cell="Bill Amt"]').textContent();
const TotalPaidAmt = await page.locator('td.e-summarycell[data-cell="TotalPaidAmt"]').textContent();
const RemainingBalance = await page.locator('td.e-summarycell[data-cell="Remaining Balance"]').textContent();

console.log(`Bill Amount: ${BillAmt}`);
console.log(`Total PaidAmt: ${TotalPaidAmt}`);
console.log(`Remaining Balance: ${RemainingBalance}`);

expect(BillAmt).not.toBeNull();
expect(TotalPaidAmt).not.toBeNull();
expect(RemainingBalance).not.toBeNull();

//vendor account ledger report
await page.locator(locators.reports_menu.reports).click();
await page.locator(locators.reports_menu.account_ledger).click();
await page.locator(locators.reports_menu.vendor_ledger).click();

await page.locator(locators.vendor_ledger.vendor_ledger_filter).click();


    await page.locator(locators.CashLedger.vendorname).click();
    await page.fill(locators.CashLedger.entercustomername, vendorName);
    await page.locator('li.e-list-item', { hasText: vendorName }).click();

    await page.locator(locators.vendor_ledger.vendor_ledger_search).click();

  await page.evaluate(() => window.scrollTo(0, document.body.scrollHeight));

    let billFoundVAL = false;
  
    // Get all rows in the grid
    await page.waitForSelector('tr[aria-rowindex]', { state: 'visible' });
    const rowVAL = await page.locator('tr[aria-rowindex]');
    const rowCountVAL = await rowVAL.count();
    console.log(` Total rows in grid: ${rowCountVAL}`);
  
    // Iterate through each row to check if the deleted bill number exists
    for (let i = 0; i < rowCountVAL; i++) {  // Loop through all available rows
      const currentRow = await rowVAL.nth(i);
      const billNumberCell = await currentRow.locator("td#VendorAccountLedgerReportGridVendorTransactionNoColumn").innerText();
  
      // Debug log for current amc number in grid
      console.log(`Row ${i + 1} Bill Number:`, billNumberCell);
  
  
      if (billNumberCell === DeletedVendorGSTNo) {
        billFoundVAL = true;
        break;
      }
    }
  
    // Assert that the deleted amc number is not found in the grid
    expect(billFoundVAL).toBe(false);
    if (!billFoundVAL) {
      console.log(` Successfully verified that deleted bill number ${DeletedVendorGSTNo} is not present in grid.`);
    } else {
      console.error(` Error - Deleted bill number ${DeletedVendorGSTNo} was found in  grid.`);
    }



  






}

module.exports = {deleteledger };