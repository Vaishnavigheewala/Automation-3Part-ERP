const { test, expect } = require('@playwright/test');
const locators = require('./proformaSale.json');
const { TIMEOUT } = require('dns');
const fs = require('fs');


async function selectsubmenu(page,menu) {
    if (menu=="Transaction") 
        {
            await page.locator(locators.sale_menu.TransactionSale_menu).click();
            await page.locator(locators.sale_menu.Proforma_menu).click();
            await expect(page.locator('li.breadcrumb-item.active', { hasText: 'Proforma sales' })).toBeVisible();                          
        }            
}

async function verifyPerformaSale(page,customer){
    const date = await page.isVisible(locators.verify_sale.date);
    const customer_name = await page.isVisible(locators.verify_sale.customerdropdown);
   
    console.log(`date: ${date}`);
    console.log(`Customer: ${customer_name}`);
    
    // await page.locator(locators.verify_sale.date).click();
    // const datepicker = '#ProFormaSalesDateRangePickerForFilter'; //code to clear the date
    // await page.fill(datepicker, ''); //code to clear the date
    // await page.fill(datepicker, '24-12-2024	 - 24-12-2024'); 

    await page.waitForTimeout(3000);
    
    await page.waitForTimeout(1000);
    await page.locator(locators.verify_sale.customerdropdown).click();
    await page.waitForTimeout(2000);
    await page.fill(locators.verify_sale.entercustomername, customer);
    await page.locator('li.e-list-item', { hasText: customer }).click();

    await page.waitForTimeout(1000);
    await page.locator(locators.verify_sale.proforma_search).click();
    console.log('Search Functionallity Working Sucess')

    await page.waitForTimeout(1000);
    await page.locator(locators.verify_sale.proforma_reset).click();
    console.log('Reset Functionallity working Sucess');
}


async function verifyPerformaSaleGrid(page) {
    const columns = [
        locators.verify_grid.bill_date,
        locators.verify_grid.customernameTH,
        locators.verify_grid.brokernameTH,
        locators.verify_grid.paymentTypeTH,
        locators.verify_grid.InvoiceType,
        locators.verify_grid.TaxMethod,
        locators.verify_grid.StateNameTH,
        locators.verify_grid.TotalQtyTH,
        locators.verify_grid.AddLesTH,
        locators.verify_grid.RoundOffTH,
        locators.verify_grid.NetAmountTH,
        locators.verify_grid.ActionTH,
        locators.verify_sale.profroma_add

    ];
 
    for (const column of columns) {
        const isVisible = await page.isVisible(column);
        console.log(`${column} visible: ${isVisible}`);
    }
}

async function viewlink(page) {
 
    await page.evaluate(() => { window.scrollTo(0, document.body.scrollHeight);});
         /*********Scroll Right******************/
       await page.waitForTimeout(3000);
       const divElement = await page.$('div.e-content.e-yscroll.e-lib.e-droppable'); // Replace with your actual selector
       await page.evaluate((el) => {
            el.scrollLeft += 600; // Adjust this value to scroll further or slower
           }, divElement);
   
        //Locate and click the "view" Button
        const rows = await page.locator('tr[aria-rowindex]'); // Select all rows with aria-rowindex
        const firstRow = await rows.nth(0); // Select the first row
        const viewButton = await firstRow.locator('a#ProFormaSalesViewButton'); //Adjust this with the actual selector for the "View"
   
        // Check if the "View" button is visible
        const isVisible = await viewButton.isVisible();
        if (isVisible) {
            console.log('View button is visible. Proceeding with click.');
            await viewButton.click();
            console.log('Clicked on "View" button.');
        } else {
            console.log('View button is not found or not visible.');
        }
        await page.waitForTimeout(1000);
        await page.evaluate(() => { window.scrollTo(0, document.body.scrollHeight, { timeout: 30000 }); });
        await page.waitForTimeout(1000);
        await page.locator(locators.verify_sale.proforma_close).click();
        //await page.waitForTimeout(5000);

}


async function Invoicelink(page) {
 
         /*********Scroll Right******************/
       //
       // await page.waitForTimeout(3000);
    //    const divElement = await page.$('div.e-content.e-yscroll.e-lib.e-droppable'); // Replace with your actual selector
    //    await page.evaluate((el) => {
    //         el.scrollLeft += 600; // Adjust this value to scroll further or slower
    //        }, divElement);
   
        //Locate and click the "view" Button
        const rows = await page.locator('tr[aria-rowindex]'); // Select all rows with aria-rowindex
        const firstRow = await rows.nth(1); // Select the first row
        const InvoiceButton = await firstRow.locator('a#ProFormaSalesInvoiceOpenButton'); //Adjust this with the actual selector for the "View"
   
        // Check if the "View" button is visible
        const isVisible = await InvoiceButton.isVisible();
        if (isVisible) {
            console.log('Invoice button is visible. Proceeding with click.');
            await InvoiceButton.click();
            console.log('Clicked on "Invoice" button.');
        } else {
            console.log('Invoice button is not found or not visible.');
        }
        await page.waitForTimeout(1000);
        await page.locator(locators.verify_sale.proforma_download).nth(0).click();
        await page.locator(locators.verify_sale.yes).click();
        //await page.waitForTimeout(5000);

}

async function addproformaSale(page,customer,broker,item,qty) {
    
        await page.locator(locators.verify_sale.profroma_add).click();
        console.log("click on add button so that add proforma sale");


        const date = await page.isVisible(locators.proforma_register.register_date);
        console.log(`date: ${date}`);
        const customername = await page.isVisible(locators.proforma_register.customerdropdown);
        console.log(`Customer Name: ${customername}`);
        const payment_type = await page.isVisible(locators.proforma_register.paymentType);
        console.log(`payment type: ${payment_type}`)
        const broker_name = await page.isVisible(locators.proforma_register.brokerdropdown);
        console.log(`Broker Name : ${broker_name}`);
        const gstin = await page.isVisible(locators.proforma_register.gst);
        console.log(`GST IN : ${gstin}`);
        const mobileno = await page.isVisible(locators.proforma_register.mobile);
        console.log(`Mobile : ${mobileno}`);
        const tax_method = await page.isVisible(locators.proforma_register.taxmethod);
        console.log(`Tax Method : ${tax_method}`);
        const State = await page.isVisible(locators.proforma_register.state);
        console.log(`State : ${State}`);
        const posno = await page.isVisible(locators.proforma_register.POS);
        console.log(`POS NO : ${posno}`);
        const deilveryadd = await page.isVisible(locators.proforma_register.deilveryaddress);
        console.log(`Delivery Address : ${deilveryadd}`);
        const Invoice_type = await page.isVisible(locators.proforma_register.invoicetype);
        console.log(`Invoice Type : ${Invoice_type}`);
        console.log('Verify add Proforma Sales Register Page');

        await page.waitForTimeout(1000);
        await page.locator(locators.proforma_register.customerdropdown).click();
        await page.waitForTimeout(2000);
        await page.fill(locators.proforma_register.entercustomername, customer);
        await page.locator('li.e-list-item', { hasText: customer }).click();


        await page.waitForTimeout(1000);
        await page.locator(locators.proforma_register.brokerdropdown).click();
        //await page.waitForTimeout(2000);
        await page.fill(locators.proforma_register.enterbrokername, broker);
        await page.locator('li.e-list-item', { hasText: broker }).click();

        //await page.locator(locators.proforma_register.gst).click();

        await page.locator(locators.proforma_register.proforma_addgrid).click();

        await page.click(locators.proforma_register.proforma_inventoryGroup);
        await page.click(locators.proforma_register.proforma_selectinventory);
        console.log("Select Inventory Group in Grid");

        await page.locator('td.e-rowcell.e-lastrowcell.e-updatedtd.e-selectionbackground.e-active[aria-label=" Column Header Item"]').click();
        await page.locator(locators.proforma_register.proforma_itemsgrid).click();
        await page.fill(locators.proforma_register.entercustomername, item);
        await page.waitForTimeout(1000);
        await page.locator('li.e-list-item', { hasText: item }).click();
        console.log("Select Inventory Items in Grid");

        await page.waitForTimeout(1000);
        await page.locator('td.e-rowcell.e-lastrowcell.e-updatedtd.e-selectionbackground.e-active[aria-label=" Column Header Item"]').click();
        await page.locator(locators.proforma_register.proforma_qty).click();
        await page.locator(locators.proforma_register.enterquantity).fill(qty);
        

        await page.waitForTimeout(1000);
        //await page.locator('td.e-rowcell.e-lastrowcell.e-updatedtd.e-selectionbackground.e-active[aria-label=" Column Header Item"]').click();
        await page.locator(locators.proforma_register.proforma_updategrid).click();
        await page.locator(locators.proforma_register.updateok).click();
        await page.locator(locators.proforma_register.proforma_submit).click();

        //await page.locator('button[type="button"]:has-text("No")'.nth(1)).click();

        // Use XPath to locate the "Yes" button by text content
        const yesButton = await page.locator(locators.proforma_register.downloadinvoice); // Adjust the index as needed
        await yesButton.click(); // Increase timeout to 60 seconds
        console.log("Clicked on Yes button and verified the invoice.");

        
    
}

async function editproformaSale(page,customer,broker,item,qty) {
    
    await page.locator(locators.verify_sale.profroma_add).click();
    console.log("click on add button so that add proforma sale");

    await page.waitForTimeout(1000);
    await page.locator(locators.proforma_register.customerdropdown).click();
    await page.waitForTimeout(2000);
    await page.fill(locators.proforma_register.entercustomername, customer);
    await page.locator('li.e-list-item', { hasText: customer }).click();


    await page.waitForTimeout(1000);
    await page.locator(locators.proforma_register.brokerdropdown).click();
    //await page.waitForTimeout(2000);
    await page.fill(locators.proforma_register.enterbrokername, broker);
    await page.locator('li.e-list-item', { hasText: broker }).click();

    //await page.locator(locators.proforma_register.gst).click();

    await page.locator(locators.proforma_register.proforma_addgrid).click();

    await page.click(locators.proforma_register.proforma_inventoryGroup);
    await page.click(locators.proforma_register.proforma_selectinventory);
    console.log("Select Inventory Group in Grid");

    await page.locator('td.e-rowcell.e-lastrowcell.e-updatedtd.e-selectionbackground.e-active[aria-label=" Column Header Item"]').click();
    await page.locator(locators.proforma_register.proforma_itemsgrid).click();
    await page.fill(locators.proforma_register.entercustomername, item);
    await page.waitForTimeout(1000);
    await page.locator('li.e-list-item', { hasText: item }).click();
    console.log("Select Inventory Items in Grid");

    await page.waitForTimeout(1000);
    await page.locator('td.e-rowcell.e-lastrowcell.e-updatedtd.e-selectionbackground.e-active[aria-label=" Column Header Item"]').click();
    await page.locator(locators.proforma_register.proforma_qty).click();
    await page.locator(locators.proforma_register.enterquantity).fill(qty);
    

    await page.waitForTimeout(1000);
    //await page.locator('td.e-rowcell.e-lastrowcell.e-updatedtd.e-selectionbackground.e-active[aria-label=" Column Header Item"]').click();
    await page.locator(locators.proforma_register.proforma_updategrid).click();
    await page.locator(locators.proforma_register.updateok).click();
    await page.locator(locators.proforma_register.proforma_reset).click();
    await page.locator(locators.proforma_register.proforma_close).click();


}






module.exports = { selectsubmenu,verifyPerformaSale,verifyPerformaSaleGrid,viewlink,Invoicelink,addproformaSale,editproformaSale };

