const { test, expect } = require('@playwright/test');
const locators = require('./GSTR_1_Report.json');


function formatDate(date) {
    const day = String(date.getDate()).padStart(2, '0');
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const year = date.getFullYear();

    return `${day}-${month}-${year}`;
}

async function CurrentMonthDateFilter(page) {
    let today = new Date();

    // Start date of the current month
    let startDate = new Date(today.getFullYear(), today.getMonth(), 1);

    // End date of the current month
    let endDate = new Date(today.getFullYear(), today.getMonth() + 1, 0);

    // Format the dates as 'dd-MM-yyyy'
    let formattedStartDate = formatDate(startDate);
    let formattedEndDate = formatDate(endDate);

    console.log(`Start Date: ${formattedStartDate}`);
    console.log(`End Date: ${formattedEndDate}`);

    await page.locator(locators.Date).click();
    const datepicker = '#GstrOneReportDatePickerForFilter';
    await page.fill(datepicker, '');
    await page.fill(datepicker, `${formattedStartDate} - ${formattedEndDate}`);
    console.log("Fill Current Month Date");
    await page.waitForTimeout(1000);
    await page.locator(locators.Search).click();
    await page.waitForTimeout(1000);
    console.log("Search after date filter applied.");
}

async function ClosePopup(page) {

    for (let i = 0; i <= 6; i++) {
        if (await page.locator(locators.PopUpClose).nth(i).isVisible()) {
            await page.locator(locators.PopUpClose).nth(i).click();
            console.log("Popup close btn clicked.");
            await page.waitForTimeout(1000);

        }
    }

}

async function EditCustomer(page , State ,GSTNo) {
    //Edit customer 
    await page.locator(locators.Edit_Customer.Master).click();
    await page.locator(locators.Edit_Customer.AccountEntry).click();
    await page.locator(locators.Edit_Customer.Editlink).nth(1).click();
    await page.waitForTimeout(3000);
    await page.locator(locators.Edit_Customer.GSTno).click();  
    await page.waitForTimeout(3000);
    await page.keyboard.press('Backspace');    
    await page.waitForTimeout(3000);
    await page.locator(locators.Edit_Customer.statedropdown).click();
    await page.waitForTimeout(1000);
    await page.fill(locators.Edit_Customer.enterstate, State);
    await page.waitForTimeout(1000);
    await page.locator('li.e-list-item', { hasText: State }).click();
    await page.waitForTimeout(1000);
    console.log("Select state");
    await page.fill(locators.Edit_Customer.GSTno, GSTNo);
    await page.waitForTimeout(2000);
    await page.locator(locators.Edit_Customer.statedropdown).click();
    console.log("GST No fill = ", GSTNo);
    await page.locator(locators.Edit_Customer.Submit).click();
    console.log("Update customer ");
}

//-------------------------------------------------------------------------------------------------------------------------------

// UnRegister Customer with  Gujarat state
async function Sale_B2Csmall_ingujarat(page , State ,GSTNo) {

      //Edit customer : Not Fill GST_No Field and select Gujarat state
      await page.locator(locators.Edit_Customer.Master).click();
      await page.locator(locators.Edit_Customer.AccountEntry).click();
      await page.locator(locators.Edit_Customer.Editlink).nth(1).click();
      await page.waitForTimeout(3000);
      await page.locator(locators.Edit_Customer.GSTno).click();  
      await page.waitForTimeout(3000);
      await page.keyboard.press('Backspace');    
      await page.waitForTimeout(3000);
      await page.locator(locators.Edit_Customer.statedropdown).click();
      await page.waitForTimeout(1000);
      await page.fill(locators.Edit_Customer.enterstate, State);
      await page.waitForTimeout(1000);
      await page.locator('li.e-list-item', { hasText: State }).click();
      await page.waitForTimeout(1000);
      console.log("Select Gujarat state");
      await page.fill(locators.Edit_Customer.GSTno, GSTNo);
      await page.waitForTimeout(2000);
      await page.locator(locators.Edit_Customer.statedropdown).click();
      console.log("GST No fill = ", GSTNo);
      await page.locator(locators.Edit_Customer.Submit).click();
      console.log("Update customer without GSTNo");

    // store values from sales page for verify data into GSTR1 Report : B2C(Small) Details - 7
    await page.locator(locators.Transactionmenu).click();
    await page.locator(locators.Salesmenu).click();
    await page.locator(locators.Salespage).click();

    const GSTBillNoinsale = (await page.locator(locators.GSTBillNo).nth(0).textContent()).trim();
    await page.waitForTimeout(1000);
    console.log('GST BillNo in sale :', GSTBillNoinsale);

    await page.locator(locators.Viewlink).nth(0).click();
    await page.waitForTimeout(1000);

    const CGSTAmtinsale = (await page.locator(locators.CGSTamt).textContent()).trim();
    await page.waitForTimeout(1000);
    console.log('CGST Amount in sale :', CGSTAmtinsale);

    const SGSTAmtinsale = (await page.locator(locators.SGSTamt).textContent()).trim();
    await page.waitForTimeout(1000);
    console.log('SGST Amount in sale :', SGSTAmtinsale);

    const Netamtinsale = (await page.locator(locators.Netamt).textContent()).trim();
    await page.waitForTimeout(1000);
    console.log(' NetAmount in sale :', Netamtinsale);
    console.log("Store CGST , SGST , Netamount from Existing Sale");

    await page.locator(locators.Gstrreportmenu).click();
    await page.locator(locators.Gstr1).click();
    console.log("Click GSTR1 Report");
    await CurrentMonthDateFilter(page);
    await page.locator(locators.B2C_Small_Details_7.B2csmall).nth(2).click();
    console.log("Display B2C(Small) Details - 7 Report page");
    await page.waitForTimeout(1000);
    await page.locator("(//div[@title='Go to last page'])[1]").click();
    await page.waitForTimeout(3000);
    console.log("Go to last page");

    // verify data in grid
    let Bill_No_From_GstrGrid, j, IGST, CGST, SGST, Net_Amount_GstrGrid;
    let billFound = false;

    do {
        for (let i = 1; i <= 12; i++) {
            await page.locator(locators.B2C_Small_Details_7.InvoiceNo).nth(i).click();
            Bill_No_From_GstrGrid = await page.locator(locators.B2C_Small_Details_7.InvoiceNo).nth(i).textContent();
            console.log("Checking row =", i, "And Invoice No =", Bill_No_From_GstrGrid);
            if (Bill_No_From_GstrGrid == GSTBillNoinsale) {
                console.log("Bill No Found with ", Bill_No_From_GstrGrid);
                j = i;
                billFound = true;
                break;
            }
        }
        if (billFound) {

            await page.locator(locators.B2C_Small_Details_7.IGST).nth(j).click();
            await page.waitForTimeout(1000);
            IGST = await page.locator(locators.B2C_Small_Details_7.IGST).nth(j).textContent();
            CGST = await page.locator(locators.B2C_Small_Details_7.CGST).nth(j).textContent();
            SGST = await page.locator(locators.B2C_Small_Details_7.SGST).nth(j).textContent();
            console.log("  IGST, CGST, SGST =", IGST, CGST, SGST);
            Net_Amount_GstrGrid = await page.locator(locators.B2C_Small_Details_7.InvoiceAmount).nth(j).textContent();

            console.log("Net Amount GST Report", Net_Amount_GstrGrid);
        } else {
            console.log("No more pages left, Bill No not found.");
            break;
        }

    } while (!billFound);

    expect(IGST).toBe('0.0');
    expect(CGSTAmtinsale).toBe(CGST);
    expect(SGSTAmtinsale).toBe(SGST);

    //close popup
    await ClosePopup(page);
    console.log("Close B2C(Small) Details - 7 Report page");

}

//-------------------------------------------------------------------------------------------------------------------------------

//Register Customer with Gujarat state
async function Sale_B2BInvoices_ingujarat(page , State , GSTNo) {

     //Edit customer : Fill GST_No Field and select state
     await page.locator(locators.Edit_Customer.Master).click();
     await page.locator(locators.Edit_Customer.AccountEntry).click();
     await page.locator(locators.Edit_Customer.Editlink).nth(1).click();
     await page.waitForTimeout(3000);
     await page.locator(locators.Edit_Customer.GSTno).click();  
     await page.waitForTimeout(3000);
     await page.keyboard.press('Backspace');    
     await page.waitForTimeout(3000);
     await page.locator(locators.Edit_Customer.statedropdown).click();
     await page.waitForTimeout(1000);
     await page.fill(locators.Edit_Customer.enterstate, State);
     await page.waitForTimeout(1000);
     await page.locator('li.e-list-item', { hasText: State }).click();
     await page.waitForTimeout(1000);
     console.log("Select Gujarat state");
     await page.fill(locators.Edit_Customer.GSTno, GSTNo);
     await page.waitForTimeout(2000);
     console.log("GST No fill = ", GSTNo);
     await page.locator(locators.Edit_Customer.Submit).click();
     console.log("Update customer with  GSTNo");

    // store values from sales page for verify data into GSTR1 Report : B2B_Invoice 
    await page.locator(locators.Transactionmenu).click();
    await page.locator(locators.Salesmenu).click();
    await page.locator(locators.Salespage).click();

    const GSTBillNoinsale = (await page.locator(locators.GSTBillNo).nth(0).textContent()).trim();
    await page.waitForTimeout(1000);
    console.log('GST BillNo in sale :', GSTBillNoinsale);

    await page.locator(locators.Viewlink).nth(0).click();
    await page.waitForTimeout(1000);

    const CGSTAmtinsale = (await page.locator(locators.CGSTamt).textContent()).trim();
    await page.waitForTimeout(1000);
    console.log('CGST Amount in sale :', CGSTAmtinsale);

    const SGSTAmtinsale = (await page.locator(locators.SGSTamt).textContent()).trim();
    await page.waitForTimeout(1000);
    console.log('SGST Amount in sale :', SGSTAmtinsale);

    const Netamtinsale = (await page.locator(locators.Netamt).textContent()).trim();
    await page.waitForTimeout(1000);
    console.log(' NetAmount in sale :', Netamtinsale);
    console.log("Store CGST , SGST , Netamount from Existing Sale");

    await page.locator(locators.Gstrreportmenu).click();
    await page.locator(locators.Gstr1).click();
    console.log("Click GSTR1 Report");
    await CurrentMonthDateFilter(page);
    await page.locator(locators.B2B_Invoice.B2binvoice).nth(0).click();
    console.log("Display B2B_Invoice Report page");
    await page.waitForTimeout(1000);
    await page.locator("(//div[@title='Go to last page'])[1]").click();
    await page.waitForTimeout(3000);
    console.log("Go to last page");

    // verify data in grid
    let Bill_No_From_GstrGrid, j, IGST, CGST, SGST, Net_Amount_GstrGrid;
    let billFound = false;

    do {
        for (let i = 1; i <= 12; i++) {
            await page.locator(locators.B2B_Invoice.InvoiceNo).nth(i).click();
            Bill_No_From_GstrGrid = await page.locator(locators.B2B_Invoice.InvoiceNo).nth(i).textContent();
            console.log("Checking row =", i, "And Invoice No =", Bill_No_From_GstrGrid);
            if (Bill_No_From_GstrGrid == GSTBillNoinsale) {
                console.log("Bill No Found with ", Bill_No_From_GstrGrid);
                j = i;
                billFound = true;
                break;
            }
        }
        if (billFound) {

            await page.locator(locators.B2B_Invoice.IGST).nth(j).click();
            await page.waitForTimeout(1000);
            IGST = await page.locator(locators.B2B_Invoice.IGST).nth(j).textContent();
            CGST = await page.locator(locators.B2B_Invoice.CGST).nth(j).textContent();
            SGST = await page.locator(locators.B2B_Invoice.SGST).nth(j).textContent();
            console.log("  IGST, CGST, SGST =", IGST, CGST, SGST);
            Net_Amount_GstrGrid = await page.locator(locators.B2B_Invoice.InvoiceAmount).nth(j).textContent();

            console.log("Net Amount GST Report", Net_Amount_GstrGrid);
        } else {
            console.log("No more pages left, Bill No not found.");
            break;
        }

    } while (!billFound);

    expect(IGST).toBe('0.0');
    expect(CGSTAmtinsale).toBe(CGST);
    expect(SGSTAmtinsale).toBe(SGST);

    //close popup
    await ClosePopup(page);
    console.log("Close B2B_Invoice Report page");

}

//-------------------------------------------------------------------------------------------------------------------------------

//Register Customer with outof Gujarat state
async function Sale_B2BInvoices_outofgujarat(page , State , GSTNo ) {

    //Edit customer : Fill GST_No Field and select state
    await page.locator(locators.Edit_Customer.Master).click();
    await page.locator(locators.Edit_Customer.AccountEntry).click();
    await page.locator(locators.Edit_Customer.Editlink).nth(1).click();
    await page.waitForTimeout(3000);
    await page.locator(locators.Edit_Customer.GSTno).click();  
    await page.waitForTimeout(3000);
    await page.keyboard.press('Backspace');    
    await page.waitForTimeout(3000);
    await page.locator(locators.Edit_Customer.statedropdown).click();
    await page.waitForTimeout(1000);
    await page.fill(locators.Edit_Customer.enterstate, State);
    await page.waitForTimeout(1000);
    await page.locator('li.e-list-item', { hasText: State }).click();
    await page.waitForTimeout(1000);
    console.log("Select Tamilnadu state");
    await page.fill(locators.Edit_Customer.GSTno, GSTNo);
    await page.waitForTimeout(2000);
    console.log("GST No fill = ", GSTNo);
    await page.locator(locators.Edit_Customer.Submit).click();
    console.log("Update customer with  GSTNo");


    // store values from sales page for verify data into GSTR1 Report : B2B_Invoice
    await page.locator(locators.Transactionmenu).click();
    await page.locator(locators.Salesmenu).click();
    await page.locator(locators.Salespage).click();

    const GSTBillNoinsale = (await page.locator(locators.GSTBillNo).nth(0).textContent()).trim();
    await page.waitForTimeout(1000);
    console.log('GST BillNo in sale :', GSTBillNoinsale);

    await page.locator(locators.Viewlink).nth(0).click();
    await page.waitForTimeout(1000);

    const CGSTAmtinsale = (await page.locator(locators.CGSTamt).textContent()).trim();
    await page.waitForTimeout(1000);
    console.log('CGST Amount in sale :', CGSTAmtinsale);

    const SGSTAmtinsale = (await page.locator(locators.SGSTamt).textContent()).trim();
    await page.waitForTimeout(1000);
    console.log('SGST Amount in sale :', SGSTAmtinsale);

    const Netamtinsale = (await page.locator(locators.Netamt).textContent()).trim();
    await page.waitForTimeout(1000);
    console.log(' NetAmount in sale :', Netamtinsale);
    console.log("Store CGST , SGST , Netamount from Existing Sale");

    await page.locator(locators.Gstrreportmenu).click();
    await page.locator(locators.Gstr1).click();
    console.log("Click GSTR1 Report");
    await CurrentMonthDateFilter(page);
    await page.locator(locators.B2B_Invoice.B2binvoice).nth(0).click();
    console.log("Display B2B_Invoice Report page");
    await page.waitForTimeout(1000);
    await page.locator("(//div[@title='Go to last page'])[1]").click();
    await page.waitForTimeout(3000);
    console.log("Go to last page");

    // verify data in grid
    let Bill_No_From_GstrGrid, j, IGST, CGST, SGST, Net_Amount_GstrGrid;
    let billFound = false;

    do {
        for (let i = 1; i <= 12; i++) {
            await page.locator(locators.B2B_Invoice.InvoiceNo).nth(i).click();
            Bill_No_From_GstrGrid = await page.locator(locators.B2B_Invoice.InvoiceNo).nth(i).textContent();
            console.log("Checking row =", i, "And Invoice No =", Bill_No_From_GstrGrid);
            if (Bill_No_From_GstrGrid == GSTBillNoinsale) {
                console.log("Bill No Found with ", Bill_No_From_GstrGrid);
                j = i;
                billFound = true;
                break;
            }
        }
        if (billFound) {

            await page.locator(locators.B2B_Invoice.IGST).nth(j).click();
            await page.waitForTimeout(1000);
            IGST = await page.locator(locators.B2B_Invoice.IGST).nth(j).textContent();
            CGST = await page.locator(locators.B2B_Invoice.CGST).nth(j).textContent();
            SGST = await page.locator(locators.B2B_Invoice.SGST).nth(j).textContent();
            console.log("  IGST, CGST, SGST =", IGST, CGST, SGST);
            Net_Amount_GstrGrid = await page.locator(locators.B2B_Invoice.InvoiceAmount).nth(j).textContent();

            console.log("Net Amount GST Report", Net_Amount_GstrGrid);
        } else {
            console.log("No more pages left, Bill No not found.");
            break;
        }

    } while (!billFound);
 // For Outof Gujarat State : IGST  amount is non Zero
    expect(IGST).toBe(IGST);
    expect(CGST).toBe('0.0');
    expect(SGST).toBe('0.0');

    //close popup
    await ClosePopup(page);
    console.log("Close B2B_Invoice Report page");

}

//-------------------------------------------------------------------------------------------------------------------------------

// UnRegister Customer with  Gujarat state
async function AMC_B2Csmall_ingujarat(page , State ,GSTNo) {

    //Edit customer : Not Fill GST_No Field and select Gujarat state
    await page.locator(locators.Edit_Customer.Master).click();
    await page.locator(locators.Edit_Customer.AccountEntry).click();
    await page.locator(locators.Edit_Customer.Editlink).nth(1).click();
    await page.waitForTimeout(3000);
    await page.locator(locators.Edit_Customer.GSTno).click();  
    await page.waitForTimeout(3000);
    await page.keyboard.press('Backspace');    
    await page.waitForTimeout(3000);
    await page.locator(locators.Edit_Customer.statedropdown).click();
    await page.waitForTimeout(1000);
    await page.fill(locators.Edit_Customer.enterstate, State);
    await page.waitForTimeout(1000);
    await page.locator('li.e-list-item', { hasText: State }).click();
    await page.waitForTimeout(1000);
    console.log("Select Gujarat state");
    await page.fill(locators.Edit_Customer.GSTno, GSTNo);
    await page.waitForTimeout(2000);
    await page.locator(locators.Edit_Customer.statedropdown).click();
    console.log("GST No fill = ", GSTNo);
    await page.locator(locators.Edit_Customer.Submit).click();
    console.log("Update customer without GSTNo");

  // store values from sales page for verify data into GSTR1 Report : B2C(Small) Details - 7
  await page.locator(locators.Transactionmenu).click();
  await page.locator(locators.AMC.Amcpage).click();
 

  const GSTBillNoinAmc = (await page.locator(locators.AMC.GSTBillNo).nth(0).textContent()).trim();
  await page.waitForTimeout(1000);
  console.log('GST BillNo in sale :', GSTBillNoinAmc);

  await page.locator(locators.AMC.Viewlink).nth(0).click();
  await page.waitForTimeout(1000);

  const CGSTAmtinAmc = (await page.locator(locators.AMC.CGSTamt).textContent()).trim();
  await page.waitForTimeout(1000);
  console.log('CGST Amount in sale :', CGSTAmtinAmc);

  const SGSTAmtinAmc = (await page.locator(locators.AMC.SGSTamt).textContent()).trim();
  await page.waitForTimeout(1000);
  console.log('SGST Amount in sale :', SGSTAmtinAmc);

  const NetamtinAmc = (await page.locator(locators.AMC.Netamt).textContent()).trim();
  await page.waitForTimeout(1000);
  console.log(' NetAmount in sale :', NetamtinAmc);
  console.log("Store CGST , SGST , Netamount from Existing Sale");

  await page.locator(locators.Gstrreportmenu).click();
  await page.locator(locators.Gstr1).click();
  console.log("Click GSTR1 Report");
  await CurrentMonthDateFilter(page);
  await page.locator(locators.B2C_Small_Details_7.B2csmall).nth(2).click();
  console.log("Display B2C(Small) Details - 7 Report page");
  await page.waitForTimeout(1000);
  await page.locator("(//div[@title='Go to last page'])[1]").click();
  await page.waitForTimeout(3000);
  console.log("Go to last page");

  // verify data in grid
  let Bill_No_From_GstrGrid, j, IGST, CGST, SGST, Net_Amount_GstrGrid;
  let billFound = false;

  do {
      for (let i = 1; i <= 12; i++) {
          await page.locator(locators.B2C_Small_Details_7.InvoiceNo).nth(i).click();
          Bill_No_From_GstrGrid = await page.locator(locators.B2C_Small_Details_7.InvoiceNo).nth(i).textContent();
          console.log("Checking row =", i, "And Invoice No =", Bill_No_From_GstrGrid);
          if (Bill_No_From_GstrGrid == GSTBillNoinAmc) {
              console.log("Bill No Found with ", Bill_No_From_GstrGrid);
              j = i;
              billFound = true;
              break;
          }
      }
      if (billFound) {

          await page.locator(locators.B2C_Small_Details_7.IGST).nth(j).click();
          await page.waitForTimeout(1000);
          IGST = await page.locator(locators.B2C_Small_Details_7.IGST).nth(j).textContent();
          CGST = await page.locator(locators.B2C_Small_Details_7.CGST).nth(j).textContent();
          SGST = await page.locator(locators.B2C_Small_Details_7.SGST).nth(j).textContent();
          console.log("  IGST, CGST, SGST =", IGST, CGST, SGST);
          Net_Amount_GstrGrid = await page.locator(locators.B2C_Small_Details_7.InvoiceAmount).nth(j).textContent();

          console.log("Net Amount GST Report", Net_Amount_GstrGrid);
      } else {
          console.log("No more pages left, Bill No not found.");
          break;
      }

  } while (!billFound);

  expect(IGST).toBe('0.0');
  expect(CGSTAmtinAmc).toBe(CGST);
  expect(SGSTAmtinAmc).toBe(SGST);

  //close popup
  await ClosePopup(page);
  console.log("Close B2C(Small) Details - 7 Report page");

}

//-------------------------------------------------------------------------------------------------------------------------------

//Register Customer with Gujarat state
async function AMC_B2BInvoices_ingujarat(page , State , GSTNo) {

    //Edit customer : Fill GST_No Field and select state
    await page.locator(locators.Edit_Customer.Master).click();
    await page.locator(locators.Edit_Customer.AccountEntry).click();
    await page.locator(locators.Edit_Customer.Editlink).nth(1).click();
    await page.waitForTimeout(3000);
    await page.locator(locators.Edit_Customer.GSTno).click();  
    await page.waitForTimeout(3000);
    await page.keyboard.press('Backspace');    
    await page.waitForTimeout(3000);
    await page.locator(locators.Edit_Customer.statedropdown).click();
    await page.waitForTimeout(1000);
    await page.fill(locators.Edit_Customer.enterstate, State);
    await page.waitForTimeout(1000);
    await page.locator('li.e-list-item', { hasText: State }).click();
    await page.waitForTimeout(1000);
    console.log("Select Gujarat state");
    await page.fill(locators.Edit_Customer.GSTno, GSTNo);
    await page.waitForTimeout(2000);
    console.log("GST No fill = ", GSTNo);
    await page.locator(locators.Edit_Customer.Submit).click();
    console.log("Update customer with  GSTNo");

   // store values from sales page for verify data into GSTR1 Report : B2B_Invoice 
   await page.locator(locators.Transactionmenu).click();
   await page.locator(locators.AMC.Amcpage).click();

   const GSTBillNoinAmc = (await page.locator(locators.AMC.GSTBillNo).nth(0).textContent()).trim();
   await page.waitForTimeout(1000);
   console.log('GST BillNo in sale :', GSTBillNoinAmc);
 
   await page.locator(locators.AMC.Viewlink).nth(0).click();
   await page.waitForTimeout(1000);
 
   const CGSTAmtinAmc = (await page.locator(locators.AMC.CGSTamt).textContent()).trim();
   await page.waitForTimeout(1000);
   console.log('CGST Amount in sale :', CGSTAmtinAmc);
 
   const SGSTAmtinAmc = (await page.locator(locators.AMC.SGSTamt).textContent()).trim();
   await page.waitForTimeout(1000);
   console.log('SGST Amount in sale :', SGSTAmtinAmc);
 
   const NetamtinAmc = (await page.locator(locators.AMC.Netamt).textContent()).trim();
   await page.waitForTimeout(1000);
   console.log(' NetAmount in sale :', NetamtinAmc);
   console.log("Store CGST , SGST , Netamount from Existing Sale");

   await page.locator(locators.Gstrreportmenu).click();
   await page.locator(locators.Gstr1).click();
   console.log("Click GSTR1 Report");
   await CurrentMonthDateFilter(page);
   await page.locator(locators.B2B_Invoice.B2binvoice).nth(0).click();
   console.log("Display B2B_Invoice Report page");
   await page.waitForTimeout(1000);
   await page.locator("(//div[@title='Go to last page'])[1]").click();
   await page.waitForTimeout(3000);
   console.log("Go to last page");

   // verify data in grid
   let Bill_No_From_GstrGrid, j, IGST, CGST, SGST, Net_Amount_GstrGrid;
   let billFound = false;

   do {
       for (let i = 1; i <= 12; i++) {
           await page.locator(locators.B2B_Invoice.InvoiceNo).nth(i).click();
           Bill_No_From_GstrGrid = await page.locator(locators.B2B_Invoice.InvoiceNo).nth(i).textContent();
           console.log("Checking row =", i, "And Invoice No =", Bill_No_From_GstrGrid);
           if (Bill_No_From_GstrGrid == GSTBillNoinAmc) {
               console.log("Bill No Found with ", Bill_No_From_GstrGrid);
               j = i;
               billFound = true;
               break;
           }
       }
       if (billFound) {

           await page.locator(locators.B2B_Invoice.IGST).nth(j).click();
           await page.waitForTimeout(1000);
           IGST = await page.locator(locators.B2B_Invoice.IGST).nth(j).textContent();
           CGST = await page.locator(locators.B2B_Invoice.CGST).nth(j).textContent();
           SGST = await page.locator(locators.B2B_Invoice.SGST).nth(j).textContent();
           console.log("  IGST, CGST, SGST =", IGST, CGST, SGST);
           Net_Amount_GstrGrid = await page.locator(locators.B2B_Invoice.InvoiceAmount).nth(j).textContent();

           console.log("Net Amount GST Report", Net_Amount_GstrGrid);
       } else {
           console.log("No more pages left, Bill No not found.");
           break;
       }

   } while (!billFound);

   expect(IGST).toBe('0.0');
   expect(CGSTAmtinAmc).toBe(CGST);
   expect(SGSTAmtinAmc).toBe(SGST);

   //close popup
   await ClosePopup(page);
   console.log("Close B2B_Invoice Report page");

}

//-------------------------------------------------------------------------------------------------------------------------------

//Register Customer with outof Gujarat state
async function AMC_B2BInvoices_outofgujarat(page , State , GSTNo ) {

    //Edit customer : Fill GST_No Field and select state
    await page.locator(locators.Edit_Customer.Master).click();
    await page.locator(locators.Edit_Customer.AccountEntry).click();
    await page.locator(locators.Edit_Customer.Editlink).nth(1).click();
    await page.waitForTimeout(3000);
    await page.locator(locators.Edit_Customer.GSTno).click();  
    await page.waitForTimeout(3000);
    await page.keyboard.press('Backspace');    
    await page.waitForTimeout(3000);
    await page.locator(locators.Edit_Customer.statedropdown).click();
    await page.waitForTimeout(1000);
    await page.fill(locators.Edit_Customer.enterstate, State);
    await page.waitForTimeout(1000);
    await page.locator('li.e-list-item', { hasText: State }).click();
    await page.waitForTimeout(1000);
    console.log("Select Tamilnadu state");
    await page.fill(locators.Edit_Customer.GSTno, GSTNo);
    await page.waitForTimeout(2000);
    console.log("GST No fill = ", GSTNo);
    await page.locator(locators.Edit_Customer.Submit).click();
    console.log("Update customer with  GSTNo");


    // store values from sales page for verify data into GSTR1 Report : B2B_Invoice
    await page.locator(locators.Transactionmenu).click();
    await page.locator(locators.AMC.Amcpage).click();
    

    const GSTBillNoinAmc = (await page.locator(locators.AMC.GSTBillNo).nth(0).textContent()).trim();
   await page.waitForTimeout(1000);
   console.log('GST BillNo in sale :', GSTBillNoinAmc);
 
   await page.locator(locators.AMC.Viewlink).nth(0).click();
   await page.waitForTimeout(1000);
 
   const CGSTAmtinAmc = (await page.locator(locators.AMC.CGSTamt).textContent()).trim();
   await page.waitForTimeout(1000);
   console.log('CGST Amount in sale :', CGSTAmtinAmc);
 
   const SGSTAmtinAmc = (await page.locator(locators.AMC.SGSTamt).textContent()).trim();
   await page.waitForTimeout(1000);
   console.log('SGST Amount in sale :', SGSTAmtinAmc);
 
   const NetamtinAmc = (await page.locator(locators.AMC.Netamt).textContent()).trim();
   await page.waitForTimeout(1000);
   console.log(' NetAmount in sale :', NetamtinAmc);
   console.log("Store CGST , SGST , Netamount from Existing Sale");

    await page.locator(locators.Gstrreportmenu).click();
    await page.locator(locators.Gstr1).click();
    console.log("Click GSTR1 Report");
    await CurrentMonthDateFilter(page);
    await page.locator(locators.B2B_Invoice.B2binvoice).nth(0).click();
    console.log("Display B2B_Invoice Report page");
    await page.waitForTimeout(1000);
    await page.locator("(//div[@title='Go to last page'])[1]").click();
    await page.waitForTimeout(3000);
    console.log("Go to last page");

    // verify data in grid
    let Bill_No_From_GstrGrid, j, IGST, CGST, SGST, Net_Amount_GstrGrid;
    let billFound = false;

    do {
        for (let i = 1; i <= 12; i++) {
            await page.locator(locators.B2B_Invoice.InvoiceNo).nth(i).click();
            Bill_No_From_GstrGrid = await page.locator(locators.B2B_Invoice.InvoiceNo).nth(i).textContent();
            console.log("Checking row =", i, "And Invoice No =", Bill_No_From_GstrGrid);
            if (Bill_No_From_GstrGrid == GSTBillNoinAmc) {
                console.log("Bill No Found with ", Bill_No_From_GstrGrid);
                j = i;
                billFound = true;
                break;
            }
        }
        if (billFound) {

            await page.locator(locators.B2B_Invoice.IGST).nth(j).click();
            await page.waitForTimeout(1000);
            IGST = await page.locator(locators.B2B_Invoice.IGST).nth(j).textContent();
            CGST = await page.locator(locators.B2B_Invoice.CGST).nth(j).textContent();
            SGST = await page.locator(locators.B2B_Invoice.SGST).nth(j).textContent();
            console.log("  IGST, CGST, SGST =", IGST, CGST, SGST);
            Net_Amount_GstrGrid = await page.locator(locators.B2B_Invoice.InvoiceAmount).nth(j).textContent();

            console.log("Net Amount GST Report", Net_Amount_GstrGrid);
        } else {
            console.log("No more pages left, Bill No not found.");
            break;
        }

    } while (!billFound);
 // For Outof Gujarat State : IGST  amount is non Zero
    expect(IGST).toBe(IGST);
    expect(CGST).toBe('0.0');
    expect(SGST).toBe('0.0');

    //close popup
    await ClosePopup(page);
    console.log("Close B2B_Invoice Report page");

}

//-------------------------------------------------------------------------------------------------------------------------------

// UnRegister Customer with  Gujarat state
async function SaleReturn_B2Csmall_ingujarat(page , State ,GSTNo) {

    //Edit customer : Not Fill GST_No Field and select Gujarat state
    await page.locator(locators.Edit_Customer.Master).click();
    await page.locator(locators.Edit_Customer.AccountEntry).click();
    await page.locator(locators.Edit_Customer.Editlink).nth(1).click();
    await page.waitForTimeout(3000);
    await page.locator(locators.Edit_Customer.GSTno).click();  
    await page.waitForTimeout(3000);
    await page.keyboard.press('Backspace');    
    await page.waitForTimeout(3000);
    await page.locator(locators.Edit_Customer.statedropdown).click();
    await page.waitForTimeout(1000);
    await page.fill(locators.Edit_Customer.enterstate, State);
    await page.waitForTimeout(1000);
    await page.locator('li.e-list-item', { hasText: State }).click();
    await page.waitForTimeout(1000);
    console.log("Select Gujarat state");
    await page.fill(locators.Edit_Customer.GSTno, GSTNo);
    await page.waitForTimeout(2000);
    await page.locator(locators.Edit_Customer.statedropdown).click();
    console.log("GST No fill = ", GSTNo);
    await page.locator(locators.Edit_Customer.Submit).click();
    console.log("Update customer without GSTNo");

  // store values from sales page for verify data into GSTR1 Report : B2C(Small) Details - 7
  await page.locator(locators.Transactionmenu).click();
  await page.locator(locators.Salesmenu).click();
  await page.locator(locators.SalesReturn.Salesreturnpage).click();

  const GSTBillNoinsalereturn = (await page.locator(locators.SalesReturn.GSTBillNo).nth(0).textContent()).trim();
  await page.waitForTimeout(1000);
  console.log('GST BillNo in sale :', GSTBillNoinsalereturn);

  await page.locator(locators.SalesReturn.Viewlink).nth(0).click();
  await page.waitForTimeout(1000);

  const CGSTAmtinsalereturn = (await page.locator(locators.SalesReturn.CGSTamt).textContent()).trim();
  await page.waitForTimeout(1000);
  console.log('CGST Amount in sale :', CGSTAmtinsalereturn);

  const SGSTAmtinsalereturn = (await page.locator(locators.SalesReturn.SGSTamt).textContent()).trim();
  await page.waitForTimeout(1000);
  console.log('SGST Amount in sale :', SGSTAmtinsalereturn);

  const Netamtinsalereturn = (await page.locator(locators.SalesReturn.Netamt).textContent()).trim();
  await page.waitForTimeout(1000);
  console.log(' NetAmount in sale :', Netamtinsalereturn);
  console.log("Store CGST , SGST , Netamount from Existing Sale");

  await page.locator(locators.Gstrreportmenu).click();
  await page.locator(locators.Gstr1).click();
  console.log("Click GSTR1 Report");
  await CurrentMonthDateFilter(page);
  await page.locator(locators.B2C_Small_Details_7.B2csmall).nth(2).click();
  console.log("Display B2C(Small) Details - 7 Report page");
  await page.waitForTimeout(1000);
  await page.locator("(//div[@title='Go to last page'])[1]").click();
  await page.waitForTimeout(3000);
  console.log("Go to last page");

  // verify data in grid
  let Bill_No_From_GstrGrid, j, IGST, CGST, SGST, Net_Amount_GstrGrid;
  let billFound = false;

  do {
      for (let i = 1; i <= 12; i++) {
          await page.locator(locators.B2C_Small_Details_7.InvoiceNo).nth(i).click();
          Bill_No_From_GstrGrid = await page.locator(locators.B2C_Small_Details_7.InvoiceNo).nth(i).textContent();
          console.log("Checking row =", i, "And Invoice No =", Bill_No_From_GstrGrid);
          if (Bill_No_From_GstrGrid == GSTBillNoinsalereturn) {
              console.log("Bill No Found with ", Bill_No_From_GstrGrid);
              j = i;
              billFound = true;
              break;
          }
      }
      if (billFound) {

          await page.locator(locators.B2C_Small_Details_7.IGST).nth(j).click();
          await page.waitForTimeout(1000);
          IGST = await page.locator(locators.B2C_Small_Details_7.IGST).nth(j).textContent();
          CGST = await page.locator(locators.B2C_Small_Details_7.CGST).nth(j).textContent();
          SGST = await page.locator(locators.B2C_Small_Details_7.SGST).nth(j).textContent();
          console.log("  IGST, CGST, SGST =", IGST, CGST, SGST);
          Net_Amount_GstrGrid = await page.locator(locators.B2C_Small_Details_7.InvoiceAmount).nth(j).textContent();

          console.log("Net Amount GST Report", Net_Amount_GstrGrid);
      } else {
          console.log("No more pages left, Bill No not found.");
          break;
      }

  } while (!billFound);

  expect(IGST).toBe('0.0');
  expect("-" + CGSTAmtinsalereturn).toBe(CGST);
  expect("-" + SGSTAmtinsalereturn).toBe(SGST);

  //close popup
  await ClosePopup(page);
  console.log("Close B2C(Small) Details - 7 Report page");

}

//-------------------------------------------------------------------------------------------------------------------------------

//Register Customer with Gujarat state
async function SaleReturn_CreditDebitNotesRegistered_ingujarat(page) {

   // store values from sales page for verify data into GSTR1 Report : B2B_Invoice 
   await page.locator(locators.Transactionmenu).click();
   await page.locator(locators.Salesmenu).click();
   await page.locator(locators.SalesReturn.Salesreturnpage).click();

   const GSTBillNoinsalereturn = (await page.locator(locators.SalesReturn.GSTBillNo).nth(0).textContent()).trim();
   await page.waitForTimeout(1000);
   console.log('GST BillNo in sale :', GSTBillNoinsalereturn);

   await page.locator(locators.SalesReturn.Viewlink).nth(0).click();
   await page.waitForTimeout(1000);

   const CGSTAmtinsalereturn = (await page.locator(locators.SalesReturn.CGSTamt).textContent()).trim();
   await page.waitForTimeout(1000);
   console.log('CGST Amount in sale :', CGSTAmtinsalereturn);

   const SGSTAmtinsalereturn = (await page.locator(locators.SalesReturn.SGSTamt).textContent()).trim();
   await page.waitForTimeout(1000);
   console.log('SGST Amount in sale :', SGSTAmtinsalereturn);

   const Netamtinsalereturn = (await page.locator(locators.SalesReturn.Netamt).textContent()).trim();
   await page.waitForTimeout(1000);
   console.log(' NetAmount in sale :', Netamtinsalereturn);
   console.log("Store CGST , SGST , Netamount from Existing Sale");

   await page.locator(locators.Gstrreportmenu).click();
   await page.locator(locators.Gstr1).click();
   console.log("Click GSTR1 Report");
   await CurrentMonthDateFilter(page);
   await page.locator(locators.CreditDebit_NotesRegistered_9B.CreditDebit_NotesRegistered_9B).nth(3).click();
   console.log("Display Credit/Debit Notes(Registered) - 9B page");
   await page.waitForTimeout(1000);
   await page.locator("(//div[@title='Go to last page'])[1]").click();
   await page.waitForTimeout(3000);
   console.log("Go to last page");

   // verify data in grid
   let Bill_No_From_GstrGrid, j, IGST, CGST, SGST, Net_Amount_GstrGrid;
   let billFound = false;

   do {
       for (let i = 1; i <= 12; i++) {
           await page.locator(locators.CreditDebit_NotesRegistered_9B.InvoiceNo).nth(i).click();
           Bill_No_From_GstrGrid = await page.locator(locators.CreditDebit_NotesRegistered_9B.InvoiceNo).nth(i).textContent();
           console.log("Checking row =", i, "And Invoice No =", Bill_No_From_GstrGrid);
           if (Bill_No_From_GstrGrid == GSTBillNoinsalereturn) {
               console.log("Bill No Found with ", Bill_No_From_GstrGrid);
               j = i;
               billFound = true;
               break;
           }
       }
       if (billFound) {

           await page.locator(locators.CreditDebit_NotesRegistered_9B.IGST).nth(j).click();
           await page.waitForTimeout(1000);
           IGST = await page.locator(locators.CreditDebit_NotesRegistered_9B.IGST).nth(j).textContent();
           CGST = await page.locator(locators.CreditDebit_NotesRegistered_9B.CGST).nth(j).textContent();
           SGST = await page.locator(locators.CreditDebit_NotesRegistered_9B.SGST).nth(j).textContent();
           console.log("  IGST, CGST, SGST =", IGST, CGST, SGST);
           Net_Amount_GstrGrid = await page.locator(locators.CreditDebit_NotesRegistered_9B.InvoiceAmount).nth(j).textContent();

           console.log("Net Amount GST Report", Net_Amount_GstrGrid);
       } else {
           console.log("No more pages left, Bill No not found.");
           break;
       }

   } while (!billFound);

   expect(IGST).toBe('0.0');
   expect("-" + CGSTAmtinsalereturn).toBe(CGST);
   expect("-"+ SGSTAmtinsalereturn).toBe(SGST);

   //close popup
   await ClosePopup(page);
   console.log("Close B2B_Invoice Report page");

}

//-------------------------------------------------------------------------------------------------------------------------------

//Register Customer with outof Gujarat state
async function SaleReturn_CreditDebitNotesRegistered_outofgujarat(page) {

    // store values from sales page for verify data into GSTR1 Report : B2B_Invoice
    await page.locator(locators.Transactionmenu).click();
    await page.locator(locators.Salesmenu).click();
    await page.locator(locators.Salespage).click();

    const GSTBillNoinsale = (await page.locator(locators.GSTBillNo).nth(0).textContent()).trim();
    await page.waitForTimeout(1000);
    console.log('GST BillNo in sale :', GSTBillNoinsale);

    await page.locator(locators.Viewlink).nth(0).click();
    await page.waitForTimeout(1000);

    const CGSTAmtinsale = (await page.locator(locators.CGSTamt).textContent()).trim();
    await page.waitForTimeout(1000);
    console.log('CGST Amount in sale :', CGSTAmtinsale);

    const SGSTAmtinsale = (await page.locator(locators.SGSTamt).textContent()).trim();
    await page.waitForTimeout(1000);
    console.log('SGST Amount in sale :', SGSTAmtinsale);

    const Netamtinsale = (await page.locator(locators.Netamt).textContent()).trim();
    await page.waitForTimeout(1000);
    console.log(' NetAmount in sale :', Netamtinsale);
    console.log("Store CGST , SGST , Netamount from Existing Sale");

    await page.locator(locators.Gstrreportmenu).click();
    await page.locator(locators.Gstr1).click();
    console.log("Click GSTR1 Report");
    await CurrentMonthDateFilter(page);
    await page.locator(locators.B2B_Invoice.B2binvoice).nth(0).click();
    console.log("Display B2B_Invoice Report page");
    await page.waitForTimeout(1000);
    await page.locator("(//div[@title='Go to last page'])[1]").click();
    await page.waitForTimeout(3000);
    console.log("Go to last page");

    // verify data in grid
    let Bill_No_From_GstrGrid, j, IGST, CGST, SGST, Net_Amount_GstrGrid;
    let billFound = false;

    do {
        for (let i = 1; i <= 12; i++) {
            await page.locator(locators.B2B_Invoice.InvoiceNo).nth(i).click();
            Bill_No_From_GstrGrid = await page.locator(locators.B2B_Invoice.InvoiceNo).nth(i).textContent();
            console.log("Checking row =", i, "And Invoice No =", Bill_No_From_GstrGrid);
            if (Bill_No_From_GstrGrid == GSTBillNoinsale) {
                console.log("Bill No Found with ", Bill_No_From_GstrGrid);
                j = i;
                billFound = true;
                break;
            }
        }
        if (billFound) {

            await page.locator(locators.B2B_Invoice.IGST).nth(j).click();
            await page.waitForTimeout(1000);
            IGST = await page.locator(locators.B2B_Invoice.IGST).nth(j).textContent();
            CGST = await page.locator(locators.B2B_Invoice.CGST).nth(j).textContent();
            SGST = await page.locator(locators.B2B_Invoice.SGST).nth(j).textContent();
            console.log("  IGST, CGST, SGST =", IGST, CGST, SGST);
            Net_Amount_GstrGrid = await page.locator(locators.B2B_Invoice.InvoiceAmount).nth(j).textContent();

            console.log("Net Amount GST Report", Net_Amount_GstrGrid);
        } else {
            console.log("No more pages left, Bill No not found.");
            break;
        }

    } while (!billFound);
 // For Outof Gujarat State : IGST  amount is non Zero
    expect(IGST).toBe(IGST);
    expect(CGST).toBe('0.0');
    expect(SGST).toBe('0.0');

    //close popup
    await ClosePopup(page);
    console.log("Close B2B_Invoice Report page");

}

//-------------------------------------------------------------------------------------------------------------------------------

//Register Customer with Gujarat state
async function DebitNote_CreditDebitNotes_Registered(page , State , GSTNo) {

    //Edit customer :  Fill GST_No Field and select Gujarat state
    await page.locator(locators.Edit_Customer.Master).click();
    await page.locator(locators.Edit_Customer.AccountEntry).click();
    await page.locator(locators.Edit_Customer.Editlink).nth(0).click();
    await page.waitForTimeout(3000);
    await page.locator(locators.Edit_Customer.GSTno).click();  
    await page.waitForTimeout(3000);
    await page.keyboard.press('Backspace');    
    await page.waitForTimeout(3000);
    await page.locator(locators.Edit_Customer.statedropdown).click();
    await page.waitForTimeout(1000);
    await page.fill(locators.Edit_Customer.enterstate, State);
    await page.waitForTimeout(1000);
    await page.locator('li.e-list-item', { hasText: State }).click();
    await page.waitForTimeout(1000);
    console.log("Select Gujarat state");
    await page.fill(locators.Edit_Customer.GSTno, GSTNo);
    await page.waitForTimeout(2000);
    await page.locator(locators.Edit_Customer.statedropdown).click();
    console.log("GST No fill = ", GSTNo);
    await page.locator(locators.Edit_Customer.Submit).click();
    console.log("Update customer without GSTNo");

    // store values from sales page for verify data into GSTR1 Report : B2B_Invoice 
    await page.locator(locators.Transactionmenu).click();
    await page.locator(locators.DebitNote.DebitNotepage).click();
 
    const GSTBillNoindebitnote = (await page.locator(locators.DebitNote.GSTBillNo).nth(0).textContent()).trim();
    await page.waitForTimeout(1000);
    console.log('GST BillNo in sale :', GSTBillNoindebitnote);

    const Netamtindebitnote = (await page.locator(locators.DebitNote.Netamt).nth(0).textContent()).trim();
    await page.waitForTimeout(1000);
    console.log(' NetAmount in sale :', Netamtindebitnote);
    console.log("Store CGST , SGST , Netamount from Existing Sale");
 
    await page.locator(locators.DebitNote.Viewlink).nth(0).click();
    await page.waitForTimeout(1000);

    const CGSTAmtindebitnote = (await page.locator(locators.DebitNote.CGSTamt).textContent()).trim();
    await page.waitForTimeout(1000);
    console.log('CGST Amount in sale :', CGSTAmtindebitnote);
 
    const SGSTAmtindebitnote = (await page.locator(locators.DebitNote.SGSTamt).textContent()).trim();
    await page.waitForTimeout(1000);
    console.log('SGST Amount in sale :', SGSTAmtindebitnote);
 
    await page.locator(locators.Gstrreportmenu).click();
    await page.locator(locators.Gstr1).click();
    console.log("Click GSTR1 Report");
    await CurrentMonthDateFilter(page);
    await page.locator(locators.CreditDebit_NotesRegistered_9B.CreditDebit_NotesRegistered_9B).nth(3).click();
    console.log("Display Credit/Debit Notes(Registered) - 9B page");
    await page.waitForTimeout(1000);
    await page.locator("(//div[@title='Go to last page'])[1]").click();
    await page.waitForTimeout(3000);
    console.log("Go to last page");
 
    // verify data in grid
    let Bill_No_From_GstrGrid, j, IGST, CGST, SGST, Net_Amount_GstrGrid;
    let billFound = false;
 
    do {
        for (let i = 1; i <= 12; i++) {
            await page.locator(locators.CreditDebit_NotesRegistered_9B.InvoiceNo).nth(i).click();
            Bill_No_From_GstrGrid = await page.locator(locators.CreditDebit_NotesRegistered_9B.InvoiceNo).nth(i).textContent();
            console.log("Checking row =", i, "And Invoice No =", Bill_No_From_GstrGrid);
            if (Bill_No_From_GstrGrid == GSTBillNoindebitnote) {
                console.log("Bill No Found with ", Bill_No_From_GstrGrid);
                j = i;
                billFound = true;
                break;
            }
        }
        if (billFound) {
 
            await page.locator(locators.CreditDebit_NotesRegistered_9B.IGST).nth(j).click();
            await page.waitForTimeout(1000);
            IGST = await page.locator(locators.CreditDebit_NotesRegistered_9B.IGST).nth(j).textContent();
            CGST = await page.locator(locators.CreditDebit_NotesRegistered_9B.CGST).nth(j).textContent();
            SGST = await page.locator(locators.CreditDebit_NotesRegistered_9B.SGST).nth(j).textContent();
            console.log("  IGST, CGST, SGST =", IGST, CGST, SGST);
            Net_Amount_GstrGrid = await page.locator(locators.CreditDebit_NotesRegistered_9B.InvoiceAmount).nth(j).textContent();
 
            console.log("Net Amount GST Report", Net_Amount_GstrGrid);
        } else {
            console.log("No more pages left, Bill No not found.");
            break;
        }
 
    } while (!billFound);
 
    expect(IGST).toBe('0.0');
    expect("-" + CGSTAmtindebitnote).toBe(CGST);
    expect("-"+ SGSTAmtindebitnote).toBe(SGST);
 
    //close popup
    await ClosePopup(page);
    console.log("Close B2B_Invoice Report page");
 
 }

 //-------------------------------------------------------------------------------------------------------------------------------

//Register Customer with Gujarat state
async function DebitNote_CreditDebitNotes_UnRegistered(page , State , GSTNo) {

    //Edit customer :  Fill GST_No Field and select Gujarat state
    await page.locator(locators.Edit_Customer.Master).click();
    await page.locator(locators.Edit_Customer.AccountEntry).click();
    await page.locator(locators.Edit_Customer.Editlink).nth(0).click();
    await page.waitForTimeout(3000);
    await page.locator(locators.Edit_Customer.GSTno).click();  
    await page.waitForTimeout(3000);
    await page.keyboard.press('Backspace');    
    await page.waitForTimeout(3000);
    await page.locator(locators.Edit_Customer.statedropdown).click();
    await page.waitForTimeout(1000);
    await page.fill(locators.Edit_Customer.enterstate, State);
    await page.waitForTimeout(1000);
    await page.locator('li.e-list-item', { hasText: State }).click();
    await page.waitForTimeout(1000);
    console.log("Select Gujarat state");
    await page.fill(locators.Edit_Customer.GSTno, GSTNo);
    await page.waitForTimeout(2000);
    await page.locator(locators.Edit_Customer.statedropdown).click();
    console.log("GST No fill = ", GSTNo);
    await page.locator(locators.Edit_Customer.Submit).click();
    console.log("Update customer without GSTNo");

    // store values from sales page for verify data into GSTR1 Report : B2B_Invoice 
    await page.locator(locators.Transactionmenu).click();
    await page.locator(locators.DebitNote.DebitNotepage).click();
 
    const GSTBillNoindebitnote = (await page.locator(locators.DebitNote.GSTBillNo).nth(0).textContent()).trim();
    await page.waitForTimeout(1000);
    console.log('GST BillNo in sale :', GSTBillNoindebitnote);

    const Netamtindebitnote = (await page.locator(locators.DebitNote.Netamt).nth(0).textContent()).trim();
    await page.waitForTimeout(1000);
    console.log(' NetAmount in sale :', Netamtindebitnote);
    console.log("Store CGST , SGST , Netamount from Existing Sale");
 
    await page.locator(locators.DebitNote.Viewlink).nth(0).click();
    await page.waitForTimeout(1000);

    const CGSTAmtindebitnote = (await page.locator(locators.DebitNote.CGSTamt).textContent()).trim();
    await page.waitForTimeout(1000);
    console.log('CGST Amount in sale :', CGSTAmtindebitnote);
 
    const SGSTAmtindebitnote = (await page.locator(locators.DebitNote.SGSTamt).textContent()).trim();
    await page.waitForTimeout(1000);
    console.log('SGST Amount in sale :', SGSTAmtindebitnote);
 
    await page.locator(locators.Gstrreportmenu).click();
    await page.locator(locators.Gstr1).click();
    await page.locator(locators.Reset).click();
    await page.locator(locators.PDFExport).click();
    await page.locator(locators.JsonExport).click();
    console.log("Click GSTR1 Report");
    await CurrentMonthDateFilter(page);
    await page.locator(locators.CreditDebit_NotesUnRegistered_9B.CreditDebit_NotesUnRegistered_9B).nth(4).click();
    console.log("Display Credit/Debit Notes(Registered) - 9B page");
    await page.waitForTimeout(1000);
    await page.locator("(//div[@title='Go to last page'])[1]").click();
    await page.waitForTimeout(3000);
    console.log("Go to last page");
 
    // verify data in grid
    let Bill_No_From_GstrGrid, j, IGST, CGST, SGST, Net_Amount_GstrGrid;
    let billFound = false;
 
    do {
        for (let i = 1; i <= 12; i++) {
            await page.locator(locators.CreditDebit_NotesUnRegistered_9B.InvoiceNo).nth(i).click();
            Bill_No_From_GstrGrid = await page.locator(locators.CreditDebit_NotesUnRegistered_9B.InvoiceNo).nth(i).textContent();
            console.log("Checking row =", i, "And Invoice No =", Bill_No_From_GstrGrid);
            if (Bill_No_From_GstrGrid == GSTBillNoindebitnote) {
                console.log("Bill No Found with ", Bill_No_From_GstrGrid);
                j = i;
                billFound = true;
                break;
            }
        }
        if (billFound) {
 
            await page.locator(locators.CreditDebit_NotesUnRegistered_9B.IGST).nth(j).click();
            await page.waitForTimeout(1000);
            IGST = await page.locator(locators.CreditDebit_NotesUnRegistered_9B.IGST).nth(j).textContent();
            CGST = await page.locator(locators.CreditDebit_NotesUnRegistered_9B.CGST).nth(j).textContent();
            SGST = await page.locator(locators.CreditDebit_NotesUnRegistered_9B.SGST).nth(j).textContent();
            console.log("  IGST, CGST, SGST =", IGST, CGST, SGST);
            Net_Amount_GstrGrid = await page.locator(locators.CreditDebit_NotesUnRegistered_9B.InvoiceAmount).nth(j).textContent();
 
            console.log("Net Amount GST Report", Net_Amount_GstrGrid);
        } else {
            console.log("No more pages left, Bill No not found.");
            break;
        }
 
    } while (!billFound);
 
    expect(IGST).toBe('0.0');
    expect("-" + CGSTAmtindebitnote).toBe(CGST);
    expect("-"+ SGSTAmtindebitnote).toBe(SGST);
 
    //close popup
    await ClosePopup(page);
    console.log("Close B2B_Invoice Report page");
 
 }

 //------------------------------------------------------------------------------------------------------------------------------
 //Add sale with Lessthan 2,50,000 Amount
 async function addInvdetailsinsale(page, inventorygroup, item, qty , rate) {
    // Sales Detail 
    await page.locator(locators.addinventoryonsalesdetails).click();
    await page.waitForTimeout(500);
    await page.locator(locators.selectinventorygroup).click(); //Click on Inventory Group
    if (inventorygroup == "FinishMaterial") {
        await page.click(locators.selectfinishmaterial);
    }
    else if (inventorygroup == "RawMaterial") {
        await page.click(locators.selectrawmaterial);
    }
    await page.locator('td.e-rowcell.e-lastrowcell.e-updatedtd.e-selectionbackground.e-active[aria-label=" Column Header Item"]').click();
    await page.locator(locators.inventoryitem).click();
    await page.locator('li.e-list-item', { hasText: item }).nth(0).click();
    await page.locator(locators.clickquantity).click();
    await page.locator(locators.enterquantity).fill(qty);
    await page.locator(locators.clickrate).dblclick();
    await page.locator(locators.enterrate).fill(rate);
} 

async function EwayPopupOkbtn(page) {
    await page.locator(locators.ewayokbtn).click();
}

async function InvoiceDownload(page) {
    await page.locator(locators.invoicedownload).click();
}

//-------------------------------------------------------------------------------------------------------------------------------

 async function Sale_Lessthan_250000(page , State , GSTNo) {

    // UnRegister Customer with Outof Gujarat state
    //Edit customer : Not Fill GST_No Field and select Outof Gujarat state
    await page.locator(locators.Edit_Customer.Master).click();
    await page.locator(locators.Edit_Customer.AccountEntry).click();
    await page.locator(locators.Edit_Customer.Editlink).nth(1).click();
    await page.waitForTimeout(3000);
    await page.locator(locators.Edit_Customer.GSTno).click();  
    await page.waitForTimeout(3000);
    await page.keyboard.press('Backspace');    
    await page.waitForTimeout(3000);
    await page.locator(locators.Edit_Customer.statedropdown).click();
    await page.waitForTimeout(1000);
    await page.fill(locators.Edit_Customer.enterstate, State);
    await page.waitForTimeout(1000);
    await page.locator('li.e-list-item', { hasText: State }).click();
    await page.waitForTimeout(1000);
    console.log("Select Gujarat state");
    await page.fill(locators.Edit_Customer.GSTno, GSTNo);
    await page.waitForTimeout(2000);
    await page.locator(locators.Edit_Customer.statedropdown).click();
    console.log("GST No fill = ", GSTNo);
    await page.locator(locators.Edit_Customer.Submit).click();
    console.log("Update customer without GSTNo");

  // store values from sales page for verify data into GSTR1 Report : B2C(Small) Details - 7
  await page.locator(locators.Transactionmenu).click();
  await page.locator(locators.Salesmenu).click();
  await page.locator(locators.Salespage).click();

  const GSTBillNoinsale = (await page.locator(locators.GSTBillNo).nth(0).textContent()).trim();
  await page.waitForTimeout(1000);
  console.log('GST BillNo in sale :', GSTBillNoinsale);

  await page.locator(locators.Viewlink).nth(0).click();
  await page.waitForTimeout(1000);

  const CGSTAmtinsale = (await page.locator(locators.CGSTamt).textContent()).trim();
  await page.waitForTimeout(1000);
  console.log('CGST Amount in sale :', CGSTAmtinsale);

  const SGSTAmtinsale = (await page.locator(locators.SGSTamt).textContent()).trim();
  await page.waitForTimeout(1000);
  console.log('SGST Amount in sale :', SGSTAmtinsale);

  const Netamtinsale = (await page.locator(locators.Netamt).textContent()).trim();
  await page.waitForTimeout(1000);
  console.log(' NetAmount in sale :', Netamtinsale);
  console.log("Store CGST , SGST , Netamount from Existing Sale");

  await page.locator(locators.Gstrreportmenu).click();
  await page.locator(locators.Gstr1).click();
  console.log("Click GSTR1 Report");
  await CurrentMonthDateFilter(page);
  await page.locator(locators.B2C_Small_Details_7.B2csmall).nth(2).click();
  console.log("Display B2C(Small) Details - 7 Report page");
  await page.waitForTimeout(1000);
  await page.locator("(//div[@title='Go to last page'])[1]").click();
  await page.waitForTimeout(3000);
  console.log("Go to last page");

  // verify data in grid
  let Bill_No_From_GstrGrid, j, IGST, CGST, SGST, Net_Amount_GstrGrid;
  let billFound = false;

  do {
      for (let i = 1; i <= 12; i++) {
          await page.locator(locators.B2C_Small_Details_7.InvoiceNo).nth(i).click();
          Bill_No_From_GstrGrid = await page.locator(locators.B2C_Small_Details_7.InvoiceNo).nth(i).textContent();
          console.log("Checking row =", i, "And Invoice No =", Bill_No_From_GstrGrid);
          if (Bill_No_From_GstrGrid == GSTBillNoinsale) {
              console.log("Bill No Found with ", Bill_No_From_GstrGrid);
              j = i;
              billFound = true;
              break;
          }
      }
      if (billFound) {

          await page.locator(locators.B2C_Small_Details_7.IGST).nth(j).click();
          await page.waitForTimeout(1000);
          IGST = await page.locator(locators.B2C_Small_Details_7.IGST).nth(j).textContent();
          CGST = await page.locator(locators.B2C_Small_Details_7.CGST).nth(j).textContent();
          SGST = await page.locator(locators.B2C_Small_Details_7.SGST).nth(j).textContent();
          console.log("  IGST, CGST, SGST =", IGST, CGST, SGST);
          Net_Amount_GstrGrid = await page.locator(locators.B2C_Small_Details_7.InvoiceAmount).nth(j).textContent();

          console.log("Net Amount GST Report", Net_Amount_GstrGrid);
      } else {
          console.log("No more pages left, Bill No not found.");
          break;
      }

  } while (!billFound);

  expect(IGST).toBe(IGST);
  expect(CGST).toBe('0.0');
  expect(SGST).toBe('0.0');

  //close popup
  await ClosePopup(page);
  console.log("Close B2C(Small) Details - 7 Report page");
 }

 //------------------------------------------------------------------------------------------------------------------------------

 async function Sale_Greaterthan_250000(page , State , GSTNo) {

    // UnRegister Customer with Outof Gujarat state
    //Edit customer : Not Fill GST_No Field and select Outof Gujarat state
    await page.locator(locators.Edit_Customer.Master).click();
    await page.locator(locators.Edit_Customer.AccountEntry).click();
    await page.locator(locators.Edit_Customer.Editlink).nth(1).click();
    await page.waitForTimeout(3000);
    await page.locator(locators.Edit_Customer.GSTno).click();  
    await page.waitForTimeout(3000);
    await page.keyboard.press('Backspace');    
    await page.waitForTimeout(3000);
    await page.locator(locators.Edit_Customer.statedropdown).click();
    await page.waitForTimeout(1000);
    await page.fill(locators.Edit_Customer.enterstate, State);
    await page.waitForTimeout(1000);
    await page.locator('li.e-list-item', { hasText: State }).click();
    await page.waitForTimeout(1000);
    console.log("Select Gujarat state");
    await page.fill(locators.Edit_Customer.GSTno, GSTNo);
    await page.waitForTimeout(2000);
    await page.locator(locators.Edit_Customer.statedropdown).click();
    console.log("GST No fill = ", GSTNo);
    await page.locator(locators.Edit_Customer.Submit).click();
    console.log("Update customer without GSTNo");

  // store values from sales page for verify data into GSTR1 Report : B2C(Small) Details - 7
  await page.locator(locators.Transactionmenu).click();
  await page.locator(locators.Salesmenu).click();
  await page.locator(locators.Salespage).click();

  const GSTBillNoinsale = (await page.locator(locators.GSTBillNo).nth(0).textContent()).trim();
  await page.waitForTimeout(1000);
  console.log('GST BillNo in sale :', GSTBillNoinsale);

  await page.locator(locators.Viewlink).nth(0).click();
  await page.waitForTimeout(1000);

  const CGSTAmtinsale = (await page.locator(locators.CGSTamt).textContent()).trim();
  await page.waitForTimeout(1000);
  console.log('CGST Amount in sale :', CGSTAmtinsale);

  const SGSTAmtinsale = (await page.locator(locators.SGSTamt).textContent()).trim();
  await page.waitForTimeout(1000);
  console.log('SGST Amount in sale :', SGSTAmtinsale);

  const Netamtinsale = (await page.locator(locators.Netamt).textContent()).trim();
  await page.waitForTimeout(1000);
  console.log(' NetAmount in sale :', Netamtinsale);
  console.log("Store CGST , SGST , Netamount from Existing Sale");

  await page.locator(locators.Gstrreportmenu).click();
  await page.locator(locators.Gstr1).click();
  console.log("Click GSTR1 Report");
  await CurrentMonthDateFilter(page);
  await page.locator(locators.B2C_Large_Invoices.B2clarge).nth(1).click();
  console.log("Display B2C(Small) Details - 7 Report page");
  await page.waitForTimeout(1000);
  await page.locator("(//div[@title='Go to last page'])[1]").click();
  await page.waitForTimeout(3000);
  console.log("Go to last page");

  // verify data in grid
  let Bill_No_From_GstrGrid, j, IGST, CGST, SGST, Net_Amount_GstrGrid;
  let billFound = false;

  do {
      for (let i = 1; i <= 12; i++) {
          await page.locator(locators.B2C_Large_Invoices.InvoiceNo).nth(i).click();
          Bill_No_From_GstrGrid = await page.locator(locators.B2C_Large_Invoices.InvoiceNo).nth(i).textContent();
          console.log("Checking row =", i, "And Invoice No =", Bill_No_From_GstrGrid);
          if (Bill_No_From_GstrGrid == GSTBillNoinsale) {
              console.log("Bill No Found with ", Bill_No_From_GstrGrid);
              j = i;
              billFound = true;
              break;
          }
      }
      if (billFound) {

          await page.locator(locators.B2C_Large_Invoices.IGST).nth(j).click();
          await page.waitForTimeout(1000);
          IGST = await page.locator(locators.B2C_Large_Invoices.IGST).nth(j).textContent();
          CGST = await page.locator(locators.B2C_Large_Invoices.CGST).nth(j).textContent();
          SGST = await page.locator(locators.B2C_Large_Invoices.SGST).nth(j).textContent();
          console.log("  IGST, CGST, SGST =", IGST, CGST, SGST);
          Net_Amount_GstrGrid = await page.locator(locators.B2C_Large_Invoices.InvoiceAmount).nth(j).textContent();

          console.log("Net Amount GST Report", Net_Amount_GstrGrid);
      } else {
          console.log("No more pages left, Bill No not found.");
          break;
      }

  } while (!billFound);

  expect(IGST).toBe(IGST);
  expect(CGST).toBe('0.0');
  expect(SGST).toBe('0.0');

  //close popup
  await ClosePopup(page);
  console.log("Close B2C(Small) Details - 7 Report page");
 }



module.exports = {EditCustomer, Sale_B2Csmall_ingujarat, Sale_B2BInvoices_ingujarat , Sale_B2BInvoices_outofgujarat,
                   AMC_B2Csmall_ingujarat , AMC_B2BInvoices_ingujarat  , AMC_B2BInvoices_outofgujarat ,
                   SaleReturn_B2Csmall_ingujarat , SaleReturn_CreditDebitNotesRegistered_ingujarat , SaleReturn_CreditDebitNotesRegistered_outofgujarat,
                   DebitNote_CreditDebitNotes_Registered , DebitNote_CreditDebitNotes_UnRegistered , 
                   addInvdetailsinsale , EwayPopupOkbtn, InvoiceDownload ,Sale_Lessthan_250000 , Sale_Greaterthan_250000

 };