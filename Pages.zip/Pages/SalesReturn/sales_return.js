const { test, expect } = require('@playwright/test');
const locators = require('./sales_return.json');
const { TIMEOUT } = require('dns');
const fs = require('fs');


async function selectsubmenu(page,menu) {
    if (menu=="Transaction") 
        {
            await page.locator(locators.sales_return_menu.sales_menu).click();
            await page.locator(locators.sales_return_menu.sales_return).click();
            await expect(page.locator('li.breadcrumb-item.active', { hasText: 'Sales Return' })).toBeVisible();
  
                                  
        }
        
        else if (menu == "Reports") {
            await page.locator(locators.reportsmenu.sales_menu).click();
            await page.locator(locators.reportsmenu.reportitemwise).click();
            await expect(page.locator('li.breadcrumb-item.active', { hasText: 'Item Wise' })).toBeVisible();
    
        }
}


async function selectcustomer(page, customer) {

    // await page.locator(locators.verify_sales_returnpage.sales_date).click();
    // const datepicker = '#ProductSalesReturnsDateLab'; //code to clear the date
    // await page.fill(datepicker, ''); //code to clear the date
    // await page.fill(datepicker, '17-12-2024 - 17-12-2024'); //code to enter current data
    // //await page.locator(locators.verify_sales_returnpage.sales_search).click();

    await page.waitForTimeout(1000);
    await page.locator(locators.verify_sales_returnpage.customerdropdown).click();
    await page.waitForTimeout(2000);
    await page.fill(locators.verify_sales_returnpage.entercustomername, customer);
    await page.locator('td.customerdropdown1', { hasText: customer }).click();
    await page.waitForTimeout(3000);
    await page.locator(locators.verify_sales_returnpage.sales_search).click();
    
    await page.waitForTimeout(1000);
    await page.locator(locators.verify_sales_returnpage.sales_pdf).click();

    await page.waitForTimeout(3000);
    await page.locator(locators.verify_sales_returnpage.sales_reset).click();

    await page.waitForTimeout(1000);
    //await page.click('a[href="/Invoice"].nav-item.nav-link.text-white');
    


}

async function viewlink(page) {
 
    await page.evaluate(() => { window.scrollTo(0, document.body.scrollHeight);});
       /*****************Verify Customer Name is Correct ************************/
       //const Verifycustomer = JSON.parse(fs.readFileSync('customer.json')); //Read the shared Net Amount from the JSON file
       //const sharedcustomer = Verifycustomer.customername;
       const rows = await page.locator('tr[aria-rowindex]'); // Select all rows with aria-rowindex
       const firstRow = await rows.nth(0); // Select the first row
       const valueone = await firstRow.locator("td#ProductSalesReturnsCustomerNameColumn"); //Extract the Net Amount from the latest row
        const customernamecolumn = await valueone.innerText();
        //expect(sharedcustomer).toBe(customernamecolumn);
       console.log(" Customer Name before Submit is same as Customer Name on the grid")
         /*********Scroll Right******************/
       await page.waitForTimeout(3000);
       const divElement = await page.$('div.e-content.e-yscroll.e-lib.e-droppable'); // Replace with your actual selector
       await page.evaluate((el) => {
            el.scrollLeft += 600; // Adjust this value to scroll further or slower
           }, divElement);
   
        //Locate and click the "view" Button
        const viewButton = await firstRow.locator('a[title="View Sales Return detail"]'); //Adjust this with the actual selector for the "View"
   
        // Check if the "View" button is visible
        const isVisible = await viewButton.isVisible();
        if (isVisible) {
            console.log('View button is visible. Proceeding with click.');
            await viewButton.click();
            console.log(' Clicked on "View" button.');
        } else {
            console.log('View button is not found or not visible.');
        }
        await page.waitForTimeout(1000);
        await page.evaluate(() => { window.scrollTo(0, document.body.scrollHeight, { timeout: 30000 }); });
        //await page.waitForTimeout(3000);
        await page.locator(locators.verify_sales_returnpage.sales_close).click();
        //await page.waitForTimeout(5000);

}

async function addSaleReturn(page,customer) {

    await page.locator(locators.sales_return_menu.transaction).click();
    await page.locator(locators.sales_return_menu.sales_menu).click();
    await page.locator(locators.sales_return_menu.sale_submenu).click();

//     // Fetch the latest ticket number from the ticket no column
  const latestSaleNo = await page.locator("//td[@id='SalesGSTBillNoColumn']").nth(0).textContent();
 
  if (!latestSaleNo || latestSaleNo.trim() === "") {
      console.log('No latest Sale number found. Exiting...');
     
      return;
  }
 
  console.log(`Latest Sale No: ${latestSaleNo.trim()}`);

  await page.locator(locators.sales_return_menu.transaction).click();
    await page.locator(locators.sales_return_menu.sales_menu).click();
    await page.locator(locators.sales_return_menu.sales_return).click();

        await page.locator(locators.verify_sales_returnpage.sales_addnew).click();
        console.log(" click on add button so that add sale return");

        const date = await page.isVisible(locators.addsales_return.saledate);
        console.log(`date: ${date}`);
        const customername = await page.isVisible(locators.verify_sales_returnpage.customerdropdown);
        console.log(`Customer Name: ${customername}`);
        const payment_type = await page.isVisible(locators.addsales_return.payment_type);
        console.log(`payment type: ${payment_type}`);
        const Invoice_type = await page.isVisible(locators.addsales_return.Invoice_type);
        console.log(`Invoice Type : ${Invoice_type}`);
        const broker_name = await page.isVisible(locators.addsales_return.brokerdropdown);
        console.log(`Broker Name : ${broker_name}`);
        const gstin = await page.isVisible(locators.addsales_return.gstin);
        console.log(`GST IN : ${gstin}`);
        const mobileno = await page.isVisible(locators.addsales_return.mobile_no);
        console.log(`Mobile : ${mobileno}`);
        const tax_method = await page.isVisible(locators.addsales_return.taxmethod);
        console.log(`Tax Method : ${tax_method}`);
        const posno = await page.isVisible(locators.addsales_return.pos);
        console.log(`POS NO : ${posno}`);
        const deilveryadd = await page.isVisible(locators.addsales_return.deivlery_add);
        console.log(`Delivery Address : ${deilveryadd}`);
        
        console.log(' Verify add Proforma Sales Register Page');

        await page.waitForTimeout(1000);
        await page.locator(locators.verify_sales_returnpage.customerdropdown).click();
        await page.waitForTimeout(2000);
        await page.fill(locators.verify_sales_returnpage.entercustomername, customer);
        await page.locator('li.e-list-item', { hasText: customer }).click();

        await page.waitForTimeout(1000);
        await page.locator(locators.addsales_return.sale_returnbill).click();
        await page.waitForTimeout(2000);
        await page.fill(locators.addsales_return.entersale_returnbill, latestSaleNo);
        await page.locator('li.e-list-item', { hasText: latestSaleNo }).click();

        await page.locator(locators.addsales_return.salerturn_updategrid).click();
        await page.waitForTimeout(1000);

        await page.locator(locators.addsales_return.OK_Update_Popup).click();
        await page.waitForTimeout(1000);

        await page.locator(locators.addsales_return.salereturn_submit).click();
        console.log(' Submited Successfully');

        //Click On yes...
        //await page.waitForTimeout(1000);
        await page.locator(locators.addsales_return.yesInvoice).click();
        console.log(' Sales Record added Successfully');


}

async function ResetSaleReturn(page,customer) {

    await page.locator(locators.sales_return_menu.transaction).click();
    await page.locator(locators.sales_return_menu.sales_menu).click();
    await page.locator(locators.sales_return_menu.sale_submenu).click();

//     // Fetch the latest ticket number from the ticket no column
  const latestSaleNo = await page.locator("//td[@id='SalesGSTBillNoColumn']").nth(0).textContent();
 
  if (!latestSaleNo || latestSaleNo.trim() === "") {
      console.log('No latest Sale number found. Exiting...');
     
      return;
  }
 
  console.log(`Latest Sale No: ${latestSaleNo.trim()}`);

  await page.locator(locators.sales_return_menu.transaction).click();
    await page.locator(locators.sales_return_menu.sales_menu).click();
    await page.locator(locators.sales_return_menu.sales_return).click();


        await page.locator(locators.verify_sales_returnpage.sales_addnew).click();
        console.log(" click on add button so that add sale return");

        await page.waitForTimeout(1000);
        await page.locator(locators.verify_sales_returnpage.customerdropdown).click();
        await page.waitForTimeout(2000);
        await page.fill(locators.verify_sales_returnpage.entercustomername, customer);
        await page.locator('li.e-list-item', { hasText: customer }).click();

        await page.waitForTimeout(1000);
        await page.locator(locators.addsales_return.sale_returnbill).click();
        await page.waitForTimeout(2000);
        await page.fill(locators.addsales_return.entersale_returnbill, latestSaleNo);
        await page.locator('li.e-list-item', { hasText: latestSaleNo }).click();

        await page.locator(locators.addsales_return.salesreturn_reset).click();
        await page.waitForTimeout(1000);
        await page.locator(locators.addsales_return.salereturn_close).click();
}

async function selectfilteritemwise(page, customername) {

    await page.locator(locators.Itemwise_Filter).click();
    await page.locator(locators.customerdropdown).click();
    await page.fill(locators.entercustomername, customername);
    await page.waitForTimeout(1000);
 
    const itemLocator = page.locator(`//td[@title='${customername}']`);
    //await expect(itemLocator).toBeVisible();
    await itemLocator.click();
    // const datepicker = '#ItemWiseSalesReportDateRangePickerForFilter'; //code to clear the date
    // await page.fill(datepicker, ''); //code to clear the date
    // await page.fill(datepicker, date); //code to enter current data
    await page.locator(locators.searchbutton_Itemwise).click();
    await page.waitForTimeout(1000);


}

async function selectfiltersalesummary(page, customername) {

    await page.locator(locators.reportsmenu.reports).click();
    await page.locator(locators.reportsmenu.sales_menu).click();
    await page.locator(locators.reportsmenu.summaryvise).click();


    await page.locator(locators.fillterbuttonsummary).click();
    await page.locator(locators.customerfiltersummary).click();
    await page.fill(locators.entercustomername, customername);
    await page.waitForTimeout(1000);
  
    const itemLocator = page.locator(`//td[@title='${customername}']`);
    //await expect(itemLocator).toBeVisible();
    await itemLocator.click();
    // const datepicker = '#SalesSummaryReportDateRangePickerForFilter'; //code to clear the date
    // await page.fill(datepicker, ''); //code to clear the date
    // await page.fill(datepicker, date); //code to enter current data
    await page.locator(locators.searchbuttonsummary).click();

}

async function verifydetailssalesummary(page) {
    /*****************Verify Customer Name is Correct ************************/
    const button = await page.locator('span.e-ungroupbutton[title="Ungroup by this column"]');
    await button.click();  // To perform a click action on the element
    //const Verifycustomer = JSON.parse(fs.readFileSync('customer.json')); //Read the shared Net Amount from the JSON file
    //const sharedcustomername = Verifycustomer.customername;
    const rows = await page.locator('tr[aria-rowindex]'); // Select all rows with aria-rowindex
    const firstRow = await rows.nth(0); // Select the first row
    await page.waitForTimeout(1000);
    //const valuethree = await firstRow.locator("td#SalesSummaryReportCustomerNameColumn");
    //const customernamecolumn = await valuethree.innerText();
    //expect(sharedcustomername).toBe(customernamecolumn);
    console.log(" Customer Name before Submit is same as Customer Name on the Sales summary Report")

    //Locate and click the "view" Button
    const viewButton = await firstRow.locator('a#SalesSummaryReportViewRegularBillNumberDetails'); //Adjust this with the actual selector for the "View" 

    // Check if the "View" button is visible
    const isVisible = await viewButton.isVisible();
    if (isVisible) {
        console.log('View button is visible. Proceeding with click.');
        await viewButton.click();
        console.log(' Clicked on "View" button.');
    } else {
        console.log('View button is not found or not visible.');
    }
    await page.waitForTimeout(3000);
    console.log("successfully click on view link")
    
}

async function selectfiltercombinesale(page, customername) {

    await page.locator(locators.reportsmenu.reports).click();
    await page.locator(locators.reportsmenu.sales_menu).click();
    await page.locator(locators.reportsmenu.Combinesales).click();


    await page.locator(locators.fillterbuttoncombine).click();
    await page.locator(locators.customerdropdown).click();
    await page.fill(locators.entercustomername, customername);
    await page.waitForTimeout(1000);

    const itemLocator = page.locator(`//td[@title='${customername}']`);
    //await expect(itemLocator).toBeVisible();
    await itemLocator.click();
    // const datepicker = '#CombinedSalesReportDateRangePickerForFilter'; //code to clear the date
    // await page.fill(datepicker, ''); //code to clear the date
    // await page.fill(datepicker, date); //code to enter current data
    await page.locator(locators.searchbuttoncombine).click();
    await page.waitForTimeout(1000);


}

async function selectfilterOutstanding(page, customername) {

    await page.locator(locators.reportsmenu.reports).click();
    await page.locator(locators.reportsmenu.outstanding).click();

    await page.locator(locators.outstandingfilter).click();
    await page.locator(locators.customerdropdown).click();
    await page.fill(locators.entercustomername, customername);
    await page.waitForTimeout(1000);

    const itemLocator = page.locator(`//td[@title='${customername}']`);
    //await expect(itemLocator).toBeVisible();
    await itemLocator.click();
    // const datepicker = '#OutstandingReportDateRangePickerForFilter'; //code to clear the date
    // await page.fill(datepicker, ''); //code to clear the date
    // await page.fill(datepicker, date); //code to enter current data
    await page.locator(locators.outstandingserach).click();
    await page.waitForTimeout(1000);

}
async function selectfilterInventorystock(page, inventoryName) {
    await page.locator(locators.reportsmenu.reports).click();
    await page.locator(locators.reportsmenu.inventoryStock).click();

    await page.click('#InventoryReportopenSideBarButton');
    console.log("Clicked on the Filter button.");
    await page.click(locators.selectinventorygroup);
    await page.click("//li[normalize-space()='RawMaterial']");
    console.log("Selected inventory group.");
    await page.locator(locators.inventoryselect).click();
    await page.waitForTimeout(1000);
    await page.fill(locators.enterInventory, inventoryName);
   await page.waitForTimeout(1000);
   await page.locator('li.e-list-item', { hasText: inventoryName }).click();

    await page.waitForTimeout(1000);

    await page.locator(locators.inventorysearchbutton).click();
    await page.waitForTimeout(1000);

}

async function viewlink1(page) {
    const viewButton = await page.locator('a#InventoryReportViewDetailedinventoryReportButton'); //Adjust this with the actual selector for the "View"

    // Check if the "View" button is visible
    const isVisible = await viewButton.isVisible();
    if (isVisible) {
        console.log('View button is visible. Proceeding with click.');
        await viewButton.click();
        console.log(' Clicked on "View" button.');
    } else {
        console.log('View button is not found or not visible.');
    }
    await page.waitForTimeout(3000);
    const billNumberSelector = '//td[contains(text(), "ST501")]'; // Adjust if necessary based on table structure
    const billNumberElement = page.locator(billNumberSelector);

    // Check if the bill number exists
    const billCount = await billNumberElement.count();
    if (billCount === 0) {
        console.log('Verified: Bill number "ST501" does NOT appear in the inventory stock report.');
    } else {
        console.error('Error: Bill number "ST501" is present in the inventory stock report.');
    }
}

async function selectfilterCustomerLedger(page, customername) {

    await page.locator(locators.reportsmenu.reports).click();
    await page.locator(locators.reportsmenu.Accountledger).click();
        await page.locator(locators.reportsmenu.CustomerAccountledger).click();
        await expect(page.locator('li.breadcrumb-item.active', { hasText: 'Customer Account ledger Report ' })).toBeVisible();

    await page.locator(locators.CustomerAccountfilterbutton).click();
    await page.locator(locators.customerfiltersummary).click();
    await page.fill(locators.entercustomername, customername);
    await page.locator('li.e-list-item', { hasText: customername }).click();

    await page.waitForTimeout(1000);
    await page.locator(locators.CustomerAccountsearchbutton).click();
    await page.waitForTimeout(1000);

}



module.exports = { selectsubmenu, selectcustomer, viewlink,addSaleReturn,ResetSaleReturn,selectfilteritemwise,selectfiltersalesummary,verifydetailssalesummary,selectfiltercombinesale,selectfilterOutstanding,selectfilterInventorystock,viewlink1,selectfilterCustomerLedger };


