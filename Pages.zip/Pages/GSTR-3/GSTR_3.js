const { test, expect } = require('@playwright/test');
const locators = require('./GSTR_3.json');

function formatDate(date) {
    const day = String(date.getDate()).padStart(2, '0');
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const year = date.getFullYear();

    return `${day}-${month}-${year}`;
}

async function CurrentMonthDateFilter(page) {
    let today = new Date();

    // Start date of the current month
    let startDate = new Date(today.getFullYear(), today.getMonth(), 1);

    // End date of the current month
    let endDate = new Date(today.getFullYear(), today.getMonth() + 1, 0);

    // Format the dates as 'dd-MM-yyyy'
    let formattedStartDate = formatDate(startDate);
    let formattedEndDate = formatDate(endDate);

    console.log(`Start Date: ${formattedStartDate}`);
    console.log(`End Date: ${formattedEndDate}`);

    await page.locator(locators.Date).click();
    const datepicker = '#GSTR3BReportDatePickerForFilter';
    await page.fill(datepicker, '');
    await page.fill(datepicker, `${formattedStartDate} - ${formattedEndDate}`);
    console.log("Fill Current Month Date");
    await page.waitForTimeout(1000);
    await page.locator(locators.Serach).click();
    await page.waitForTimeout(1000);
    console.log("Search after date filter applied.");
}

async function SearchDate(page){
    await page.click(locators.GSTRReport);
    await page.click(locators.GSTR3Page);
    await CurrentMonthDateFilter(page);
    await page.click(locators.PDFButton);
    await page.click(locators.Reset);




}

module.exports = {SearchDate};
