const { test, expect } = require('@playwright/test');
const locators = require('./InventoryMerge.json');

const fs = require('fs');
const path = require('path');

// Define the file path for the variable storage
let filePath = path.join(process.cwd(), 'Dynamic_Variables_Manage/Dynamic_Variable.json');

// Ensure the variable file exists
if (!fs.existsSync(filePath)) {
    console.error(`File not found: ${filePath}`);
    process.exit(1);
}

let updatedVariables = JSON.parse(fs.readFileSync(filePath, 'utf-8'));
let customerName = updatedVariables.Customer.Customer_Account_Name;

async function verifyinventory(page) {
    await page.click(locators.inventorypage);

    await page.isVisible(locators.inventorygroup);
    await page.isVisible(locators.taxabledropdown);
    await page.isVisible(locators.searchbutton);
    await page.isVisible(locators.resetbutton);
    await page.isVisible(locators.inventorygroupname);
    await page.isVisible(locators.inventoryname);
    await page.isVisible(locators.taxtype);
    await page.isVisible(locators.HSNcode);
    await page.isVisible(locators.GSTpercentage);
    await page.isVisible(locators.Action);

    // Verify that Inventory Name is non-editable
    const inventoryNameField = await page.$(locators.inventoryname1);
    const isDisabled = await inventoryNameField.evaluate(el => el.hasAttribute('disabled'));
    console.log(`Inventory Name is disabled: ${isDisabled}`);

    // Verify the presence of dropdowns and buttons
    const inventoryGroupDropdown = await page.$(locators.inventorygroup);
    const taxableDropdown = await page.$(locators.taxabledropdown);
    const searchButton = await page.$(locators.searchbutton);
    const resetButton = await page.$(locators.resetbutton);

    console.log(`Inventory Group Dropdown present: ${!!inventoryGroupDropdown}`);
    console.log(`Taxable Dropdown present: ${!!taxableDropdown}`);
    console.log(`Search Button present: ${!!searchButton}`);
    console.log(`Reset Button present: ${!!resetButton}`);


    // Set Inventory Group to Finish Material
    await page.click(locators.inventorygroup);
    await page.click(locators.FinishMaterial);

    // Set Taxable to Taxable
    await page.click(locators.taxabledropdown);
    await page.click(locators.Taxable); // Select Taxable

    // Click Search to refresh the inventory list
    await page.click(locators.searchbutton);

    // Wait for the inventory list to refresh
    await page.waitForSelector(locators.inventoryname);

    // Verify all Finish Material inventories marked as Taxable are displayed
    const taxableInventories = await page.$$eval(locators.taxtype, elements =>
        elements.filter(el => el.textContent.includes('Taxable')).length
    );
    console.log(`Number of Taxable Inventories: ${taxableInventories}`);
    await page.waitForTimeout(1000);
    // Change Taxable to Non-GST and verify only non-GST inventories are displayed
    await page.click(locators.taxabledropdown);
    await page.click(locators.NonGST); // Select Non-GST

    // Click Search to refresh the inventory list
    await page.click(locators.searchbutton);

    // Wait for the inventory list to refresh
    await page.waitForSelector(locators.inventoryname); // Adjust selector as needed
    await page.waitForTimeout(1000);
    // Verify only non-GST inventories are displayed
    const nonGSTInventories = await page.$$eval(locators.taxtype, elements =>
        elements.filter(el => el.textContent.includes('Non GST')).length
    );
    console.log(`Number of Non-GST Inventories: ${nonGSTInventories}`);

    // Switch Taxable back to Taxable
    await page.click(locators.taxabledropdown);
    await page.click(locators.Taxable); // Select Taxable

    // Click Search to refresh the inventory list
    await page.click(locators.searchbutton);

    // Wait for the inventory list to refresh
    await page.locator(locators.inventoryname);
    await page.waitForTimeout(2000);

    await page.locator(locators.keepthisinventory).nth(0).click();

    // Ensure Inventory Name field is populated and editable
    const inventoryNameField1 = await page.locator(locators.inventoryname1);
    await page.waitForTimeout(2000);
    const inventoryNameValue = await inventoryNameField1.inputValue();
    await page.waitForTimeout(2000);
    console.log(`Inventory Name Field Value: ${inventoryNameValue}`); // Adjust selector as neede
    const isEditable = await inventoryNameField1.evaluate(el => !el.hasAttribute('readonly') && !el.hasAttribute('disabled'));
    console.log(`Inventory Name is editable: ${isEditable}`);


    // Verify checkboxes appear next to inventories, and the Action column disappears
    const checkboxes = await page.$$(locators.checkbox); // Adjust selector as needed
    console.log(`Checkboxes present: ${checkboxes.length > 0}`);

    const actionColumn = await page.$(locators.Action); // Adjust selector as needed
    const isActionColumnVisible = actionColumn !== null;
    console.log(`Action Column Disappears : ${isActionColumnVisible}`);

    // Select inventories to merge by checking the checkboxes
    //await page.click(locators.checkbox);
    await page.locator("span.e-frame.e-icons.e-uncheck").nth(2).click();
    await page.waitForTimeout(2000);
    // Click "Merge All Selected" to merge Inventory A into Inventory B
    const mergeAllSelectedButton = await page.locator(locators.mergeallselected);
    await mergeAllSelectedButton.click();
    await page.waitForTimeout(2000);

    await page.click("//button[normalize-space()='OK']");
    await page.waitForTimeout(3000);

    console.log("Inventory Merged Succesfully..")



}

async function verifytransactionrecord(page) {
    // navigate to sales menu
    await page.click(locators.sales.sales_menu);
    await page.click(locators.sales.salespage);


    await page.locator(locators.sales.customerdropdown).click();
    await page.fill(locators.sales.entercustomername, customerName);
    //  Select the desired customer by its text
    await page.locator('li.e-list-item', { hasText: customerName }).click();
    await page.waitForTimeout(1000);
    await page.locator('#SalesListSearchButton').click();
    const view = await page.locator(locators.sales.viewbutton).nth(0);
    await view.click();


    // Verify Inventory Names in Transactions
    const transactions = await page.$$eval('td#SalesViewInventoryNameColumn', elements => elements.map(e => e.textContent.trim()));

    let inventoryAExists = false; // Check for "demolast"
    let inventoryBExists = true; // Check for "demozinal"


    // Loop through transaction records
    for (const inventoryName of transactions) {
        if (inventoryName === 'demolast') {
            inventoryAExists = false;
        } else if (inventoryName === 'demozinal') {
            inventoryBExists = true;
        }
    }

    // Final validation
    if (!inventoryAExists && inventoryBExists) {
        console.log(' Verification Passed: "demolast" is not displayed and "demozinal" is displayed.');
    } else {
        console.error(' Verification Failed: "demolast" is still displayed or "demozinal" is not displayed.');
    }


}

async function SACitemwise(page) {
    await page.locator(locators.Itemwise.sales_menu).click();
    await page.locator(locators.Itemwise.reportitemwise).click();
    await page.locator(locators.Itemwise.Itemwise_Filter).click();

    await page.locator(locators.Itemwise.Item).click();
    await page.fill(locators.sales.entercustomername, "demozinal");
    await page.locator('li.e-list-item', { hasText: "demozinal" }).click();



    await page.locator(locators.Itemwise.searchbutton_Itemwise).click();


}

async function purchaseitemwise(page) {

    await page.locator(locators.purchaseitemwise.purchase_menu).click();
    await page.locator(locators.purchaseitemwise.purchase_item).click();
    await page.locator(locators.purchaseitemwise.purchase_itemwise_filter).click();

    await page.locator(locators.Itemwise.Item).click();
    await page.fill(locators.sales.entercustomername, "demozinal");
    await page.locator('li.e-list-item', { hasText: "demozinal" }).click();



    await page.locator(locators.purchaseitemwise.purchase_itewise_search).click();


}

async function inventorystockreport(page) {
    await page.locator(locators.inventorystockreport.inventoryStock).click();
    await page.click('#InventoryReportopenSideBarButton');
    await page.click(locators.inventorystockreport.FilterInventorygroup);
    await page.click("//li[normalize-space()='FinishMaterial']");
    await page.waitForTimeout(2000);
    await page.locator(locators.inventorystockreport.inventoryselect).click();

    await page.fill(locators.inventorystockreport.enterInventory, "demozinal");
    await page.locator('li.e-list-item', { hasText: "demozinal" }).click();

    await page.locator(locators.inventorystockreport.inventorysearchbutton).click();


}



module.exports = { verifyinventory, verifytransactionrecord, SACitemwise, purchaseitemwise, inventorystockreport };