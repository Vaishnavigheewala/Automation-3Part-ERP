const { test, expect } = require('@playwright/test');
const locators = require('./Debitnote.json');
const { TIMEOUT } = require('dns');
const fs = require('fs');


async function selectsubmenuofdebit(page,menu) {
    
        if (menu == "Reports") {
            await page.locator(locators.reports_menu.reports).click();
            await page.locator(locators.reports_menu.debit_menu).click();
            await expect(page.locator('li.breadcrumb-item.active', { hasText: 'Debit Note' })).toBeVisible();
    
        }
}

async function selectfilterResetDebit(page, vendorname ,date ) {

    const backButton = page.locator('button:has-text("Back")');
    const pdfExportButton = page.locator('button:has-text("PDF Export")');
    const filterButton = page.locator('button:has-text("Filter")');
    
    await expect(backButton).toBeVisible();
    await expect(pdfExportButton).toBeVisible();
    await expect(filterButton).toBeVisible();
  
    const button = await page.locator('span.e-ungroupbutton[title="Ungroup by this column"]').nth(0);
      await button.click();

      const button2 = await page.locator('span.e-ungroupbutton[title="Ungroup by this column"]').nth(0);
      //await button2.waitFor({ state: 'visible' });
      await page.waitForTimeout(1000); // Adjust this time as needed
      await button2.click();
  
    console.log(' Back, PDF Export, and Filter buttons are visible');
  
      await page.locator(locators.Debit_Note.debit_filter).click();
  
      await page.locator(locators.vendordropdown).click();
      await page.fill(locators.entercustomername, vendorname);
      await page.waitForTimeout(1000);
      
      const datepicker = '#DabitNoteReportDatePickerForFilter'; //code to clear the date
      await page.fill(datepicker, ''); //code to clear the date
      await page.fill(datepicker, date); //code to enter current data
      await page.locator(locators.Debit_Note.debit_reset).click();
      await page.waitForTimeout(1000);
      await page.locator(locators.Debit_Note.debit_close).click();
  
  
  }
  
  
  async function selectfilterDebit(page, vendorname ) {
    await page.locator(locators.Debit_Note.debit_filter).click();
  
      //await page.locator(locators.Itemwise_report.Itemwise_Filter).click();
      
      await page.locator(locators.vendordropdown).click();
      await page.fill(locators.entercustomername, vendorname);
      await page.locator('li.e-list-item', { hasText: vendorname }).click();
      await page.waitForTimeout(3000);
    
      await page.locator(locators.Debit_Note.debit_search).click();
      await page.waitForTimeout(1000);

      await page.locator(locators.bill_no).click();
   // await page.waitForTimeout(1000);
    console.log(" The report is sorted by Bill No in assending order");
    await page.waitForTimeout(1000);
    await page.locator(locators.bill_no).click();
    await page.waitForTimeout(1000);
    console.log(" The report is sorted by Bill No in descending order");
  
      await page.locator(locators.Debit_Note.debit_back).click();
      await page.waitForTimeout(1000);
  
      await page.locator(locators.Debit_Note.debit_pdf).click();
      await page.waitForTimeout(1000);
  
  
  }



module.exports = { selectsubmenuofdebit,selectfilterResetDebit,selectfilterDebit }