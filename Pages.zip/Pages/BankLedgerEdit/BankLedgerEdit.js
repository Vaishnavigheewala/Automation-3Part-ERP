const { test, expect } = require('@playwright/test');
const locators = require('./BankLedgerEdit.json');

const fs = require('fs');
const path = require('path');

// Define the file path for the variable storage
let filePath = path.join(process.cwd(), 'Dynamic_Variables_Manage/Dynamic_Variable.json');

// Ensure the variable file exists
if (!fs.existsSync(filePath)) {
  console.error(`File not found: ${filePath}`);
  process.exit(1);
}

let updatedVariables = JSON.parse(fs.readFileSync(filePath, 'utf-8'));
let customerName = updatedVariables.Customer.Customer_Account_Name;
let vendor_name = updatedVariables.Vendor.Vendor_Account_Name; 

async function editbankledger(page) {
    await page.click(locators.ledger);
    await page.click(locators.bank_ledger);

    await page.click(locators.customerdropdown);
    await page.fill(locators.entercustomername, customerName);
    await page.locator('li.e-list-item', { hasText: customerName }).click();
    await page.waitForTimeout(1000);
    await page.click(locators.searchbutton);

    // await page.evaluate(() => { window.scrollTo(0, document.body.scrollHeight); });

    const divElement = await page.$('div.e-content.e-yscroll.e-lib.e-droppable'); // Replace with your actual selector
    await page.evaluate((el) => {
        el.scrollLeft += 600; // Adjust this value to scroll further or slower
    }, divElement);
    await page.waitForTimeout(1000);

    await page.click(locators.viewLink);

   
    await page.waitForTimeout(1000);

    await page.click(locators.viewpage.editbutton);

    const netOutstandingAmt = await page.locator(locators.viewpage.netOut).first().textContent();
  // Trim and convert the value to a number
    const amount = parseFloat(netOutstandingAmt.trim());
    console.log("amount",amount);

    if (!isNaN(amount) && amount > 0) {

        console.log(`Filling Received Amount with: ${amount}`);

        // Fill the "Received Amount" input field
        const receive = await page.locator(locators.viewpage.Receivedamt).nth(0);
        receive.dblclick();
        await page.fill(locators.viewpage.enterReceiveamt, amount.toString());
    } else {
        console.log("Invalid Net Outstanding Amount. Skipping input.");
    }


    await page.click(locators.viewpage.balance);
    
    //click on update
    await page.click(locators.viewpage.updatebutton);
    await page.click('//button[normalize-space()="OK"]');

    await page.click(locators.viewpage.submitbutton);

}

async function editforvendor(page) {

    await page.click(locators.ledger);
    await page.click(locators.bank_ledger);
    //edit vendor for partial payment

    //select account group
    await page.click(locators.viewpage.accountgroup);
    await page.click("//li[normalize-space()='Vendor']");


    await page.click(locators.viewpage.vendordropdown);
    await page.fill(locators.entercustomername, vendor_name);
    await page.locator('li.e-list-item', { hasText: vendor_name }).click();
    await page.click(locators.searchbutton);
    await page.waitForTimeout(3000);

    const divElement = await page.$('div.e-content.e-yscroll.e-lib.e-droppable'); // Replace with your actual selector
    await page.evaluate((el) => {
        el.scrollLeft += 600; // Adjust this value to scroll further or slower
    }, divElement);

    await page.click(locators.viewLink);

    const paymentAmount = parseFloat(await page.locator(locators.viewpage.receivedamt).textContent());
    const totalBillAmount = parseFloat(await page.locator(locators.viewpage.netoutstanding).textContent());
    const editButton = page.locator(locators.viewpage.editbutton);
    // Determine payment type
    const paymentType = paymentAmount > totalBillAmount ? 'Partial' : 'Full';
    if (paymentType === 'Partial') {
        // Edit button should be displayed for the latest partial payment
        await expect(editButton).toBeHidden();
    } else {
        // Edit button should not be displayed for earlier ledgers or full payments
        await expect(editButton).toBeVisible();
    }

    await page.click(locators.viewpage.editbutton);

    await page.dblclick(locators.viewpage.paymentmethod);
    await page.waitForTimeout(1000);
    await page.fill(locators.entercustomername, "NEFT");
    await page.locator('li.e-list-item', { hasText: "NEFT" }).dblclick();
    //enter transaction num
    await page.fill(locators.viewpage.TransactionNo, "T2109301234567890123456");

    const netOutstandingAmt = await page.locator(locators.viewpage.netOut).first().textContent();
    // Trim and convert the value to a number
      const amount = parseFloat(netOutstandingAmt.trim());
      console.log("amount",amount);
  
      if (!isNaN(amount) && amount > 0) {
  
          console.log(`Filling Received Amount with: ${amount}`);
  
          // Fill the "Received Amount" input field
          const receive = await page.locator(locators.viewpage.Receivedamt).nth(0);
          receive.dblclick();
          await page.fill(locators.viewpage.enterReceiveamt, amount.toString());
      } else {
          console.log("Invalid Net Outstanding Amount. Skipping input.");
      }

      await page.click(locators.viewpage.balance);

      await page.click(locators.viewpage.updatebutton);
      await page.click('//button[normalize-space()="OK"]');
  
      await page.click(locators.viewpage.submitbutton);
  
  
}

async function outstandingforcustomer(page) {
    // Click on Reports → Outstanding Reports
    await page.click(locators.outstandingreport.outstanding);

    // Open the filter sidebar
    await page.click(locators.outstandingreport.filterbutton);

    // Enter Customer Name in the filter

    await page.click(locators.customerdropdown);
    await page.waitForTimeout(1000);
    await page.fill(locators.entercustomername, customerName);
    await page.locator('li.e-list-item', { hasText: customerName }).click();
    // Apply the filter by clicking on Search
    await page.click(locators.outstandingreport.SearchButton);


    // Check for sales/AMCs with 0 pending payment
    const zeroPendingRows = await page.$$eval('table tbody tr', rows => {
        return rows.filter(row => {
            const balanceElement = row.querySelector('#OutstandingReportRemainBalanceAmountColumn');
            const balance = balanceElement ? parseFloat(balanceElement.innerText.replace(/[^0-9.-]+/g, "")) : 0;
            return balance === 0;
        });
    });

    if (zeroPendingRows.length < 0) {
        console.error('Found sales/AMCs with 0 pending payment displayed in the report.');
    } else {
        console.log('No sales/AMCs with 0 pending payment displayed in the report.');
    }
}

async function customeraccledger(page) {
    await page.click(locators.customeraccLedger.accountLedger);
    await page.click(locators.customeraccLedger.customeraccount);
    await page.click(locators.customeraccLedger.filterbutton);

    await page.click(locators.customerdropdown);
    await page.fill(locators.entercustomername, customerName);
    await page.locator('li.e-list-item', { hasText: customerName }).click();
    await page.click(locators.customeraccLedger.Searchbutton);
    console.log('Customer Account Ledger Report verification completed successfully.');
}

async function VerifyConsistency(page) {

    await page.click(locators.outstandingreport.outstanding);
    await page.click(locators.outstandingreport.filterbutton);

    // Enter Customer Name in the filter
    await page.click(locators.customerdropdown);
    await page.fill(locators.entercustomername, customerName);
    await page.locator('li.e-list-item', { hasText: customerName }).click();
    // Apply the filter by clicking on Search
    await page.click(locators.outstandingreport.SearchButton);

    await page.waitForSelector(`tr:has(td:has-text("${customerName}"))`);// wait up to 60 seconds

    // Now locate the row and get the balance
    await page.locator(`tr:has(td:has-text("${customerName}"))`);
    const outstandingBalance = await page.locator('td.e-summarycell[data-cell="Balance"]').textContent();
    console.log(`Outstanding Report Overall Balance: ${outstandingBalance}`);

    console.log('Outstanding Report verification completed successfully.');
    await page.click(locators.customeraccLedger.reports);
    await page.click(locators.customeraccLedger.accountLedger);
    await page.click(locators.customeraccLedger.customeraccount);
    await page.click(locators.customeraccLedger.filterbutton);

    await page.click(locators.customerdropdown);
    await page.fill(locators.entercustomername, customerName);
    await page.locator('li.e-list-item', { hasText: customerName }).click();

    await page.click(locators.customeraccLedger.Searchbutton);
    await page.waitForSelector(`tr:has(td:has-text("${customerName}"))`);// wait up to 60 seconds

    await page.locator(`tr:has(td:has-text("${customerName}"))`);
    const recentBalance = await page.locator('td.e-summarycell[data-cell="Balance"]').textContent();
    console.log(`customer Ledger Report Overall Balance: ${recentBalance}`);
    expect(parseFloat(outstandingBalance)).toBe(parseFloat(recentBalance));
    console.log('Consistency between Outstanding Report and Account Ledger verified successfully.');
}

async function payablereportforvendor(page) {
    await page.locator(locators.payablereport.reportpayble).click();
    await page.locator(locators.payablereport.FilterbtnpurchasePayblereport).click();
    await page.locator(locators.payablereport.FiltervenpurchasePayble).click();
    await page.fill(locators.entercustomername, vendor_name);
    await page.locator('li.e-list-item', { hasText: vendor_name }).click();
    await page.locator(locators.payablereport.SearchbtnpurchasePayble).click();

}

async function Vendoraccountledger(page) {
    await page.locator(locators.vendoraccountledger.accledger).click();
    await page.locator(locators.vendoraccountledger.reportvendoraccountledger).click();
    await page.locator(locators.vendoraccountledger.Filterbtnpurchasevendorledgerreport).click();
    await page.locator(locators.vendoraccountledger.Filtervenpurchasevendorledger).click();
    await page.fill(locators.entercustomername, vendor_name);
    await page.locator('li.e-list-item', { hasText: vendor_name }).click();
    await page.locator(locators.vendoraccountledger.Searchbtnpurchasevendorledger).click();

}




module.exports = { editbankledger, editforvendor, outstandingforcustomer, customeraccledger, VerifyConsistency, payablereportforvendor, Vendoraccountledger };