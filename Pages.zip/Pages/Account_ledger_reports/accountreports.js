const { test, expect } = require('@playwright/test');
const locators = require('./accountreports.json');
const { TIMEOUT } = require('dns');
const fs = require('fs');


async function selectsubmenuofaccountledger(page, menu) {

  if (menu == "Reports") {
    await page.locator(locators.reports_menu.reports).click();
    await page.locator(locators.reports_menu.account_ledger).click();
    await page.locator(locators.reports_menu.vendor_ledger).click();
    await expect(page.locator('li.breadcrumb-item.active', { hasText: 'Vendor Account Ledger Report' })).toBeVisible();

  }
}



async function selectfilterResetvendor(page, vendorname, date) {

  const backButton = page.locator('button:has-text("Back")');
  const pdfExportButton = page.locator('button:has-text("PDF Export")');
  const filterButton = page.locator('button:has-text("Filter")');

  await expect(backButton).toBeVisible();
  await expect(pdfExportButton).toBeVisible();
  await expect(filterButton).toBeVisible();

  const button = await page.locator('span.e-ungroupbutton[title="Ungroup by this column"]');
  await button.click();


  console.log(' Back, PDF Export, and Filter buttons are visible');

  await page.locator(locators.vendor_ledger.vendor_ledger_filter).click();

  await page.locator(locators.vendordropdown).click();
  await page.fill(locators.entercustomername, vendorname);
  await page.waitForTimeout(1000);

  const datepicker = '#VendorAccountLedgerReportDatePickerForFilter'; //code to clear the date
  await page.fill(datepicker, ''); //code to clear the date
  await page.fill(datepicker, date); //code to enter current data
  await page.locator(locators.vendor_ledger.vendor_ledger_reset).click();
  await page.waitForTimeout(1000);
  await page.locator(locators.vendor_ledger.vendor_ledger_close).click();


}

async function selectfiltervendor(page, vendorname) {
  await page.locator(locators.vendor_ledger.vendor_ledger_filter).click();

  //await page.locator(locators.Itemwise_report.Itemwise_Filter).click();

  await page.locator(locators.vendordropdown).click();
  await page.fill(locators.entercustomername, vendorname);
  await page.locator('li.e-list-item', { hasText: vendorname }).click();
  await page.waitForTimeout(3000);

  await page.locator(locators.vendor_ledger.vendor_ledger_search).click();
  await page.waitForTimeout(1000);

  await page.locator(locators.vendor_ledger.vendor_ledger_back).click();
  await page.waitForTimeout(1000);

  await page.locator(locators.vendorbill).click();

  console.log(" The report is sorted by Bill No in assending order");

  await page.locator(locators.vendorbill).click();

  console.log(" The report is sorted by Bill No in descending order");
}

async function selectfilterResetcustomer(page, customername, date) {

  await page.locator(locators.reports_menu.reports).click();
  await page.locator(locators.reports_menu.account_ledger).click();
  await page.locator(locators.reports_menu.customer_ledger).click();

  const backButton = page.locator('button:has-text("Back")');
  const pdfExportButton = page.locator('button:has-text("PDF Export")');
  const filterButton = page.locator('button:has-text("Filter")');

  await expect(backButton).toBeVisible();
  await expect(pdfExportButton).toBeVisible();
  await expect(filterButton).toBeVisible();

  const button = await page.locator('span.e-ungroupbutton[title="Ungroup by this column"]');
  await button.click();


  console.log(' Back, PDF Export, and Filter buttons are visible');

  await page.locator(locators.customer_ledger.customer_ledger_filter).click();

  await page.locator(locators.customerdropdown).click();
  await page.fill(locators.entercustomername, customername);
  await page.locator('li.e-list-item', { hasText: customername }).click();

  //await page.waitForTimeout(1000);

  const datepicker = '#AccountLedgerReportDateRangePickerForFilter'; //code to clear the date
  await page.fill(datepicker, ''); //code to clear the date
  await page.fill(datepicker, date); //code to enter current data
  await page.locator(locators.customer_ledger.customer_ledger_reset).click();
  //await page.waitForTimeout(1000);
  await page.locator(locators.customer_ledger.customer_ledger_close).click();


}

async function selectfiltercustomer(page, customername) {

  await page.locator(locators.customer_ledger.customer_ledger_filter).click();
  await page.waitForTimeout(1000);
  await page.locator(locators.customerdropdown).click();
  await page.waitForTimeout(1000);
  await page.fill(locators.entercustomername, customername);
  await page.locator('li.e-list-item', { hasText: customername }).click();


  await page.locator(locators.customer_ledger.customer_ledger_search).click();


  await page.locator(locators.customer_ledger.customer_ledger_back).click();


  await page.locator(locators.customer_ledger.customer_ledger_pdf).click();


  await page.locator(locators.bill_no).click();

  console.log(" The report is sorted by Bill No in assending order");

  await page.locator(locators.bill_no).click();

  console.log(" The report is sorted by Bill No in descending order");
}

async function Handle_New_Tab(page, clickSelector, targetSelector, action) {
  // Step 1: Get the browser context from the page
  const context = page.context();

  // Step 2: Click the element that opens the new tab and wait for the new tab to open
  const [newPage] = await Promise.all([
    context.waitForEvent('page'), // Wait for the new page event
    page.locator(clickSelector).nth(1).click(), // Click action to open new tab
  ]);

  console.log("✅ New tab opened:", newPage.url());

  // Step 3: Ensure the new tab loads completely
  await newPage.waitForLoadState();

  // Step 4: Wait for the target element to be visible (if provided)
  try {
    await newPage.waitForSelector(targetSelector, { state: 'attached', timeout: 10000 });
    console.log(`✅ Element ${targetSelector} found!`);
  } catch (error) {
    console.log(`❌ ERROR: Element ${targetSelector} NOT found.`);
    console.log("💡 Possible reasons: Selector incorrect, slow loading, inside iframe.");
  }

  // Step 5: Perform custom actions inside the new tab (if provided)
  if (action) {
    await action(newPage);
  }

  // Step 6: Close the new tab
  await newPage.close();
  console.log("✅ New tab closed.");

  // Step 7: Ensure the original page is still active
  await expect(page).toHaveURL(page.url()); // Validate it's still on the same page
}



let BillFrompage;

async function handleNewTab(page, clickSelector, expectedUrl, targetSelector, action) {
  // Step 1: Get the browser context
  const context = page.context();

  // Step 2: Check if the clickable element exists
  let elements = await page.locator(clickSelector).count();
  if (elements === 0) {
    console.log(`❌ No element found with selector: ${clickSelector}. New tab will NOT open.`);
    return; // Exit function if no element to click
  }

  // Step 3: Select the first row element
  const firstElement = page.locator(clickSelector).first();

  // Step 4: Wait for the element to be visible & stable
  await firstElement.waitFor({ state: 'visible', timeout: 5000 });

  // Step 5: Check if the first element contains an <a> tag
  const anchorElement = firstElement.locator('a'); // Find <a> inside the first row
  const anchorCount = await anchorElement.count(); // Count <a> tags inside

  console.log(`🔍 Debug: First element HTML ->`, await firstElement.evaluate(el => el.outerHTML));

  if (anchorCount === 0) {
    console.log("⚠️ First element is NOT a link. New tab will NOT open.");
    return; // Exit function if no <a> tag found
  }

  // Step 6: Extract text inside the <a> tag
  BillFrompage = await anchorElement.first().textContent();
  console.log("✅ Account Ledger Page Bill =", BillFrompage);

  // Step 7: Click to open a new tab and wait for it
  let [newPage] = await Promise.all([
    context.waitForEvent('page'), // Wait for new tab
    anchorElement.first().click(), // Click the first <a> inside the row
  ]);

  console.log("✅ New tab opened:", newPage.url());

  // Step 8: Ensure the new tab loads completely
  await newPage.waitForLoadState();

  // Step 9: Verify URL
  //expect(newPage.url()).toContain(expectedUrl);

  // Step 10: Wait for the target element (if provided)
  if (targetSelector) {
    try {
      await newPage.waitForSelector(targetSelector, { timeout: 10000 });
      console.log(`✅ Element ${targetSelector} found!`);
    } catch (e) {
      console.log(`❌ Element ${targetSelector} NOT found.`);
    }
  }

  // Step 11: Perform custom actions inside the new tab
  if (action) {
    await action(newPage);
  }

  // Step 12: Close the new tab
  await newPage.close();
  console.log("✅ New tab closed.");

  // Step 13: Ensure the original page is still active
  await expect(page).toHaveURL(page.url());
}




module.exports = { selectsubmenuofaccountledger, selectfiltervendor, selectfilterResetvendor, selectfilterResetcustomer, selectfiltercustomer, Handle_New_Tab, handleNewTab }