const { test, expect } = require('@playwright/test');
const locators = require('./Payment_Nature.json');

async function verifyledger(page) {
    await page.locator(locators.CashLedger.Ledger).click();
    await page.locator(locators.CashLedger.CashLedgerpage).click();
    await expect(page.locator('li.breadcrumb-item.active', { hasText: 'Cash' })).toBeVisible();
  
    await page.locator(locators.CashLedger.AddnewButton).click();

    //select date range
    await page.locator(locators.CashLedger.Datepicker).click();
    const datepicker = '#CommonDatePicker'; //code to clear the date
    await page.fill(datepicker, ''); //code to clear the date
    await page.fill(datepicker, '06-01-2025');
  
    await page.waitForTimeout(2000);

    await page.locator(locators.CashLedger.Payment_Nature).click();
    await page.locator("//li[normalize-space()='Receive']").click();
    console.log('Payment Nature is Selected');
    await page.waitForTimeout(2000);
  
    await page.locator(locators.CashLedger.Customer_Name).click();
    await page.locator('li.e-list-item', { hasText: "Jash Test 2" }).click();
    console.log("Customer Selected");
    await page.waitForTimeout(2000);

    await page.locator(locators.CashLedger.Inventory_Add).click();
    await page.waitForTimeout(2000);

    await page.locator(locators.CashLedger.Bill_Type).click();
    await page.locator('li.e-list-item', { hasText: "GSTAmc" }).click();
    await page.waitForTimeout(1000);

    await page.locator(locators.CashLedger.Bill_No).dblclick();
    await page.locator(locators.CashLedger.Bill_No1).dblclick();
    await page.locator('li.e-list-item', { hasText: "IN146" }).click();
    await page.waitForTimeout(1000);

    await page.locator(locators.CashLedger.Received).dblclick();
    await page.fill(locators.CashLedger.Received1, "5000");
    await page.waitForTimeout(2000);

    await page.locator(locators.CashLedger.Inventory_Update).click();
    await page.locator(locators.CashLedger.Update_Ok).click();
    await page.waitForTimeout(2000);

    await page.locator(locators.CashLedger.Close).click();
    await page.waitForTimeout(2000);

}


//reports
async function amcreport(page){
    await page.locator(locators.Reports.amcreport).click();
   // await expect(page.locator('li.breadcrumb-item.active', { hasText: 'AMC Report' })).toBeVisible();
    await page.locator(locators.Reports.filterbutton).click();
    await page.waitForTimeout(2000);
  
    //select customer
    const dropdown = page.locator('span.e-ddl.e-lib.e-input-group.e-control-container.e-control-wrapper.e-multi-column.CommonCustomerDropdownCustomerId').nth(0); // Adjust the index as needed
    await dropdown.click();
    await page.waitForTimeout(2000);
    await page.fill(locators.CashLedger.entercustomername, "Jash Test 2");
    await page.locator('li.e-list-item', { hasText: "Jash Test 2" }).click();
    await page.waitForTimeout(2000);
  
    //click on searchbutton
    await page.locator(locators.Reports.searchbuttonamc).click();
  }
  async function outstanding(page){
    await page.locator(locators.Reports.outstandingreport).click();
   // await expect(page.locator('li.breadcrumb-item.active', { hasText: 'AMC Report' })).toBeVisible();
    await page.locator(locators.Reports.filteroutstanding).click();
    await page.waitForTimeout(2000);
  
    //select customer
    const dropdown = page.locator('span.e-ddl.e-lib.e-input-group.e-control-container.e-control-wrapper.e-multi-column.CommonCustomerDropdownCustomerId').nth(0); // Adjust the index as needed
    await dropdown.click();
    await page.waitForTimeout(2000);
    await page.fill(locators.CashLedger.entercustomername, "Jash Test 2");
    await page.locator('li.e-list-item', { hasText: "Jash Test 2" }).click();
    await page.waitForTimeout(2000);
  
    //click on searchbutton
    await page.locator(locators.Reports.searchbuttonoutstanding).click();
  }
  
  async function customerAccountledger(page){
    await page.locator(locators.Reports.Accountledgerreport).click();
    await page.locator(locators.Reports.customeraccountledger).click();
   // await expect(page.locator('li.breadcrumb-item.active', { hasText: 'AMC Report' })).toBeVisible();
    await page.locator(locators.Reports.filtercustomer).click();
    await page.waitForTimeout(2000);
  
    //select customer
    const dropdown = page.locator('span.e-ddl.e-lib.e-input-group.e-control-container.e-control-wrapper.e-multi-column.CommonCustomerDropdownCustomerId').nth(0); // Adjust the index as needed
    await dropdown.click();
    await page.waitForTimeout(2000);
    await page.fill(locators.CashLedger.entercustomername, "Jash Test 2");
    await page.locator('li.e-list-item', { hasText: "Jash Test 2" }).click();
    await page.waitForTimeout(2000);
  
    //click on searchbutton
    await page.locator(locators.Reports.searchcustomer).click();
  }
  
  async function Inventorystock(page) {
    await page.locator(locators.Reports.inventoryStock).click();
     await page.locator(locators.Reports.inventoryfilter).click();
     await page.waitForTimeout(2000);
   
  
    //await page.click('#InventoryReportopenSideBarButton');
    console.log("Clicked on the Filter button.");
    await page.click(locators.Reports.selectinventorygroup);
    await page.click("//li[normalize-space()='RawMaterial']");
    console.log("Selected inventory group.");
    await page.locator(locators.Reports.inventoryselect).click();
    await page.fill(locators.Reports.enterInventory, "alien");
    await page.locator('li.e-list-item', { hasText: "alien" }).click();
  
    await page.waitForTimeout(1000);
    await page.locator(locators.Reports.inventorysearchbutton).click();
  
    await page.waitForTimeout(3000);
    const divElement = await page.$('div.e-content.e-yscroll.e-lib.e-droppable'); // Replace with your actual selector
    await page.evaluate((el) => {
         el.scrollLeft += 600; // Adjust this value to scroll further or slower
        }, divElement);
    const viewButton = await page.locator('a#InventoryReportViewDetailedinventoryReportButton'); //Adjust this with the actual selector for the "View"
  
    // Check if the "View" button is visible
    const isVisible = await viewButton.isVisible();
    if (isVisible) {
      console.log('View button is visible. Proceeding with click.');
      await viewButton.click();
      console.log('Clicked on "View" button.');
  } else {
      console.log('View button is not found or not visible.');
  }
  
  }
  

module.exports = {verifyledger, outstanding, amcreport, customerAccountledger ,Inventorystock};