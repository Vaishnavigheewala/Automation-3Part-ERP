const { test, expect } = require('@playwright/test');
const locators = require('./sale_reports.json');
const { TIMEOUT } = require('dns');
const fs = require('fs');


async function selectsubmenu(page,menu) {
    
        if (menu == "Reports") {
            await page.locator(locators.reports_menu.reports).click();
            await page.locator(locators.reports_menu.sales_menu).click();
            await page.locator(locators.reports_menu.reportitemwise).click();
            await expect(page.locator('li.breadcrumb-item.active', { hasText: 'Item Wise' })).toBeVisible();
    
        }
}

async function selectfilterResetitemwise(page, customername) {

    const backButton = page.locator('button:has-text("Back")');
  const pdfExportButton = page.locator('button:has-text("PDF Export")');
  const filterButton = page.locator('button:has-text("Filter")');
  
  await expect(backButton).toBeVisible();
  await expect(pdfExportButton).toBeVisible();
  await expect(filterButton).toBeVisible();

  console.log('Back, PDF Export, and Filter buttons are visible');

    await page.locator(locators.Itemwise_report.Itemwise_Filter).click();
    await page.locator(locators.customerdropdown).click();
    await page.fill(locators.entercustomername, customername);
    await page.waitForTimeout(1000);
    // Step : Select the desired customer by its text
    const itemLocator = page.locator(`//td[@title='${customername}']`);
    await expect(itemLocator).toBeVisible();
    await itemLocator.click();
   
    await page.locator(locators.Itemwise_report.item_reset).click();
    //await page.locator(locators.Itemwise_report.searchbutton_Itemwise).click();

}


async function selectfilteritemwise(page, customername) {

    //await page.locator(locators.Itemwise_report.Itemwise_Filter).click();
    await page.locator(locators.customerdropdown).click();
    await page.fill(locators.entercustomername, customername);
    await page.waitForTimeout(1000);
    // Step : Select the desired customer by its text
    const itemLocator = page.locator(`//td[@title='${customername}']`);
    await expect(itemLocator).toBeVisible();
    await itemLocator.click();
   
    //await page.locator(locators.Itemwise_report.item_reset).click();
    await page.locator(locators.Itemwise_report.searchbutton_Itemwise).click();

}

async function verifydetailsitemwise(page) {
    /*****************Verify Customer Name is Correct ************************/
    //const Verifycustomer = JSON.parse(fs.readFileSync('customer.json')); //Read the shared Net Amount from the JSON file
    //const sharedcustomername = Verifycustomer.customername;
    const rows = await page.locator('tr[aria-rowindex]'); // Select all rows with aria-rowindex
    const firstRow = await rows.nth(0); // Select the first row
    await page.waitForTimeout(1000);
    const valuethree = await firstRow.locator("td#ItemWiseSalesReportCustomerNameColumn");
    await page.waitForTimeout(2000);
    const customernamecolumn = await valuethree.innerText();
    //expect(sharedcustomername).toBe(customernamecolumn);
    console.log("Customer Name before Submit is same as Customer Name on the Itemwise Sales Report")
    //const datatwo = JSON.parse(fs.readFileSync('VerifygstbillforSalesReturn.json'));
    //const sharedlatestBillNumber = datatwo.latestGstbillnumber;
    const valuetwo = await firstRow.locator("td#ItemWiseSalesReportBillNumberColumn");
    const gstbillonreport = await valuetwo.innerText();
    const numericPart = gstbillonreport.slice(2);
    const gstBillNumber = parseInt(numericPart, 10);
    //expect(sharedlatestBillNumber).toBe(gstBillNumber);
    console.log("Correct GST Bill # is displayed ");

    const button = await page.locator('span.e-ungroupbutton[title="Ungroup by this column"]');
    await button.click();

    // Step : Verify Bill No. is sorted in descending order
  const billNumbers = await page.$$eval('.bill-number-column', elements => elements.map(e => e.textContent));
  const sortedBillNumbers = [...billNumbers].sort((a, b) => b - a);
  expect(billNumbers).toEqual(sortedBillNumbers);

}
async function selectfilterResetsalesummary(page, customername) {
    await page.locator(locators.reports_menu.reports).click();
            await page.locator(locators.reports_menu.sales_menu).click();
            await page.locator(locators.reports_menu.summaryvise).click();

    await page.locator(locators.sale_summary.fillterbuttonsummary).click();
    await page.locator(locators.customerdropdown).click();
    await page.fill(locators.entercustomername, customername);
    await page.waitForTimeout(1000);
    // Step : Select the desired customer by its text
    const itemLocator = page.locator(`//td[@title='${customername}']`);
    await expect(itemLocator).toBeVisible();
    await itemLocator.click();
    
    await page.locator(locators.sale_summary.saleSummary_reset).click();

}

async function selectfiltersalesummary(page, customername) {

   
    await page.locator(locators.customerdropdown).click();
    await page.fill(locators.entercustomername, customername);
    await page.waitForTimeout(1000);
    // Step : Select the desired customer by its text
    const itemLocator = page.locator(`//td[@title='${customername}']`);
    await expect(itemLocator).toBeVisible();
    await itemLocator.click();
    
    await page.locator(locators.sale_summary.searchbuttonsummary).click();

}

async function verifydetailssalesummary(page) {
    /*****************Verify Customer Name is Correct ************************/
    const button = await page.locator('span.e-ungroupbutton[title="Ungroup by this column"]');
    await button.click();  // To perform a click action on the element
    //const Verifycustomer = JSON.parse(fs.readFileSync('customer.json')); //Read the shared Net Amount from the JSON file
    //const sharedcustomername = Verifycustomer.customername;
    const rows = await page.locator('tr[aria-rowindex]'); // Select all rows with aria-rowindex
    const firstRow = await rows.nth(0); // Select the first row
    await page.waitForTimeout(1000);
    const valuethree = await firstRow.locator("td#SalesSummaryReportCustomerNameColumn");
    const customernamecolumn = await valuethree.innerText();
    //expect(sharedcustomername).toBe(customernamecolumn);
    console.log(" Customer Name before Submit is same as Customer Name on the Sales summary Report")

    //Locate and click the "view" Button
    const viewButton = await firstRow.locator('a#SalesSummaryReportViewRegularBillNumberDetails'); //Adjust this with the actual selector for the "View" 

    // Check if the "View" button is visible
    const isVisible = await viewButton.isVisible();
    if (isVisible) {
        console.log('View button is visible. Proceeding with click.');
        await viewButton.click();
        console.log('Clicked on "View" button');
    } else {
        console.log('View button is not found or not visible.');
    }
    await page.waitForTimeout(3000);
    console.log("successfully click on view link")
    
}

async function selectfiltercombineResetsale(page, customername, date) {

    await page.locator(locators.reports_menu.reports).click();
    await page.locator(locators.reports_menu.sales_menu).click();
    await page.locator(locators.reports_menu.Combinesales).click();


    await page.locator(locators.combine_summary.fillterbuttoncombine).click();
    await page.locator(locators.customerdropdown).click();
    await page.fill(locators.entercustomername, customername);
    await page.waitForTimeout(1000);
    // Step : Select the desired customer by its text
    const itemLocator = page.locator(`//td[@title='${customername}']`);
    await expect(itemLocator).toBeVisible();
    await itemLocator.click();
    const datepicker = '#CombinedSalesReportDateRangePickerForFilter'; //code to clear the date
    await page.fill(datepicker, ''); //code to clear the date
    await page.fill(datepicker, date); //code to enter current data
    await page.locator(locators.combine_summary.combine_reset).click();

}

async function selectfiltercombinesale(page, customername) {

    // await page.locator(locators.reportsmenu.reports).click();
    // await page.locator(locators.reportsmenu.sales_menu).click();
    // await page.locator(locators.reportsmenu.Combinesales).click();


    // await page.locator(locators.combine_summary.fillterbuttoncombine).click();
    await page.locator(locators.customerdropdown).click();
    await page.fill(locators.entercustomername, customername);
    await page.waitForTimeout(1000);
    // Step : Select the desired customer by its text
    const itemLocator = page.locator(`//td[@title='${customername}']`);
    await expect(itemLocator).toBeVisible();
    await itemLocator.click();
    
    await page.locator(locators.combine_summary.searchbuttoncombine).click();

    const button = await page.locator('span.e-ungroupbutton[title="Ungroup by this column"]');
    await button.click();

}

module.exports = { selectsubmenu,selectfilteritemwise,verifydetailsitemwise,selectfilterResetitemwise,selectfiltersalesummary,selectfilterResetsalesummary,verifydetailssalesummary,selectfiltercombinesale,selectfiltercombineResetsale };
